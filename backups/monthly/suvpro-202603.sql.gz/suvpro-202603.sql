--
-- PostgreSQL database dump
--

\restrict GB8YnMN9P4x9JcVhUTzysNCDHhZkTo5pindzG3hr0gg9phphE09LpMzlcGsLGDn

-- Dumped from database version 16.13
-- Dumped by pg_dump version 18.0 (Debian 18.0-1.pgdg13+3)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO postgres;

--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audit_log (
    id uuid NOT NULL,
    tenant_id uuid,
    user_id uuid,
    action character varying(100) NOT NULL,
    entity_type character varying(50),
    entity_id character varying(100),
    old_value text,
    new_value text,
    ip_address character varying(50),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.audit_log OWNER TO postgres;

--
-- Name: client_addresses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.client_addresses (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    client_id uuid NOT NULL,
    region_id uuid,
    label character varying(50) NOT NULL,
    address_text character varying(500) NOT NULL,
    landmark character varying(200),
    apartment character varying(50),
    floor character varying(20),
    entrance character varying(20),
    latitude double precision,
    longitude double precision,
    city character varying(100),
    is_primary boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.client_addresses OWNER TO postgres;

--
-- Name: client_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.client_groups (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.client_groups OWNER TO postgres;

--
-- Name: clients; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.clients (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    user_id uuid,
    first_name character varying(100) NOT NULL,
    last_name character varying(100),
    phone character varying(20) NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    is_verified boolean DEFAULT false NOT NULL,
    is_blocked boolean DEFAULT false NOT NULL,
    has_contract boolean DEFAULT false NOT NULL,
    container_balance integer DEFAULT 0 NOT NULL,
    debt_amount integer DEFAULT 0 NOT NULL,
    advance_amount integer DEFAULT 0 NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL,
    group_id uuid,
    CONSTRAINT check_clients_debt_non_negative CHECK ((debt_amount >= 0))
);


ALTER TABLE public.clients OWNER TO postgres;

--
-- Name: container_client_balance; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.container_client_balance (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    client_id uuid NOT NULL,
    balance integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.container_client_balance OWNER TO postgres;

--
-- Name: container_transactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.container_transactions (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    client_id uuid NOT NULL,
    order_id integer,
    created_by_id uuid,
    transaction_type character varying(20) NOT NULL,
    quantity integer NOT NULL,
    balance_before integer NOT NULL,
    balance_after integer NOT NULL,
    note text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.container_transactions OWNER TO postgres;

--
-- Name: courier_balance_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.courier_balance_log (
    id uuid NOT NULL,
    courier_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    order_id integer,
    operation character varying(50) NOT NULL,
    full_containers_delta integer DEFAULT 0 NOT NULL,
    empty_containers_delta integer DEFAULT 0 NOT NULL,
    cash_delta integer DEFAULT 0 NOT NULL,
    card_delta integer DEFAULT 0 NOT NULL,
    payme_delta integer DEFAULT 0 NOT NULL,
    note text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.courier_balance_log OWNER TO postgres;

--
-- Name: courier_cash_collections; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.courier_cash_collections (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    courier_id uuid NOT NULL,
    collected_by_id uuid,
    cash_amount integer DEFAULT 0 NOT NULL,
    card_amount integer DEFAULT 0 NOT NULL,
    payme_amount integer DEFAULT 0 NOT NULL,
    total_amount integer DEFAULT 0 NOT NULL,
    full_containers_returned integer DEFAULT 0 NOT NULL,
    empty_containers_returned integer DEFAULT 0 NOT NULL,
    orders_completed integer DEFAULT 0 NOT NULL,
    note text,
    collection_date timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.courier_cash_collections OWNER TO postgres;

--
-- Name: courier_inventory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.courier_inventory (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    courier_id uuid NOT NULL,
    product_id uuid NOT NULL,
    quantity integer DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT check_courier_inventory_quantity_non_negative CHECK ((quantity >= 0))
);


ALTER TABLE public.courier_inventory OWNER TO postgres;

--
-- Name: TABLE courier_inventory; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.courier_inventory IS 'Текущие остатки товаров у курьеров';


--
-- Name: couriers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.couriers (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    user_id uuid NOT NULL,
    car_number character varying(20),
    is_active boolean DEFAULT true NOT NULL,
    shift_status character varying(10) DEFAULT 'closed'::character varying NOT NULL,
    shift_started_at timestamp with time zone,
    cash_balance integer DEFAULT 0 NOT NULL,
    card_balance integer DEFAULT 0 NOT NULL,
    payme_balance integer DEFAULT 0 NOT NULL,
    full_containers integer DEFAULT 0 NOT NULL,
    empty_containers integer DEFAULT 0 NOT NULL,
    preferred_navigator character varying(20) DEFAULT 'yandex'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT check_couriers_balances_non_negative CHECK (((cash_balance >= 0) AND (card_balance >= 0) AND (payme_balance >= 0) AND (full_containers >= 0) AND (empty_containers >= 0)))
);


ALTER TABLE public.couriers OWNER TO postgres;

--
-- Name: debt_transactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.debt_transactions (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    client_id uuid NOT NULL,
    debt_id uuid,
    order_id integer,
    created_by_id uuid,
    transaction_type character varying(20) NOT NULL,
    amount integer NOT NULL,
    payment_method character varying(20),
    description text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.debt_transactions OWNER TO postgres;

--
-- Name: debts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.debts (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    client_id uuid NOT NULL,
    order_id integer NOT NULL,
    original_amount integer NOT NULL,
    remaining_amount integer NOT NULL,
    is_paid boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    paid_at timestamp with time zone
);


ALTER TABLE public.debts OWNER TO postgres;

--
-- Name: notifications_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notifications_log (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    user_id uuid,
    order_id integer,
    telegram_id bigint,
    message text NOT NULL,
    notification_type character varying(50) NOT NULL,
    is_sent boolean DEFAULT false NOT NULL,
    error text,
    sent_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.notifications_log OWNER TO postgres;

--
-- Name: operator_cash_submissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.operator_cash_submissions (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    operator_id uuid NOT NULL,
    collected_by_id uuid,
    cash_amount integer DEFAULT 0 NOT NULL,
    card_amount integer DEFAULT 0 NOT NULL,
    total_amount integer DEFAULT 0 NOT NULL,
    note text,
    submission_date timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.operator_cash_submissions OWNER TO postgres;

--
-- Name: order_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_items (
    id uuid NOT NULL,
    order_id integer NOT NULL,
    product_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    quantity integer NOT NULL,
    price_at_order integer NOT NULL,
    total integer NOT NULL,
    delivered_quantity integer NOT NULL
);


ALTER TABLE public.order_items OWNER TO postgres;

--
-- Name: order_status_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_status_history (
    id uuid NOT NULL,
    order_id integer NOT NULL,
    tenant_id uuid NOT NULL,
    status character varying(20) NOT NULL,
    changed_by_id uuid,
    note text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.order_status_history OWNER TO postgres;

--
-- Name: orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orders (
    id integer NOT NULL,
    tenant_id uuid NOT NULL,
    client_id uuid NOT NULL,
    courier_id uuid,
    address_id uuid,
    status character varying(20) DEFAULT 'yangi'::character varying NOT NULL,
    payment_status character varying(20) DEFAULT 'tolanmagan'::character varying NOT NULL,
    payment_method character varying(20),
    total_amount integer DEFAULT 0 NOT NULL,
    paid_amount integer DEFAULT 0 NOT NULL,
    debt_amount integer DEFAULT 0 NOT NULL,
    containers_delivered integer DEFAULT 0 NOT NULL,
    containers_returned integer DEFAULT 0 NOT NULL,
    comment text,
    cancel_reason text,
    problem_reason text,
    is_phone_order boolean DEFAULT false NOT NULL,
    delivered_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    cash_amount integer DEFAULT 0 NOT NULL,
    card_amount integer DEFAULT 0 NOT NULL,
    contact_phone character varying(20)
);


ALTER TABLE public.orders OWNER TO postgres;

--
-- Name: orders_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.orders_id_seq OWNER TO postgres;

--
-- Name: orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.orders_id_seq OWNED BY public.orders.id;


--
-- Name: price_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.price_history (
    id uuid NOT NULL,
    product_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    old_price integer NOT NULL,
    new_price integer NOT NULL,
    changed_by_id uuid,
    changed_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.price_history OWNER TO postgres;

--
-- Name: product_categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_categories (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    icon character varying(50),
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.product_categories OWNER TO postgres;

--
-- Name: products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.products (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    category_id uuid,
    name character varying(200) NOT NULL,
    description text,
    image_url character varying(500),
    price integer NOT NULL,
    volume integer,
    volume_unit character varying(10),
    is_returnable_container boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    container_product_id uuid,
    containers_per_unit integer DEFAULT 1 NOT NULL,
    inactive_threshold_days integer DEFAULT 30 NOT NULL,
    show_to_clients boolean DEFAULT true NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL
);


ALTER TABLE public.products OWNER TO postgres;

--
-- Name: regions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.regions (
    id uuid NOT NULL,
    tenant_id uuid,
    name_uz character varying(100) NOT NULL,
    name_uz_cyrillic character varying(100),
    name_ru character varying(100),
    is_active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.regions OWNER TO postgres;

--
-- Name: settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.settings (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    company_name character varying(200),
    logo_url character varying(500),
    bot_token character varying(200),
    work_start_hour integer DEFAULT 8 NOT NULL,
    work_end_hour integer DEFAULT 22 NOT NULL,
    inactive_client_days integer DEFAULT 30 NOT NULL,
    extra_json text
);


ALTER TABLE public.settings OWNER TO postgres;

--
-- Name: tenants; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tenants (
    id uuid NOT NULL,
    name character varying(200) NOT NULL,
    slug character varying(100) NOT NULL,
    logo_url character varying(500),
    bot_token character varying(200),
    is_active boolean DEFAULT true NOT NULL,
    settings text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.tenants OWNER TO postgres;

--
-- Name: treasury_transactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.treasury_transactions (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    order_id integer,
    created_by_id uuid,
    transaction_type character varying(10) NOT NULL,
    category character varying(30),
    amount integer NOT NULL,
    payment_method character varying(20) NOT NULL,
    description text,
    transaction_date timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.treasury_transactions OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id uuid NOT NULL,
    tenant_id uuid,
    telegram_id bigint,
    telegram_username character varying(100),
    first_name character varying(100) NOT NULL,
    last_name character varying(100),
    phone character varying(20),
    role character varying(20) DEFAULT 'client'::character varying NOT NULL,
    hashed_password character varying(200),
    is_active boolean DEFAULT true NOT NULL,
    is_phone_verified boolean DEFAULT false NOT NULL,
    bot_blocked boolean DEFAULT false NOT NULL,
    language character varying(10) DEFAULT 'uz'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    cash_balance integer DEFAULT 0 NOT NULL,
    card_balance integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: warehouse_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.warehouse_items (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    product_id uuid,
    name character varying(200) NOT NULL,
    unit character varying(20) DEFAULT 'ta'::character varying NOT NULL,
    is_container boolean DEFAULT false NOT NULL,
    is_full boolean DEFAULT true NOT NULL,
    low_threshold integer DEFAULT 50 NOT NULL,
    out_threshold integer DEFAULT 10 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.warehouse_items OWNER TO postgres;

--
-- Name: warehouse_stock; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.warehouse_stock (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    item_id uuid NOT NULL,
    quantity integer DEFAULT 0 NOT NULL,
    empty_quantity integer DEFAULT 0 NOT NULL,
    CONSTRAINT check_warehouse_stock_quantity_non_negative CHECK (((quantity >= 0) AND (empty_quantity >= 0)))
);


ALTER TABLE public.warehouse_stock OWNER TO postgres;

--
-- Name: warehouse_transactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.warehouse_transactions (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    item_id uuid NOT NULL,
    order_id integer,
    courier_id uuid,
    created_by_id uuid,
    transaction_type character varying(10) NOT NULL,
    quantity integer NOT NULL,
    balance_before integer NOT NULL,
    balance_after integer NOT NULL,
    note text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.warehouse_transactions OWNER TO postgres;

--
-- Name: orders id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders ALTER COLUMN id SET DEFAULT nextval('public.orders_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alembic_version (version_num) FROM stdin;
h3i4j5k6l7m8
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audit_log (id, tenant_id, user_id, action, entity_type, entity_id, old_value, new_value, ip_address, created_at) FROM stdin;
\.


--
-- Data for Name: client_addresses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.client_addresses (id, tenant_id, client_id, region_id, label, address_text, landmark, apartment, floor, entrance, latitude, longitude, city, is_primary, created_at, updated_at) FROM stdin;
f2b9477a-82af-463e-b9f4-6fa1cd932f58	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	1f762413-3dc4-4c89-9e3c-a34ca4fbba99	\N	Uy	LOMONOSOVA 7A 2	9 bozor	2	1		\N	\N	\N	t	2026-03-18 20:51:30.164098+00	2026-03-18 20:51:30.164098+00
c8b4e47d-f7fd-4982-86e1-77419387ab30	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	1f762413-3dc4-4c89-9e3c-a34ca4fbba99	\N	Uy	7 Б, улица Ломоносова, Махалля Ватан, Navoiy shahri, Навоинский Район, Navoiy Viloyati, 210100, Oʻzbekiston					40.117172	65.3615753	\N	f	2026-03-19 07:36:36.851792+00	2026-03-19 07:36:36.851792+00
b7f15715-2e17-4172-a187-c8bfa6924866	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	df821ea1-c28c-411a-b9b0-8b16f11979bf	\N	Ish	O'zsanoatqurilishbank, улица Садриддин Айний, Navoiy shahri, Навоинский Район, Navoiy Viloyati, 210100, Oʻzbekiston					40.1091665	65.3367315	\N	f	2026-03-19 08:08:26.026145+00	2026-03-19 08:08:26.026145+00
3ed93332-bf92-41a2-ab9a-c2ec12b9ad2c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	df821ea1-c28c-411a-b9b0-8b16f11979bf	\N	Uy	Махалля Дехкон, Karmana, Karmana tumani, Navoiy Viloyati, 210600, Oʻzbekiston					40.1432714	65.3642849	\N	f	2026-03-19 12:30:45.657916+00	2026-03-19 12:30:45.657916+00
77de7759-8d96-4afc-b7f4-d1c27def9a5d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	2e40a458-c6b6-4c41-bb79-f2ae224decc0	\N	Uy	40.11695, 65.36140	\N	\N	\N	\N	40.116949	65.361402	\N	t	2026-03-21 08:52:05.071799+00	2026-03-21 08:52:05.071799+00
e19eb946-586d-43a7-b01a-8f019ccb6fab	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	1f762413-3dc4-4c89-9e3c-a34ca4fbba99	\N	Boshqa	улица махтумкули 15 20кв	\N	\N	\N	\N	\N	\N	\N	f	2026-03-21 09:04:07.621144+00	2026-03-21 09:04:07.621144+00
af4daa50-db82-4c45-b23d-770601f6ba7c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	aec3e0a9-01b1-4bf2-91ec-4655c3f5c77c	\N	Boshqa	навои шахри 9 бозор	\N	\N	\N	\N	\N	\N	\N	f	2026-03-22 05:16:23.022417+00	2026-03-22 05:16:23.022417+00
9c4df195-5873-4fa3-bfae-4c9e47f1fe44	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	2e40a458-c6b6-4c41-bb79-f2ae224decc0	\N	Boshqa	янги бозор	\N	\N	\N	\N	\N	\N	\N	f	2026-03-22 05:24:58.844378+00	2026-03-22 05:24:58.844378+00
6dc93b2a-a65e-4b54-b2cb-e994473b8b01	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	70c5b358-66d5-401b-b4d7-231e4aef297a	\N	Uy	40.12933, 65.37120	\N	\N	\N	\N	40.129331	65.371202	\N	t	2026-03-22 06:24:11.146652+00	2026-03-22 06:24:11.146652+00
0597d7dc-f03c-45c1-bdc3-3036cb8c70da	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	88098c0c-44ba-4c51-899f-9fd58dd4277c	\N	Boshqa	Karmana 2	\N	\N	\N	\N	\N	\N	\N	f	2026-03-24 13:01:04.653274+00	2026-03-24 13:01:04.653274+00
32ec0b97-9f96-4e00-b396-7d9eb3fe42f9	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	db638bc6-c733-4122-9dc2-8a3f70453c76	\N	Uy	40.12145, 65.35754	\N	\N	\N	\N	40.121451	65.357538	\N	t	2026-03-26 01:39:17.385351+00	2026-03-26 01:39:17.385351+00
3ba78587-c6fc-40ab-945d-47dcbf6f97c3	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	70c5b358-66d5-401b-b4d7-231e4aef297a	\N	Boshqa	rfr	\N	\N	\N	\N	\N	\N	\N	f	2026-03-26 08:28:29.031085+00	2026-03-26 08:28:29.031085+00
3ad4c99a-456d-4fa3-86ca-f0eb5c6a4fe6	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	db638bc6-c733-4122-9dc2-8a3f70453c76	\N	Boshqa	Навоий 2х	\N	\N	\N	\N	\N	\N	\N	f	2026-03-27 11:16:37.183215+00	2026-03-27 11:16:37.183215+00
358e1f85-0f97-420e-b8d6-bb7d6b559bf0	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	aec3e0a9-01b1-4bf2-91ec-4655c3f5c77c	\N	Boshqa	Навои 2 45	\N	\N	\N	\N	\N	\N	\N	f	2026-03-27 11:19:28.202675+00	2026-03-27 11:19:28.202675+00
73d6b51d-0e59-4f08-bfd2-e3fbc0f9c50b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	a9f6123e-c55a-44b1-a09e-70bb797f9101	\N	Uy	40.13533, 65.36715	\N	\N	\N	\N	40.135326	65.367154	\N	t	2026-03-27 11:38:06.864048+00	2026-03-27 11:38:06.864048+00
0b86e6c4-cece-4f3b-bc5c-9a962000176b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	a409f7ad-5f4b-4e3a-9905-0fa795c5ad1f	\N	Uy	40.12933, 65.37120	\N	\N	\N	\N	40.129331	65.371202	\N	t	2026-03-28 13:50:43.730783+00	2026-03-28 13:50:43.730783+00
a823a669-fac8-4e24-9ef1-1ec1c825fefc	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	12a3be02-6e5c-4b3c-94d2-d3ac4d9c4d60	\N	Uy	баходир	\N	\N	\N	\N	\N	\N	\N	t	2026-03-29 06:26:05.462467+00	2026-03-29 06:26:05.462467+00
281d4045-f71e-46c1-ae9e-cfb4e2f3b977	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	fd20af3f-c093-4222-b503-f78ce13d265c	\N	Uy	Ziyokor 153	\N	\N	\N	\N	\N	\N	\N	t	2026-03-30 07:25:28.500434+00	2026-03-30 07:25:28.500434+00
\.


--
-- Data for Name: client_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.client_groups (id, tenant_id, name, sort_order, created_at, updated_at) FROM stdin;
7453eaba-2f9c-4120-9f2a-0dca2e6f33fa	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	янги гурух	0	2026-03-29 11:18:21.803305+00	2026-03-29 11:18:21.803305+00
\.


--
-- Data for Name: clients; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.clients (id, tenant_id, user_id, first_name, last_name, phone, is_active, is_verified, is_blocked, has_contract, container_balance, debt_amount, advance_amount, notes, created_at, updated_at, is_deleted, group_id) FROM stdin;
1f762413-3dc4-4c89-9e3c-a34ca4fbba99	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	49ff00e4-1838-4106-849d-4a00256d1241	Бехруз	Хайриллоев	+998937570731	t	t	f	f	8	0	0	\N	2026-03-18 18:10:36.934887+00	2026-03-20 20:37:37.508362+00	f	\N
70c5b358-66d5-401b-b4d7-231e4aef297a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	abadd210-693e-4193-b2c0-2f31132c0e08	Qodirov	\N	+998900157775	t	t	f	f	0	0	0	\N	2026-03-22 06:24:11.146652+00	2026-03-22 06:24:11.146652+00	f	\N
a9f6123e-c55a-44b1-a09e-70bb797f9101	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	1078b015-3922-4283-94f6-be7629c9371a	zaripov_o17	\N	+998770357032	t	t	f	f	0	0	0	\N	2026-03-27 11:38:06.864048+00	2026-03-27 11:38:06.864048+00	f	\N
a409f7ad-5f4b-4e3a-9905-0fa795c5ad1f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	d23f6f14-c3fb-4337-80cb-d9929518d9fb	Strong water		+998997555516	t	t	f	f	0	0	0	\N	2026-03-28 13:50:43.730783+00	2026-03-28 13:51:28.027277+00	f	\N
88098c0c-44ba-4c51-899f-9fd58dd4277c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	Суннат 	Хайриллоев	+998999999999	f	f	f	f	5	0	0	\N	2026-03-21 08:53:51.524258+00	2026-03-29 04:05:59.496988+00	t	\N
db638bc6-c733-4122-9dc2-8a3f70453c76	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	757d7d23-af87-4de8-87c9-ee21bcf87b93	HIMALAY	\N	+998913373937	t	t	f	f	30	0	0	\N	2026-03-26 01:39:17.385351+00	2026-03-29 12:10:12.384764+00	f	\N
fd20af3f-c093-4222-b503-f78ce13d265c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	e6babbdd-1df1-44ba-a38e-d5227c335b50	Akobir	Qodirov	+998905005030	t	t	f	f	0	0	0	\N	2026-03-30 07:25:28.500434+00	2026-03-30 07:25:28.500434+00	f	\N
2e40a458-c6b6-4c41-bb79-f2ae224decc0	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	2bc91495-9590-46d3-9730-db037c942f5b	Юмитова Юлдуз.	\N	+998973231310	f	t	f	f	3	0	0	\N	2026-03-21 08:52:05.071799+00	2026-03-30 07:31:45.047953+00	t	7453eaba-2f9c-4120-9f2a-0dca2e6f33fa
12a3be02-6e5c-4b3c-94d2-d3ac4d9c4d60	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	Баходир	Баходиров	+998999999991	f	f	f	f	0	0	0	\N	2026-03-29 06:26:05.362626+00	2026-03-30 07:31:59.256994+00	t	\N
aec3e0a9-01b1-4bf2-91ec-4655c3f5c77c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	Акмал	Акмалов	+998505005050	f	f	f	f	0	0	0	\N	2026-03-22 04:59:11.331532+00	2026-03-30 07:32:09.040731+00	t	\N
85baf3d2-d829-46ba-a661-ad5c8e5d1809	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	Баходир	Анваров	+998931233211	f	f	f	f	0	0	0	\N	2026-03-22 05:25:28.128892+00	2026-03-30 07:32:14.932343+00	t	\N
df821ea1-c28c-411a-b9b0-8b16f11979bf	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	b89bc16d-45c3-4ae7-921e-a095cb04f0c9	Rasuljon	Melixanov	+998975590068	f	t	f	f	4	0	0	\N	2026-03-19 08:03:26.429458+00	2026-03-30 07:32:23.088798+00	t	\N
\.


--
-- Data for Name: container_client_balance; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.container_client_balance (id, tenant_id, client_id, balance) FROM stdin;
9f8d3845-877c-4d76-98fc-be2fd46c8c75	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	df821ea1-c28c-411a-b9b0-8b16f11979bf	4
1c3f5dd4-c64e-4150-9ce8-1749b84ee35d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	1f762413-3dc4-4c89-9e3c-a34ca4fbba99	8
63177359-8f71-4e9b-ae9f-cfe7f167791f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	2e40a458-c6b6-4c41-bb79-f2ae224decc0	3
9b473611-a79a-454d-a065-6291c2564c42	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	aec3e0a9-01b1-4bf2-91ec-4655c3f5c77c	0
dcac79af-da56-424b-a842-c272e0ac262f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	db638bc6-c733-4122-9dc2-8a3f70453c76	30
cedb14d8-fd67-43b2-9fca-cee3d9c59d49	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	88098c0c-44ba-4c51-899f-9fd58dd4277c	5
\.


--
-- Data for Name: container_transactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.container_transactions (id, tenant_id, client_id, order_id, created_by_id, transaction_type, quantity, balance_before, balance_after, note, created_at) FROM stdin;
f67f5b59-9d28-43f7-97bd-e113d5853500	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	df821ea1-c28c-411a-b9b0-8b16f11979bf	\N	\N	returned	4	0	-4	\N	2026-03-19 08:56:42.213024+00
152bcdd0-ceab-4078-a004-3d5d7799a9c5	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	1f762413-3dc4-4c89-9e3c-a34ca4fbba99	\N	\N	delivered	3	0	3	\N	2026-03-20 03:45:39.667676+00
a5a418a6-fb3f-4d28-ba2c-11b9202abf29	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	1f762413-3dc4-4c89-9e3c-a34ca4fbba99	\N	\N	delivered	6	3	9	\N	2026-03-20 03:45:46.094813+00
87b7e127-cdf5-45e1-bf58-34e4b88ee890	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	1f762413-3dc4-4c89-9e3c-a34ca4fbba99	\N	\N	returned	3	9	6	\N	2026-03-20 03:45:46.094813+00
c469612f-4016-4896-bfe9-622a46d11e40	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	df821ea1-c28c-411a-b9b0-8b16f11979bf	\N	\N	delivered	5	-4	1	\N	2026-03-20 03:45:49.727276+00
3a170acc-0e94-48e6-89cd-ae77720cf38a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	df821ea1-c28c-411a-b9b0-8b16f11979bf	\N	\N	delivered	3	1	4	\N	2026-03-20 03:45:51.837994+00
12e19fc6-fcd0-41f7-9ef8-53f1cbc7fbe8	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	1f762413-3dc4-4c89-9e3c-a34ca4fbba99	\N	\N	delivered	4	6	10	\N	2026-03-20 20:37:37.508362+00
26ae6710-9555-4953-9f1a-ec0dd776e394	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	1f762413-3dc4-4c89-9e3c-a34ca4fbba99	\N	\N	returned	2	10	8	\N	2026-03-20 20:37:37.508362+00
8d02f73d-794d-4f62-8d28-d2b854ba6393	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	2e40a458-c6b6-4c41-bb79-f2ae224decc0	9	\N	delivered	3	0	3	\N	2026-03-21 19:05:40.820797+00
eded0d0d-6523-4635-8a8a-47bcd34410f0	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	aec3e0a9-01b1-4bf2-91ec-4655c3f5c77c	12	\N	delivered	1	0	1	\N	2026-03-22 06:33:36.7937+00
f1f5b64b-09e1-4549-a77f-2081cca82e5f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	aec3e0a9-01b1-4bf2-91ec-4655c3f5c77c	12	\N	returned	1	1	0	\N	2026-03-22 06:33:36.7937+00
0c05d25a-8249-412f-8d04-b115154ade7b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	db638bc6-c733-4122-9dc2-8a3f70453c76	22	\N	delivered	30	0	30	\N	2026-03-28 14:04:10.537478+00
4ad8d932-2b1f-4bdc-8a22-159a5da38766	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	88098c0c-44ba-4c51-899f-9fd58dd4277c	10	\N	delivered	5	0	5	\N	2026-03-29 04:05:59.496988+00
\.


--
-- Data for Name: courier_balance_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.courier_balance_log (id, courier_id, tenant_id, order_id, operation, full_containers_delta, empty_containers_delta, cash_delta, card_delta, payme_delta, note, created_at) FROM stdin;
969d5111-5d26-49ee-ba6e-c9ad343d996b	0f177107-8b39-4bcb-b914-5445c00ac6ee	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	shift_open	0	0	0	0	0	Smena ochildi. Boshlang'ich to'la tara: 0	2026-03-19 08:55:23.890624+00
7020b37a-444e-43d3-bd09-5d7685b279e8	0f177107-8b39-4bcb-b914-5445c00ac6ee	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	shift_close_by_operator	0	0	0	0	0	Operator tomonidan yopildi. Farq: naqd=0, karta=0, payme=0	2026-03-20 20:43:07.50134+00
c7bed2b4-0b22-4c26-b1d6-ad3d1e08d6a1	0f177107-8b39-4bcb-b914-5445c00ac6ee	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	shift_open	0	0	0	0	0	Smena ochildi. Boshlang'ich to'la tara: 0	2026-03-20 20:43:23.174581+00
1b966582-3557-4a5b-974d-c1225866c83b	0f177107-8b39-4bcb-b914-5445c00ac6ee	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	shift_close	0	0	0	0	0	Smena yopildi. Farq: naqd=0, karta=0, payme=0	2026-03-21 18:22:25.038476+00
9d460bcd-a77c-4bc5-9435-4b6c3ea4ade3	0f177107-8b39-4bcb-b914-5445c00ac6ee	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	shift_open	0	0	0	0	0	Smena ochildi. Boshlang'ich to'la tara: 0	2026-03-21 18:22:25.959495+00
7d640f2a-d2d3-43d6-ab6a-fd3e56f51e22	0f177107-8b39-4bcb-b914-5445c00ac6ee	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	shift_close_by_operator	0	0	0	0	0	Operator tomonidan yopildi. Farq: naqd=0, karta=0, payme=0	2026-03-21 19:20:50.244477+00
3e1f16a3-a234-45e6-bf83-3e894a4dc300	0f177107-8b39-4bcb-b914-5445c00ac6ee	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	shift_open	0	0	0	0	0	Smena ochildi. Boshlang'ich to'la tara: 0	2026-03-22 06:34:20.56802+00
a241bc6a-12ca-44d1-9af4-40e749bd19f4	0f177107-8b39-4bcb-b914-5445c00ac6ee	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	shift_close_by_operator	0	0	0	0	0	Operator tomonidan yopildi. Farq: naqd=0, karta=0, payme=0	2026-03-22 06:55:16.479052+00
d540ad9a-44c1-4ca2-a75b-2762247d267d	0f177107-8b39-4bcb-b914-5445c00ac6ee	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	shift_open	0	0	0	0	0	Smena ochildi. Boshlang'ich to'la tara: 0	2026-03-27 11:50:16.875452+00
397beb73-bf32-4820-9206-16cbcb8e3d02	0f177107-8b39-4bcb-b914-5445c00ac6ee	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	shift_close	0	0	0	0	0	Smena yopildi. Farq: naqd=0, karta=0, payme=0	2026-03-27 11:50:18.459448+00
aa375887-3d67-4ed1-8a3c-2b069265b485	0f177107-8b39-4bcb-b914-5445c00ac6ee	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	shift_open	0	0	0	0	0	Smena ochildi. Boshlang'ich to'la tara: 0	2026-03-27 11:50:19.194411+00
f330101b-f10b-4b29-b928-14386cf5d1fd	0f177107-8b39-4bcb-b914-5445c00ac6ee	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	shift_close	0	0	0	0	0	Smena yopildi. Farq: naqd=0, karta=0, payme=0	2026-03-27 11:50:19.603614+00
a16debaa-eb9d-4b21-b4b2-672d3163ecea	0f177107-8b39-4bcb-b914-5445c00ac6ee	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	shift_open	0	0	0	0	0	Smena ochildi. Boshlang'ich to'la tara: 0	2026-03-27 11:50:20.025114+00
e3e3add3-3d20-463a-8174-8b00c0a9c8d4	0f177107-8b39-4bcb-b914-5445c00ac6ee	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	shift_close	0	0	0	0	0	Smena yopildi. Farq: naqd=0, karta=0, payme=0	2026-03-27 11:50:20.505926+00
5056c7e7-2982-4561-afbc-0a34c49fc6b7	0f177107-8b39-4bcb-b914-5445c00ac6ee	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	shift_open	0	0	0	0	0	Smena ochildi. Boshlang'ich to'la tara: 0	2026-03-27 11:50:20.871861+00
d28d18d1-bc8b-4ef1-a4b7-5bc6d15702b7	0f177107-8b39-4bcb-b914-5445c00ac6ee	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	shift_close	0	0	0	0	0	Smena yopildi. Farq: naqd=0, karta=0, payme=0	2026-03-27 11:50:21.409753+00
bd39ad94-0f5f-4653-a800-5ce2bad97bac	0f177107-8b39-4bcb-b914-5445c00ac6ee	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	shift_open	0	0	0	0	0	Smena ochildi. Boshlang'ich to'la tara: 0	2026-03-27 11:50:22.414636+00
f4f5240b-9c0c-4188-bbab-59da30fbd81c	0f177107-8b39-4bcb-b914-5445c00ac6ee	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	shift_close	0	0	0	0	0	Smena yopildi. Farq: naqd=0, karta=0, payme=0	2026-03-27 11:50:29.578966+00
2ea4191c-6917-488c-b3f1-2af7de45f8ac	0f177107-8b39-4bcb-b914-5445c00ac6ee	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	shift_open	0	0	0	0	0	Smena ochildi. Boshlang'ich to'la tara: 0	2026-03-27 11:50:30.424356+00
d2537a29-d286-4eef-81e9-2aad7d48f84f	0f177107-8b39-4bcb-b914-5445c00ac6ee	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	shift_close	0	0	0	0	0	Smena yopildi. Farq: naqd=0, karta=0, payme=0	2026-03-27 11:50:30.881691+00
07995d19-e22c-401c-b066-c66357f79628	0f177107-8b39-4bcb-b914-5445c00ac6ee	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	shift_open	0	0	0	0	0	Smena ochildi. Boshlang'ich to'la tara: 0	2026-03-27 11:50:35.63427+00
a77411ca-562f-43e7-a719-58b00bc9e7f5	0f177107-8b39-4bcb-b914-5445c00ac6ee	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	shift_close_by_operator	0	0	0	0	0	Operator tomonidan yopildi. Farq: naqd=0, karta=0, payme=0	2026-03-27 15:13:03.975304+00
81d32c4a-1ada-4279-91a4-fdc86308c1f0	6adef115-693e-422a-a94c-b774ea98141a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	shift_open	0	0	0	0	0	Smena ochildi. Boshlang'ich to'la tara: 0	2026-03-28 14:00:53.728369+00
90b51d48-2e6e-4c4b-92f4-aa29139d78a8	6adef115-693e-422a-a94c-b774ea98141a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	shift_close	0	0	0	0	0	Smena yopildi. Farq: naqd=-300000, karta=0, payme=0	2026-03-28 14:04:36.343495+00
\.


--
-- Data for Name: courier_cash_collections; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.courier_cash_collections (id, tenant_id, courier_id, collected_by_id, cash_amount, card_amount, payme_amount, total_amount, full_containers_returned, empty_containers_returned, orders_completed, note, collection_date) FROM stdin;
89acbaaa-1a4c-431c-8577-dd80fb67a771	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	0f177107-8b39-4bcb-b914-5445c00ac6ee	ae52ce2c-19e6-4a62-9081-1185b515af53	40000	50000	0	90000	0	2	4		2026-03-20 20:43:07.50134+00
4774a612-108a-47be-8e64-81b66588d0d0	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	0f177107-8b39-4bcb-b914-5445c00ac6ee	49ff00e4-1838-4106-849d-4a00256d1241	0	0	0	0	0	0	0	\N	2026-03-21 18:22:25.038476+00
50af1d79-80cb-4b7b-a709-26c29a8b8ec2	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	0f177107-8b39-4bcb-b914-5445c00ac6ee	ae52ce2c-19e6-4a62-9081-1185b515af53	145000	10000	0	155000	0	0	2		2026-03-21 19:20:50.244477+00
10f40815-a958-49fb-b85b-18ee9dcca5b2	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	0f177107-8b39-4bcb-b914-5445c00ac6ee	ae52ce2c-19e6-4a62-9081-1185b515af53	10000	0	0	10000	0	0	1		2026-03-22 06:55:16.479052+00
f6e6fd47-fcba-4139-8557-2f23bd8f2653	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	0f177107-8b39-4bcb-b914-5445c00ac6ee	49ff00e4-1838-4106-849d-4a00256d1241	0	0	0	0	0	0	0	\N	2026-03-27 11:50:18.459448+00
1aa894df-9a22-4fee-ba83-db2f5ae2ab58	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	0f177107-8b39-4bcb-b914-5445c00ac6ee	49ff00e4-1838-4106-849d-4a00256d1241	0	0	0	0	0	0	0	\N	2026-03-27 11:50:19.603614+00
c9cd4484-89f3-4ad6-88d5-2476dd488d29	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	0f177107-8b39-4bcb-b914-5445c00ac6ee	49ff00e4-1838-4106-849d-4a00256d1241	0	0	0	0	0	0	0	\N	2026-03-27 11:50:20.505926+00
3433fe6e-e7b1-40a5-8fcb-4bb0e0aa4ab5	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	0f177107-8b39-4bcb-b914-5445c00ac6ee	49ff00e4-1838-4106-849d-4a00256d1241	0	0	0	0	0	0	0	\N	2026-03-27 11:50:21.409753+00
d14b0f6a-e8a6-427c-b0a7-6cb40035cd83	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	0f177107-8b39-4bcb-b914-5445c00ac6ee	49ff00e4-1838-4106-849d-4a00256d1241	0	0	0	0	0	0	0	\N	2026-03-27 11:50:29.578966+00
1c4939fc-f30f-4807-8e8a-5a296ce98b98	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	0f177107-8b39-4bcb-b914-5445c00ac6ee	49ff00e4-1838-4106-849d-4a00256d1241	0	0	0	0	0	0	0	\N	2026-03-27 11:50:30.881691+00
2594ffc9-82b1-4226-b554-1f5c4bea0066	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	0f177107-8b39-4bcb-b914-5445c00ac6ee	ae52ce2c-19e6-4a62-9081-1185b515af53	0	0	0	0	0	0	0		2026-03-27 15:13:03.975304+00
476bfaa1-7c0c-4d47-916e-f8bc025a33aa	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	6adef115-693e-422a-a94c-b774ea98141a	d23f6f14-c3fb-4337-80cb-d9929518d9fb	0	0	0	0	0	0	1	\N	2026-03-28 14:04:36.343495+00
\.


--
-- Data for Name: courier_inventory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.courier_inventory (id, tenant_id, courier_id, product_id, quantity, updated_at) FROM stdin;
d064169e-cdb3-408a-9051-a419f653660b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	6adef115-693e-422a-a94c-b774ea98141a	82725c10-d3e4-48cd-b6df-c881652fe0f8	2	2026-03-28 14:00:09.216823+00
6e24b3f6-d24b-4689-b0ca-830c614ba4ef	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	6adef115-693e-422a-a94c-b774ea98141a	878bdc5d-fb6e-40c4-b2ba-4a4c65073e78	2	2026-03-28 14:00:09.216823+00
05dfc15a-719f-4e8a-b5ae-acf5e742638c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	6adef115-693e-422a-a94c-b774ea98141a	31c66e15-1101-4a40-b40a-4a42839f2ccc	2	2026-03-28 14:00:09.216823+00
712ad640-9142-49c4-bccc-3bd026637c92	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	6adef115-693e-422a-a94c-b774ea98141a	3b30efd1-cbc1-4d46-b5ed-6537c9b7118e	2	2026-03-28 14:04:10.537478+00
\.


--
-- Data for Name: couriers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.couriers (id, tenant_id, user_id, car_number, is_active, shift_status, shift_started_at, cash_balance, card_balance, payme_balance, full_containers, empty_containers, preferred_navigator, created_at, updated_at) FROM stdin;
0f177107-8b39-4bcb-b914-5445c00ac6ee	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	49ff00e4-1838-4106-849d-4a00256d1241	\N	t	CLOSED	2026-03-27 11:50:35.637087+00	0	0	0	0	0	yandex	2026-03-19 08:39:04.250183+00	2026-03-27 15:13:03.975304+00
b21012bd-e496-4f71-9f85-a4c6dc6fca89	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	1078b015-3922-4283-94f6-be7629c9371a	85533ZAA	t	CLOSED	\N	0	0	0	0	0	yandex	2026-03-28 09:18:53.067945+00	2026-03-28 09:18:53.067945+00
6adef115-693e-422a-a94c-b774ea98141a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	d23f6f14-c3fb-4337-80cb-d9929518d9fb	\N	t	CLOSED	2026-03-28 14:00:53.775808+00	0	0	0	0	0	yandex	2026-03-28 13:51:34.603141+00	2026-03-28 14:04:36.343495+00
82445b20-963b-433b-b452-d70935033042	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	757d7d23-af87-4de8-87c9-ee21bcf87b93	\N	t	CLOSED	\N	50000	0	0	0	0	yandex	2026-03-27 11:20:03.253082+00	2026-03-29 04:05:59.496988+00
\.


--
-- Data for Name: debt_transactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.debt_transactions (id, tenant_id, client_id, debt_id, order_id, created_by_id, transaction_type, amount, payment_method, description, created_at) FROM stdin;
0c0eb640-8692-42e5-bdee-ffd833e6d95d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	df821ea1-c28c-411a-b9b0-8b16f11979bf	\N	\N	49ff00e4-1838-4106-849d-4a00256d1241	PAYMENT	50000	KARTA	Qarz to'landi kuryer orqali. To'lov: KARTA	2026-03-20 20:42:25.675407+00
cebc971b-4f25-4165-a127-4da31a793743	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	2e40a458-c6b6-4c41-bb79-f2ae224decc0	\N	\N	49ff00e4-1838-4106-849d-4a00256d1241	PAYMENT	10000	NAQD	Qarz to'landi kuryer orqali. To'lov: NAQD	2026-03-22 06:49:10.828007+00
96ecb165-0f10-4882-a390-30c619535568	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	aec3e0a9-01b1-4bf2-91ec-4655c3f5c77c	\N	\N	49ff00e4-1838-4106-849d-4a00256d1241	PAYMENT	2000	NAQD	20000	2026-03-27 11:50:05.774469+00
\.


--
-- Data for Name: debts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.debts (id, tenant_id, client_id, order_id, original_amount, remaining_amount, is_paid, created_at, paid_at) FROM stdin;
a4fccf37-0b81-4ab2-a68a-ce20791b2350	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	2e40a458-c6b6-4c41-bb79-f2ae224decc0	9	10000	10000	f	2026-03-21 19:05:40.820797+00	\N
cba96208-f61e-47da-b9d5-3fbdfb1e2edf	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	aec3e0a9-01b1-4bf2-91ec-4655c3f5c77c	12	2000	2000	f	2026-03-22 06:33:36.7937+00	\N
\.


--
-- Data for Name: notifications_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notifications_log (id, tenant_id, user_id, order_id, telegram_id, message, notification_type, is_sent, error, sent_at, created_at) FROM stdin;
\.


--
-- Data for Name: operator_cash_submissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.operator_cash_submissions (id, tenant_id, operator_id, collected_by_id, cash_amount, card_amount, total_amount, note, submission_date) FROM stdin;
\.


--
-- Data for Name: order_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_items (id, order_id, product_id, tenant_id, quantity, price_at_order, total, delivered_quantity) FROM stdin;
02d8da34-0de4-46f6-9616-4c8bb86a5f09	9	3b30efd1-cbc1-4d46-b5ed-6537c9b7118e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	3	10000	30000	3
35dea164-4e31-4379-aee9-d1820f9711fe	9	878bdc5d-fb6e-40c4-b2ba-4a4c65073e78	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	2	5000	10000	2
2e59e4c1-d05a-4ec5-92ab-6384bff27d93	10	3b30efd1-cbc1-4d46-b5ed-6537c9b7118e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	5	10000	50000	5
69773813-b45e-4951-8901-86d12430b389	11	878bdc5d-fb6e-40c4-b2ba-4a4c65073e78	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	25	5000	125000	25
a12fc1b6-8702-4f95-b676-303d6aa8e19e	12	3b30efd1-cbc1-4d46-b5ed-6537c9b7118e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	1	10000	10000	1
065eaf15-bb33-4ef1-b54a-0e92e4951c6d	13	878bdc5d-fb6e-40c4-b2ba-4a4c65073e78	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	15	5000	75000	15
f77c4269-dfb5-4edc-a94d-7d9411e2f403	14	878bdc5d-fb6e-40c4-b2ba-4a4c65073e78	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	4	5000	20000	4
b0508d4c-df69-411e-a4e1-ff795ead6ae6	15	3b30efd1-cbc1-4d46-b5ed-6537c9b7118e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	1	10000	10000	1
9fedead2-333e-4295-b83e-9cc78f3e0b44	15	82725c10-d3e4-48cd-b6df-c881652fe0f8	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	2	7000	14000	2
f272cb98-c123-4cc1-9598-872660affce0	16	82725c10-d3e4-48cd-b6df-c881652fe0f8	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	5	7000	35000	5
9657f704-691f-4086-9954-a828a3be5ed0	17	31c66e15-1101-4a40-b40a-4a42839f2ccc	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	1	5000000	5000000	1
202b831a-c8be-4f4a-abbe-6efb41b81a90	18	878bdc5d-fb6e-40c4-b2ba-4a4c65073e78	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	3	5000	15000	3
70ebcb51-907e-4606-9a1f-449215e0e08f	18	3b30efd1-cbc1-4d46-b5ed-6537c9b7118e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	1	10000	10000	1
01536699-1521-4bde-bd2d-3aaf4fa8e618	18	31c66e15-1101-4a40-b40a-4a42839f2ccc	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	1	5000000	5000000	1
eb1bc2f1-4c71-44e1-b945-2d535f287784	18	0ee9ecf5-334c-48cb-921c-448da04c0a69	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	1	70000	70000	1
c1e0da72-098d-4f59-8ca5-66da2435e012	19	3b30efd1-cbc1-4d46-b5ed-6537c9b7118e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	1	10000	10000	1
fe36df8b-1289-47d9-a621-464d5480ff17	19	82725c10-d3e4-48cd-b6df-c881652fe0f8	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	1	7000	7000	1
75ee0a5f-c999-42f0-95bc-e582387f57ac	19	31c66e15-1101-4a40-b40a-4a42839f2ccc	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	1	5000000	5000000	1
eaa6a6bd-92a0-4835-91e7-780612600584	19	878bdc5d-fb6e-40c4-b2ba-4a4c65073e78	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	1	5000	5000	1
986d8953-ce15-4fab-91d3-d0b73d8f8a3d	19	0ee9ecf5-334c-48cb-921c-448da04c0a69	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	1	70000	70000	1
1b32eba0-0e30-4862-b6c1-c78e0a87d5ba	20	3b30efd1-cbc1-4d46-b5ed-6537c9b7118e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	10	10000	100000	10
52dcd3b8-e035-43f4-8aec-d1c51b28eb3c	21	82725c10-d3e4-48cd-b6df-c881652fe0f8	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	15	8000	120000	15
3e1a9390-49c5-4d04-b860-c5a1c177901a	22	3b30efd1-cbc1-4d46-b5ed-6537c9b7118e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	30	10000	300000	30
\.


--
-- Data for Name: order_status_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_status_history (id, order_id, tenant_id, status, changed_by_id, note, created_at) FROM stdin;
be6d8e4e-c9e0-428f-aa83-5a3755419ae9	9	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	YANGI	2bc91495-9590-46d3-9730-db037c942f5b	\N	2026-03-21 08:52:34.185373+00
96d4e422-fe86-4a13-bf80-c4ece4dc949d	10	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	YANGI	ae52ce2c-19e6-4a62-9081-1185b515af53	\N	2026-03-21 08:54:21.456167+00
daa00d41-d5a5-42bd-a103-f6f322843a5a	11	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	YANGI	ae52ce2c-19e6-4a62-9081-1185b515af53	\N	2026-03-21 09:04:07.621144+00
4d05e52e-46b5-423a-8bd9-8e08f678b8a2	11	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	TAYINLANDI	ae52ce2c-19e6-4a62-9081-1185b515af53	\N	2026-03-21 18:40:07.085651+00
215175ea-554e-4c9d-9bb5-d89a1fc9309f	11	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	YETKAZILDI	49ff00e4-1838-4106-849d-4a00256d1241	\N	2026-03-21 18:42:34.015242+00
b7e21ec7-e0bd-4a57-9271-75ea0e2d5932	9	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	TAYINLANDI	ae52ce2c-19e6-4a62-9081-1185b515af53	\N	2026-03-21 19:02:42.426503+00
cc672403-7002-4986-940a-d35d2b26647f	9	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	YETKAZILDI	49ff00e4-1838-4106-849d-4a00256d1241	\N	2026-03-21 19:05:40.820797+00
b2eae49e-fbf4-4961-8392-c84719815ef3	12	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	YANGI	ae52ce2c-19e6-4a62-9081-1185b515af53	\N	2026-03-22 05:16:23.022417+00
7ae4ad64-b658-4027-a89a-36f8f249d522	13	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	YANGI	ae52ce2c-19e6-4a62-9081-1185b515af53	\N	2026-03-22 05:24:58.844378+00
1df6a6db-df82-4d80-80e8-3bdc7b74fe0d	13	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	TAYINLANDI	ae52ce2c-19e6-4a62-9081-1185b515af53	\N	2026-03-22 05:25:06.454147+00
75464b2f-0b6b-4833-b4c5-ce58ea395938	12	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	TAYINLANDI	ae52ce2c-19e6-4a62-9081-1185b515af53	\N	2026-03-22 05:25:10.037059+00
be15e053-30b8-4da2-9e86-7c4128a93ac7	14	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	YANGI	abadd210-693e-4193-b2c0-2f31132c0e08	\N	2026-03-22 06:25:05.203149+00
1e8bfa68-7195-4e6f-bcde-83dc654cd3e7	14	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	TAYINLANDI	ae52ce2c-19e6-4a62-9081-1185b515af53	\N	2026-03-22 06:26:52.635009+00
0354e36e-a257-44c3-b09e-9ce5db755f35	12	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	YETKAZILDI	49ff00e4-1838-4106-849d-4a00256d1241	\N	2026-03-22 06:33:36.7937+00
b020b128-6472-4506-af1d-0c8d816d2d2b	15	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	YANGI	b89bc16d-45c3-4ae7-921e-a095cb04f0c9	\N	2026-03-22 07:45:33.628712+00
6616853a-2fdf-4a6e-8846-3b2c7cdaad69	16	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	YANGI	ae52ce2c-19e6-4a62-9081-1185b515af53	\N	2026-03-24 13:01:04.653274+00
9415bdb0-b971-48c7-8447-f85bfa539aa6	16	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	TAYINLANDI	ae52ce2c-19e6-4a62-9081-1185b515af53	\N	2026-03-24 13:01:26.853209+00
8a01dba0-7948-44d3-a8c1-29883da92b0d	17	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	YANGI	ae52ce2c-19e6-4a62-9081-1185b515af53	\N	2026-03-26 08:28:29.031085+00
68c26789-ce04-4e21-b7cf-737b45299aeb	17	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	TAYINLANDI	ae52ce2c-19e6-4a62-9081-1185b515af53	\N	2026-03-26 08:28:40.896819+00
49d3096b-d53d-444c-a1cd-99cc01915533	18	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	YANGI	b89bc16d-45c3-4ae7-921e-a095cb04f0c9	\N	2026-03-26 08:49:26.154921+00
39da3657-13d4-46da-9778-cc8db5550ee6	19	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	YANGI	b89bc16d-45c3-4ae7-921e-a095cb04f0c9	\N	2026-03-26 08:49:52.499543+00
3f4522f4-e7cf-4ee1-856f-cf78191f8b3e	20	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	YANGI	ae52ce2c-19e6-4a62-9081-1185b515af53	\N	2026-03-27 11:16:37.183215+00
765cd473-3026-4e61-87bc-0c434fd093a9	21	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	YANGI	ae52ce2c-19e6-4a62-9081-1185b515af53	\N	2026-03-27 11:19:28.202675+00
6fe7c1ea-c9e4-4359-9ab0-946656782b9b	21	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	TAYINLANDI	ae52ce2c-19e6-4a62-9081-1185b515af53	\N	2026-03-27 11:19:33.17537+00
a1518311-eaf1-4f3f-ae5a-6fef8668a46c	20	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	TAYINLANDI	ae52ce2c-19e6-4a62-9081-1185b515af53	\N	2026-03-27 11:22:20.500477+00
8d70d6ac-fb9f-47a5-8e3e-48176b572a4f	19	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	TAYINLANDI	ae52ce2c-19e6-4a62-9081-1185b515af53	\N	2026-03-28 13:52:29.818622+00
fea0aebf-a838-4366-982c-a47abf5727cb	22	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	YANGI	757d7d23-af87-4de8-87c9-ee21bcf87b93	\N	2026-03-28 14:02:46.875363+00
09b46bac-2e7c-4a2a-a302-44f677270d14	22	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	TAYINLANDI	ae52ce2c-19e6-4a62-9081-1185b515af53	\N	2026-03-28 14:03:07.057843+00
1493b57b-6a66-4196-b588-a44c5e414b79	22	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	YETKAZILDI	d23f6f14-c3fb-4337-80cb-d9929518d9fb	\N	2026-03-28 14:04:10.537478+00
aae384b6-50d6-4e56-9f5c-454deb7e0978	18	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	TAYINLANDI	ae52ce2c-19e6-4a62-9081-1185b515af53	\N	2026-03-29 04:05:15.452776+00
9db6f638-d656-4154-8c1d-cbdf263c7c90	15	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	TAYINLANDI	ae52ce2c-19e6-4a62-9081-1185b515af53	\N	2026-03-29 04:05:23.451334+00
d746318f-a345-4e92-827c-265b3eeef408	10	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	TAYINLANDI	ae52ce2c-19e6-4a62-9081-1185b515af53	\N	2026-03-29 04:05:29.624529+00
ac30dfac-1aca-4bed-bbb9-e4ecfe0233a4	10	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	YETKAZILDI	757d7d23-af87-4de8-87c9-ee21bcf87b93	\N	2026-03-29 04:05:59.496988+00
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orders (id, tenant_id, client_id, courier_id, address_id, status, payment_status, payment_method, total_amount, paid_amount, debt_amount, containers_delivered, containers_returned, comment, cancel_reason, problem_reason, is_phone_order, delivered_at, created_at, updated_at, cash_amount, card_amount, contact_phone) FROM stdin;
9	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	2e40a458-c6b6-4c41-bb79-f2ae224decc0	0f177107-8b39-4bcb-b914-5445c00ac6ee	77de7759-8d96-4afc-b7f4-d1c27def9a5d	YETKAZILDI	QISMAN	NAQD	40000	30000	10000	3	0	\N	\N	\N	f	2026-03-21 19:05:40.834914+00	2026-03-21 08:52:34.185373+00	2026-03-21 19:05:40.820797+00	20000	10000	\N
11	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	1f762413-3dc4-4c89-9e3c-a34ca4fbba99	0f177107-8b39-4bcb-b914-5445c00ac6ee	e19eb946-586d-43a7-b01a-8f019ccb6fab	YETKAZILDI	TOLANGAN	NAQD	125000	125000	0	0	0	\N	\N	\N	t	2026-03-21 18:42:34.021254+00	2026-03-21 09:04:07.621144+00	2026-03-21 18:42:34.015242+00	125000	0	\N
13	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	2e40a458-c6b6-4c41-bb79-f2ae224decc0	0f177107-8b39-4bcb-b914-5445c00ac6ee	9c4df195-5873-4fa3-bfae-4c9e47f1fe44	TAYINLANDI	TOLANMAGAN	\N	75000	0	0	0	0	\N	\N	\N	t	\N	2026-03-22 05:24:58.844378+00	2026-03-22 05:25:06.454147+00	0	0	\N
14	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	70c5b358-66d5-401b-b4d7-231e4aef297a	0f177107-8b39-4bcb-b914-5445c00ac6ee	6dc93b2a-a65e-4b54-b2cb-e994473b8b01	TAYINLANDI	TOLANMAGAN	\N	20000	0	0	0	0	6fan kryin	\N	\N	f	\N	2026-03-22 06:25:05.203149+00	2026-03-22 06:26:52.635009+00	0	0	\N
12	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	aec3e0a9-01b1-4bf2-91ec-4655c3f5c77c	0f177107-8b39-4bcb-b914-5445c00ac6ee	af4daa50-db82-4c45-b23d-770601f6ba7c	YETKAZILDI	QISMAN	NAQD	10000	8000	2000	1	1	\N	\N	\N	t	2026-03-22 06:33:36.801469+00	2026-03-22 05:16:23.022417+00	2026-03-22 06:33:36.7937+00	4000	4000	\N
16	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	88098c0c-44ba-4c51-899f-9fd58dd4277c	0f177107-8b39-4bcb-b914-5445c00ac6ee	0597d7dc-f03c-45c1-bdc3-3036cb8c70da	TAYINLANDI	TOLANMAGAN	\N	35000	0	0	0	0	\N	\N	\N	t	\N	2026-03-24 13:01:04.653274+00	2026-03-24 13:01:26.853209+00	0	0	\N
17	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	70c5b358-66d5-401b-b4d7-231e4aef297a	0f177107-8b39-4bcb-b914-5445c00ac6ee	3ba78587-c6fc-40ab-945d-47dcbf6f97c3	TAYINLANDI	TOLANMAGAN	\N	5000000	0	0	0	0	\N	\N	\N	t	\N	2026-03-26 08:28:29.031085+00	2026-03-26 08:28:40.896819+00	0	0	\N
21	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	aec3e0a9-01b1-4bf2-91ec-4655c3f5c77c	0f177107-8b39-4bcb-b914-5445c00ac6ee	358e1f85-0f97-420e-b8d6-bb7d6b559bf0	TAYINLANDI	TOLANMAGAN	\N	120000	0	0	0	0	\N	\N	\N	t	\N	2026-03-27 11:19:28.202675+00	2026-03-27 11:19:33.17537+00	0	0	\N
20	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	db638bc6-c733-4122-9dc2-8a3f70453c76	82445b20-963b-433b-b452-d70935033042	3ad4c99a-456d-4fa3-86ca-f0eb5c6a4fe6	TAYINLANDI	TOLANMAGAN	\N	100000	0	0	0	0	\N	\N	\N	t	\N	2026-03-27 11:16:37.183215+00	2026-03-27 11:22:20.500477+00	0	0	\N
10	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	88098c0c-44ba-4c51-899f-9fd58dd4277c	82445b20-963b-433b-b452-d70935033042	\N	YETKAZILDI	TOLANGAN	NAQD	50000	50000	0	5	0	\N	\N	\N	t	2026-03-29 04:05:59.514382+00	2026-03-21 08:54:21.456167+00	2026-03-29 04:05:59.496988+00	50000	0	\N
19	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	df821ea1-c28c-411a-b9b0-8b16f11979bf	6adef115-693e-422a-a94c-b774ea98141a	b7f15715-2e17-4172-a187-c8bfa6924866	TAYINLANDI	TOLANMAGAN	\N	5092000	0	0	0	0	\N	\N	\N	f	\N	2026-03-26 08:49:52.499543+00	2026-03-28 13:52:29.818622+00	0	0	95 555 66 44
22	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	db638bc6-c733-4122-9dc2-8a3f70453c76	6adef115-693e-422a-a94c-b774ea98141a	32ec0b97-9f96-4e00-b396-7d9eb3fe42f9	YETKAZILDI	TOLANGAN	NAQD	300000	300000	0	30	0	\N	\N	\N	f	2026-03-28 14:04:10.548609+00	2026-03-28 14:02:46.875363+00	2026-03-28 14:04:10.537478+00	300000	0	90 015 77 75
18	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	df821ea1-c28c-411a-b9b0-8b16f11979bf	82445b20-963b-433b-b452-d70935033042	b7f15715-2e17-4172-a187-c8bfa6924866	TAYINLANDI	TOLANMAGAN	\N	5095000	0	0	0	0	\N	\N	\N	f	\N	2026-03-26 08:49:26.154921+00	2026-03-29 04:05:15.452776+00	0	0	98 252 62 22
15	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	df821ea1-c28c-411a-b9b0-8b16f11979bf	82445b20-963b-433b-b452-d70935033042	b7f15715-2e17-4172-a187-c8bfa6924866	TAYINLANDI	TOLANMAGAN	\N	24000	0	0	0	0	\N	\N	\N	f	\N	2026-03-22 07:45:33.628712+00	2026-03-29 04:05:23.451334+00	0	0	\N
\.


--
-- Data for Name: price_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.price_history (id, product_id, tenant_id, old_price, new_price, changed_by_id, changed_at) FROM stdin;
5ac8f9e8-f6f7-4f9d-9262-914bc78f8dd0	82725c10-d3e4-48cd-b6df-c881652fe0f8	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	7000	8000	ae52ce2c-19e6-4a62-9081-1185b515af53	2026-03-26 12:46:12.533994+00
0631550d-88dc-437c-a7e9-377a5661a247	878bdc5d-fb6e-40c4-b2ba-4a4c65073e78	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	5000	6000	ae52ce2c-19e6-4a62-9081-1185b515af53	2026-03-26 12:46:30.682041+00
d81e4f5f-a9ce-4518-9afd-14dfd8dc3a29	0ee9ecf5-334c-48cb-921c-448da04c0a69	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	70000	1200000	ae52ce2c-19e6-4a62-9081-1185b515af53	2026-03-26 12:46:52.545747+00
5b4d38e5-75be-4c59-9a8a-c403f8327527	31c66e15-1101-4a40-b40a-4a42839f2ccc	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	5000000	50000	ae52ce2c-19e6-4a62-9081-1185b515af53	2026-03-28 13:49:00.324293+00
17393401-ba15-4f0b-82db-33dfea1fe87c	31c66e15-1101-4a40-b40a-4a42839f2ccc	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	50000	5000000	ae52ce2c-19e6-4a62-9081-1185b515af53	2026-03-28 13:58:28.078642+00
f1343887-103c-440b-93c8-6a9dac49bcc2	82725c10-d3e4-48cd-b6df-c881652fe0f8	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	8000	7000	ae52ce2c-19e6-4a62-9081-1185b515af53	2026-03-28 13:58:56.700175+00
aaf63387-7490-4856-89a4-585bea86ee09	878bdc5d-fb6e-40c4-b2ba-4a4c65073e78	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	6000	5000	ae52ce2c-19e6-4a62-9081-1185b515af53	2026-03-28 13:59:21.095239+00
589cf6ef-c6a3-4dfe-9582-9e35866b33ad	82725c10-d3e4-48cd-b6df-c881652fe0f8	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	7000	8000	ae52ce2c-19e6-4a62-9081-1185b515af53	2026-03-30 08:28:23.272572+00
cc4350ed-956f-4e1e-8b39-c2e1c10834f5	878bdc5d-fb6e-40c4-b2ba-4a4c65073e78	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	5000	6000	ae52ce2c-19e6-4a62-9081-1185b515af53	2026-03-30 08:29:36.402341+00
\.


--
-- Data for Name: product_categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_categories (id, tenant_id, name, icon, sort_order, created_at, updated_at) FROM stdin;
18946cf2-cab7-4639-88fd-0dddb8d5a2e9	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	Su ballonlari	\N	0	2026-03-18 18:29:12.876894+00	2026-03-18 18:29:12.876894+00
c82ebfdb-9b84-475b-b4d3-7b8e12762290	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	suv	\N	0	2026-03-18 18:30:33.588757+00	2026-03-18 18:30:33.588757+00
c463cda2-53dc-40e2-897d-14e30834ecea	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	Himolay	\N	0	2026-03-27 11:30:42.419149+00	2026-03-27 11:30:42.419149+00
da67a857-8434-4797-ba2e-9abf8fc789b0	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	ako	\N	0	2026-03-29 02:20:29.591873+00	2026-03-29 02:20:29.591873+00
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.products (id, tenant_id, category_id, name, description, image_url, price, volume, volume_unit, is_returnable_container, is_active, sort_order, created_at, updated_at, container_product_id, containers_per_unit, inactive_threshold_days, show_to_clients, is_deleted) FROM stdin;
3b30efd1-cbc1-4d46-b5ed-6537c9b7118e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	18946cf2-cab7-4639-88fd-0dddb8d5a2e9	18.9 литра	\N	/uploads/products/87258f95-6314-48c5-af0c-fb1935f3fab4.png	10000	18	\N	t	t	0	2026-03-21 08:50:10.509534+00	2026-03-27 11:12:33.974449+00	\N	1	15	t	f
31c66e15-1101-4a40-b40a-4a42839f2ccc	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	pompa	\N	\N	5000000	\N	\N	f	t	0	2026-03-26 08:08:36.283067+00	2026-03-28 13:58:28.078642+00	\N	1	30	t	f
0ee9ecf5-334c-48cb-921c-448da04c0a69	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	кулер	\N	/uploads/products/df4d6cd5-1bb4-450f-aac4-9623c00e9696.png	1200000	\N	\N	f	f	0	2026-03-22 05:25:51.611142+00	2026-03-29 06:13:20.827911+00	\N	1	30	t	t
82725c10-d3e4-48cd-b6df-c881652fe0f8	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	c82ebfdb-9b84-475b-b4d3-7b8e12762290	10 литр	\N	/uploads/products/b5122a1f-1833-4ca8-b040-bdc598d42a28.png	8000	10	\N	f	t	0	2026-03-22 05:17:46.503268+00	2026-03-30 08:29:02.803471+00	\N	1	30	t	f
878bdc5d-fb6e-40c4-b2ba-4a4c65073e78	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	18946cf2-cab7-4639-88fd-0dddb8d5a2e9	5 литр	\N	/uploads/products/d858f037-30ef-4a60-a4ae-4482db300aed.png	6000	5	\N	f	t	0	2026-03-21 06:44:31.759137+00	2026-03-30 08:29:36.402341+00	\N	1	30	t	f
\.


--
-- Data for Name: regions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.regions (id, tenant_id, name_uz, name_uz_cyrillic, name_ru, is_active, sort_order, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.settings (id, tenant_id, company_name, logo_url, bot_token, work_start_hour, work_end_hour, inactive_client_days, extra_json) FROM stdin;
b01bfcbc-1032-47c4-82a9-1b15a7d50e1e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	\N	\N	8	22	30	\N
\.


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tenants (id, name, slug, logo_url, bot_token, is_active, settings, created_at, updated_at) FROM stdin;
0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	SuvPro Demo	suvpro	\N	\N	t	\N	2026-03-18 16:04:43.648204+00	2026-03-18 16:04:43.648204+00
\.


--
-- Data for Name: treasury_transactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.treasury_transactions (id, tenant_id, order_id, created_by_id, transaction_type, category, amount, payment_method, description, transaction_date) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, tenant_id, telegram_id, telegram_username, first_name, last_name, phone, role, hashed_password, is_active, is_phone_verified, bot_blocked, language, created_at, updated_at, cash_balance, card_balance) FROM stdin;
abadd210-693e-4193-b2c0-2f31132c0e08	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	1028958055	\N	Qodirov	\N	+998900157775	CLIENT	\N	t	t	f	uz	2026-03-22 06:24:11.146652+00	2026-03-22 06:24:11.146652+00	0	0
ae52ce2c-19e6-4a62-9081-1185b515af53	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	\N	Admin	SuvPro	998901234567	SUPER_ADMIN	$2b$12$JK6tNkOfSEP7suZjAYo3XeFKVnW14k7slrtssiVjPbty5LqGEMGgC	t	t	f	uz	2026-03-18 16:04:43.648204+00	2026-03-18 16:04:43.648204+00	0	0
ecf1ebec-0714-43c5-a881-4c47a7cec52b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	\N	Сардор	Каримов	+998 99 999 88 77	COURIER	\N	t	f	f	uz	2026-03-26 08:16:08.214794+00	2026-03-26 08:16:08.214794+00	0	0
2bc91495-9590-46d3-9730-db037c942f5b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	\N	Юмитова Юлдуз.	\N	+998973231310	CLIENT	\N	f	t	f	uz	2026-03-21 08:52:05.071799+00	2026-03-30 07:31:45.047953+00	0	0
b89bc16d-45c3-4ae7-921e-a095cb04f0c9	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	Rasuljon_Melixanov	Rasuljon	Melixanov	+998975590068	CLIENT	\N	f	t	f	ru	2026-03-19 08:03:26.429458+00	2026-03-30 07:32:23.088798+00	0	0
aff8390a-3a31-4f3e-8364-a7a8b2d667e3	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	\N	dfdf	dfdf	dfdf	COURIER	\N	f	f	f	uz	2026-03-26 08:28:59.413426+00	2026-03-30 07:32:34.350652+00	0	0
e6babbdd-1df1-44ba-a38e-d5227c335b50	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	1834336339	\N	Akobir	Qodirov	+998905005030	COURIER	$2b$12$PFRuxQ1skZ4a.WdFxXKhCerng2b/cPLZBR2jfCSS5wt6.n.blrnMy	t	t	f	uz	2026-03-30 07:25:28.500434+00	2026-03-30 07:35:25.770935+00	0	0
1078b015-3922-4283-94f6-be7629c9371a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	7638928608	\N	zaripov_o17	\N	+998770357032	COURIER	\N	t	t	f	uz	2026-03-27 11:38:06.864048+00	2026-03-28 09:18:53.067945+00	0	0
d23f6f14-c3fb-4337-80cb-d9929518d9fb	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	5358138651	\N	Strong water	\N	+998997555516	COURIER	\N	t	t	f	uz	2026-03-28 13:50:43.730783+00	2026-03-28 13:51:34.603141+00	0	0
757d7d23-af87-4de8-87c9-ee21bcf87b93	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	985937565	Himalaywater	HIMALAY	\N	+998913373937	CLIENT	\N	t	t	f	uz	2026-03-26 01:39:17.385351+00	2026-03-28 14:01:42.887542+00	0	0
49ff00e4-1838-4106-849d-4a00256d1241	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	7628815246	Prooudmoore	Бехруз	Хайриллоев	+998937570731	OPERATOR	$2b$12$HDAlrvHKahHr1NqXMKc3fuR6WYR/yS//CkIdT33amgsD3vyoPPAse	t	t	f	ru	2026-03-18 18:10:36.934887+00	2026-03-29 11:53:33.198676+00	0	0
\.


--
-- Data for Name: warehouse_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.warehouse_items (id, tenant_id, product_id, name, unit, is_container, is_full, low_threshold, out_threshold, created_at, updated_at) FROM stdin;
89f9673b-ee10-4a89-9814-8c861351348e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	878bdc5d-fb6e-40c4-b2ba-4a4c65073e78	5 литр	ta	f	t	50	10	2026-03-21 09:07:31.157716+00	2026-03-21 09:07:31.157716+00
ffd12d17-a421-4b7e-8f6c-67494b512c13	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	3b30efd1-cbc1-4d46-b5ed-6537c9b7118e	18.9 литра	ta	t	t	50	10	2026-03-21 09:07:31.157716+00	2026-03-21 09:07:31.157716+00
fd5e6690-0ecb-4acd-aac2-4c93d220fa60	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	82725c10-d3e4-48cd-b6df-c881652fe0f8	10 литр	ta	f	t	50	10	2026-03-22 05:17:46.503268+00	2026-03-22 05:17:46.503268+00
f44b162b-73d2-47c8-bb95-90ea927eccfb	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	0ee9ecf5-334c-48cb-921c-448da04c0a69	кулер	ta	f	t	50	10	2026-03-22 05:25:51.611142+00	2026-03-22 05:25:51.611142+00
1466f481-bc34-4ac5-b0a4-8ff3bb44f887	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	31c66e15-1101-4a40-b40a-4a42839f2ccc	pompa	ta	f	t	50	10	2026-03-26 08:08:36.283067+00	2026-03-26 08:08:36.283067+00
\.


--
-- Data for Name: warehouse_stock; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.warehouse_stock (id, tenant_id, item_id, quantity, empty_quantity) FROM stdin;
93adffce-ceaa-4fa7-aa40-6ea116bda039	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	fd5e6690-0ecb-4acd-aac2-4c93d220fa60	98	0
52abb623-ca69-4140-8f0d-ae29605aea92	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	89f9673b-ee10-4a89-9814-8c861351348e	271	0
c0d38039-0139-4e44-8ed2-b82dc8f45661	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	ffd12d17-a421-4b7e-8f6c-67494b512c13	709	3351
665bffb7-9ea5-4c01-aea0-4cbaada5f3a8	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	f44b162b-73d2-47c8-bb95-90ea927eccfb	0	0
70e7e53c-8af4-40e7-b6a8-05c9bf199f39	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	1466f481-bc34-4ac5-b0a4-8ff3bb44f887	0	0
\.


--
-- Data for Name: warehouse_transactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.warehouse_transactions (id, tenant_id, item_id, order_id, courier_id, created_by_id, transaction_type, quantity, balance_before, balance_after, note, created_at) FROM stdin;
e302c3b0-6c33-4fff-8fc9-6e160c8572b6	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	ffd12d17-a421-4b7e-8f6c-67494b512c13	\N	\N	ae52ce2c-19e6-4a62-9081-1185b515af53	KIRIM	500	0	500	Bo'sh tara kirim	2026-03-21 18:40:54.70179+00
358993ca-c509-4a92-af55-e5d821887b4c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	ffd12d17-a421-4b7e-8f6c-67494b512c13	\N	\N	ae52ce2c-19e6-4a62-9081-1185b515af53	KIRIM	100	0	100	\N	2026-03-21 18:40:58.074203+00
262ac7e3-2bf2-40e4-b5c6-8332315f3c50	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	89f9673b-ee10-4a89-9814-8c861351348e	\N	\N	ae52ce2c-19e6-4a62-9081-1185b515af53	KIRIM	100	0	100	\N	2026-03-21 18:41:01.21147+00
5336b568-19b2-4d56-aab6-622c386b0ebf	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	ffd12d17-a421-4b7e-8f6c-67494b512c13	\N	\N	ae52ce2c-19e6-4a62-9081-1185b515af53	KIRIM	100	400	500	Bo'sh tara kirim	2026-03-22 05:26:28.24191+00
d1518b2f-5a04-41ec-ba9f-532cd5fa2547	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	ffd12d17-a421-4b7e-8f6c-67494b512c13	\N	\N	ae52ce2c-19e6-4a62-9081-1185b515af53	KIRIM	300	67	367	\N	2026-03-22 05:26:32.414946+00
85d8abf4-d18e-428f-b623-cc4e03d56643	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	89f9673b-ee10-4a89-9814-8c861351348e	\N	\N	ae52ce2c-19e6-4a62-9081-1185b515af53	KIRIM	200	73	273	\N	2026-03-22 05:26:37.358242+00
df72afef-4691-4c69-82bd-09a68303ca12	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	fd5e6690-0ecb-4acd-aac2-4c93d220fa60	\N	\N	ae52ce2c-19e6-4a62-9081-1185b515af53	KIRIM	100	0	100	\N	2026-03-22 05:26:41.244096+00
60e59d12-cc67-40b4-a3aa-9a394a30f6e4	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	ffd12d17-a421-4b7e-8f6c-67494b512c13	12	\N	\N	KIRIM	1	200	201	Buyurtma #12 - mijoz pust tara qaytardi	2026-03-22 06:33:36.7937+00
5bdfc74a-e37c-44b8-8991-370a59b0350d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	ffd12d17-a421-4b7e-8f6c-67494b512c13	\N	\N	ae52ce2c-19e6-4a62-9081-1185b515af53	KIRIM	100	396	496	\N	2026-03-24 13:07:04.285027+00
fe3bd4b3-16b2-4b85-9c58-c336fda20064	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	ffd12d17-a421-4b7e-8f6c-67494b512c13	\N	\N	ae52ce2c-19e6-4a62-9081-1185b515af53	KIRIM	500	101	601	Bo'sh tara kirim	2026-03-24 13:07:13.900528+00
14f16577-fdbf-4502-b5e0-afffc4e7678c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	1466f481-bc34-4ac5-b0a4-8ff3bb44f887	\N	\N	ae52ce2c-19e6-4a62-9081-1185b515af53	KIRIM	50	0	50	\N	2026-03-26 08:24:29.788023+00
a23a06bc-5f53-47cc-aa27-8b126a621a78	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	f44b162b-73d2-47c8-bb95-90ea927eccfb	\N	\N	ae52ce2c-19e6-4a62-9081-1185b515af53	KIRIM	2	0	2	Weelstar	2026-03-29 02:15:32.311796+00
09d1edbb-4db3-4a38-b6a4-5898fd06f0ce	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	ffd12d17-a421-4b7e-8f6c-67494b512c13	\N	\N	ae52ce2c-19e6-4a62-9081-1185b515af53	KIRIM	250	459	709	Yangi	2026-03-29 02:16:38.63992+00
8612ba60-23c2-4c86-bce3-4f13595cb7a9	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	ffd12d17-a421-4b7e-8f6c-67494b512c13	\N	\N	ae52ce2c-19e6-4a62-9081-1185b515af53	KIRIM	3000	351	3351	Bo'sh tara kirim	2026-03-29 02:16:53.217474+00
bfcff4a2-2e07-4d9b-b2a1-fe5ef219c912	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	1466f481-bc34-4ac5-b0a4-8ff3bb44f887	\N	\N	ae52ce2c-19e6-4a62-9081-1185b515af53	CHIQIM	48	48	0	\N	2026-03-29 11:17:18.505597+00
\.


--
-- Name: orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.orders_id_seq', 22, true);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: client_addresses client_addresses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client_addresses
    ADD CONSTRAINT client_addresses_pkey PRIMARY KEY (id);


--
-- Name: client_groups client_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client_groups
    ADD CONSTRAINT client_groups_pkey PRIMARY KEY (id);


--
-- Name: clients clients_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_pkey PRIMARY KEY (id);


--
-- Name: container_client_balance container_client_balance_client_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.container_client_balance
    ADD CONSTRAINT container_client_balance_client_id_key UNIQUE (client_id);


--
-- Name: container_client_balance container_client_balance_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.container_client_balance
    ADD CONSTRAINT container_client_balance_pkey PRIMARY KEY (id);


--
-- Name: container_transactions container_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.container_transactions
    ADD CONSTRAINT container_transactions_pkey PRIMARY KEY (id);


--
-- Name: courier_balance_log courier_balance_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.courier_balance_log
    ADD CONSTRAINT courier_balance_log_pkey PRIMARY KEY (id);


--
-- Name: courier_cash_collections courier_cash_collections_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.courier_cash_collections
    ADD CONSTRAINT courier_cash_collections_pkey PRIMARY KEY (id);


--
-- Name: courier_inventory courier_inventory_courier_id_product_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.courier_inventory
    ADD CONSTRAINT courier_inventory_courier_id_product_id_key UNIQUE (courier_id, product_id);


--
-- Name: courier_inventory courier_inventory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.courier_inventory
    ADD CONSTRAINT courier_inventory_pkey PRIMARY KEY (id);


--
-- Name: couriers couriers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.couriers
    ADD CONSTRAINT couriers_pkey PRIMARY KEY (id);


--
-- Name: debt_transactions debt_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.debt_transactions
    ADD CONSTRAINT debt_transactions_pkey PRIMARY KEY (id);


--
-- Name: debts debts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.debts
    ADD CONSTRAINT debts_pkey PRIMARY KEY (id);


--
-- Name: notifications_log notifications_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_log
    ADD CONSTRAINT notifications_log_pkey PRIMARY KEY (id);


--
-- Name: operator_cash_submissions operator_cash_submissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.operator_cash_submissions
    ADD CONSTRAINT operator_cash_submissions_pkey PRIMARY KEY (id);


--
-- Name: order_items order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_pkey PRIMARY KEY (id);


--
-- Name: order_status_history order_status_history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_status_history
    ADD CONSTRAINT order_status_history_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: price_history price_history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.price_history
    ADD CONSTRAINT price_history_pkey PRIMARY KEY (id);


--
-- Name: product_categories product_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_categories
    ADD CONSTRAINT product_categories_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: regions regions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.regions
    ADD CONSTRAINT regions_pkey PRIMARY KEY (id);


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (id);


--
-- Name: settings settings_tenant_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_tenant_id_key UNIQUE (tenant_id);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_slug_key UNIQUE (slug);


--
-- Name: treasury_transactions treasury_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.treasury_transactions
    ADD CONSTRAINT treasury_transactions_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_telegram_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_telegram_id_key UNIQUE (telegram_id);


--
-- Name: warehouse_items warehouse_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouse_items
    ADD CONSTRAINT warehouse_items_pkey PRIMARY KEY (id);


--
-- Name: warehouse_stock warehouse_stock_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouse_stock
    ADD CONSTRAINT warehouse_stock_pkey PRIMARY KEY (id);


--
-- Name: warehouse_transactions warehouse_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouse_transactions
    ADD CONSTRAINT warehouse_transactions_pkey PRIMARY KEY (id);


--
-- Name: idx_courier_cash_collections_courier; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_courier_cash_collections_courier ON public.courier_cash_collections USING btree (courier_id);


--
-- Name: idx_courier_cash_collections_tenant; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_courier_cash_collections_tenant ON public.courier_cash_collections USING btree (tenant_id);


--
-- Name: idx_courier_inventory_courier; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_courier_inventory_courier ON public.courier_inventory USING btree (courier_id);


--
-- Name: idx_courier_inventory_full; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_courier_inventory_full ON public.courier_inventory USING btree (courier_id, product_id, quantity);


--
-- Name: idx_courier_inventory_product; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_courier_inventory_product ON public.courier_inventory USING btree (product_id);


--
-- Name: idx_orders_tenant_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_orders_tenant_status ON public.orders USING btree (tenant_id, status);


--
-- Name: ix_audit_log_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_audit_log_tenant_id ON public.audit_log USING btree (tenant_id);


--
-- Name: ix_client_addresses_client_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_client_addresses_client_id ON public.client_addresses USING btree (client_id);


--
-- Name: ix_client_groups_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_client_groups_tenant_id ON public.client_groups USING btree (tenant_id);


--
-- Name: ix_clients_group_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_clients_group_id ON public.clients USING btree (group_id);


--
-- Name: ix_clients_phone; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_clients_phone ON public.clients USING btree (phone);


--
-- Name: ix_clients_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_clients_tenant_id ON public.clients USING btree (tenant_id);


--
-- Name: ix_container_transactions_client_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_container_transactions_client_id ON public.container_transactions USING btree (client_id);


--
-- Name: ix_courier_balance_log_courier_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_courier_balance_log_courier_id ON public.courier_balance_log USING btree (courier_id);


--
-- Name: ix_couriers_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_couriers_tenant_id ON public.couriers USING btree (tenant_id);


--
-- Name: ix_debt_transactions_client_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_debt_transactions_client_id ON public.debt_transactions USING btree (client_id);


--
-- Name: ix_debts_client_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_debts_client_id ON public.debts USING btree (client_id);


--
-- Name: ix_debts_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_debts_tenant_id ON public.debts USING btree (tenant_id);


--
-- Name: ix_operator_cash_submissions_operator_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_operator_cash_submissions_operator_id ON public.operator_cash_submissions USING btree (operator_id);


--
-- Name: ix_operator_cash_submissions_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_operator_cash_submissions_tenant_id ON public.operator_cash_submissions USING btree (tenant_id);


--
-- Name: ix_order_items_order_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_order_items_order_id ON public.order_items USING btree (order_id);


--
-- Name: ix_order_status_history_order_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_order_status_history_order_id ON public.order_status_history USING btree (order_id);


--
-- Name: ix_orders_client_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_orders_client_id ON public.orders USING btree (client_id);


--
-- Name: ix_orders_courier_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_orders_courier_id ON public.orders USING btree (courier_id);


--
-- Name: ix_orders_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_orders_status ON public.orders USING btree (status);


--
-- Name: ix_orders_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_orders_tenant_id ON public.orders USING btree (tenant_id);


--
-- Name: ix_price_history_product_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_price_history_product_id ON public.price_history USING btree (product_id);


--
-- Name: ix_products_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_products_tenant_id ON public.products USING btree (tenant_id);


--
-- Name: ix_regions_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_regions_tenant_id ON public.regions USING btree (tenant_id);


--
-- Name: ix_treasury_transactions_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_treasury_transactions_tenant_id ON public.treasury_transactions USING btree (tenant_id);


--
-- Name: ix_users_phone; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_users_phone ON public.users USING btree (phone);


--
-- Name: ix_users_telegram_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_users_telegram_id ON public.users USING btree (telegram_id);


--
-- Name: ix_warehouse_stock_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_warehouse_stock_tenant_id ON public.warehouse_stock USING btree (tenant_id);


--
-- Name: ix_warehouse_transactions_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_warehouse_transactions_tenant_id ON public.warehouse_transactions USING btree (tenant_id);


--
-- Name: audit_log audit_log_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: audit_log audit_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: client_addresses client_addresses_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client_addresses
    ADD CONSTRAINT client_addresses_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: client_addresses client_addresses_region_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client_addresses
    ADD CONSTRAINT client_addresses_region_id_fkey FOREIGN KEY (region_id) REFERENCES public.regions(id) ON DELETE SET NULL;


--
-- Name: client_addresses client_addresses_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client_addresses
    ADD CONSTRAINT client_addresses_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: client_groups client_groups_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client_groups
    ADD CONSTRAINT client_groups_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: clients clients_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: clients clients_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: container_client_balance container_client_balance_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.container_client_balance
    ADD CONSTRAINT container_client_balance_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: container_client_balance container_client_balance_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.container_client_balance
    ADD CONSTRAINT container_client_balance_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: container_transactions container_transactions_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.container_transactions
    ADD CONSTRAINT container_transactions_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: container_transactions container_transactions_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.container_transactions
    ADD CONSTRAINT container_transactions_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: container_transactions container_transactions_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.container_transactions
    ADD CONSTRAINT container_transactions_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE SET NULL;


--
-- Name: container_transactions container_transactions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.container_transactions
    ADD CONSTRAINT container_transactions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: courier_balance_log courier_balance_log_courier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.courier_balance_log
    ADD CONSTRAINT courier_balance_log_courier_id_fkey FOREIGN KEY (courier_id) REFERENCES public.couriers(id) ON DELETE CASCADE;


--
-- Name: courier_balance_log courier_balance_log_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.courier_balance_log
    ADD CONSTRAINT courier_balance_log_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE SET NULL;


--
-- Name: courier_balance_log courier_balance_log_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.courier_balance_log
    ADD CONSTRAINT courier_balance_log_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: courier_cash_collections courier_cash_collections_collected_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.courier_cash_collections
    ADD CONSTRAINT courier_cash_collections_collected_by_id_fkey FOREIGN KEY (collected_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: courier_cash_collections courier_cash_collections_courier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.courier_cash_collections
    ADD CONSTRAINT courier_cash_collections_courier_id_fkey FOREIGN KEY (courier_id) REFERENCES public.couriers(id) ON DELETE CASCADE;


--
-- Name: courier_cash_collections courier_cash_collections_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.courier_cash_collections
    ADD CONSTRAINT courier_cash_collections_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: courier_inventory courier_inventory_courier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.courier_inventory
    ADD CONSTRAINT courier_inventory_courier_id_fkey FOREIGN KEY (courier_id) REFERENCES public.couriers(id) ON DELETE CASCADE;


--
-- Name: courier_inventory courier_inventory_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.courier_inventory
    ADD CONSTRAINT courier_inventory_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: courier_inventory courier_inventory_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.courier_inventory
    ADD CONSTRAINT courier_inventory_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: couriers couriers_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.couriers
    ADD CONSTRAINT couriers_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: couriers couriers_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.couriers
    ADD CONSTRAINT couriers_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: debt_transactions debt_transactions_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.debt_transactions
    ADD CONSTRAINT debt_transactions_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: debt_transactions debt_transactions_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.debt_transactions
    ADD CONSTRAINT debt_transactions_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: debt_transactions debt_transactions_debt_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.debt_transactions
    ADD CONSTRAINT debt_transactions_debt_id_fkey FOREIGN KEY (debt_id) REFERENCES public.debts(id) ON DELETE CASCADE;


--
-- Name: debt_transactions debt_transactions_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.debt_transactions
    ADD CONSTRAINT debt_transactions_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE SET NULL;


--
-- Name: debt_transactions debt_transactions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.debt_transactions
    ADD CONSTRAINT debt_transactions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: debts debts_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.debts
    ADD CONSTRAINT debts_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: debts debts_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.debts
    ADD CONSTRAINT debts_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: debts debts_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.debts
    ADD CONSTRAINT debts_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: clients fk_clients_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT fk_clients_group_id FOREIGN KEY (group_id) REFERENCES public.client_groups(id) ON DELETE SET NULL;


--
-- Name: notifications_log notifications_log_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_log
    ADD CONSTRAINT notifications_log_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE SET NULL;


--
-- Name: notifications_log notifications_log_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_log
    ADD CONSTRAINT notifications_log_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: notifications_log notifications_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_log
    ADD CONSTRAINT notifications_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: operator_cash_submissions operator_cash_submissions_collected_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.operator_cash_submissions
    ADD CONSTRAINT operator_cash_submissions_collected_by_id_fkey FOREIGN KEY (collected_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: operator_cash_submissions operator_cash_submissions_operator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.operator_cash_submissions
    ADD CONSTRAINT operator_cash_submissions_operator_id_fkey FOREIGN KEY (operator_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: operator_cash_submissions operator_cash_submissions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.operator_cash_submissions
    ADD CONSTRAINT operator_cash_submissions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: order_items order_items_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: order_items order_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE RESTRICT;


--
-- Name: order_items order_items_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: order_status_history order_status_history_changed_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_status_history
    ADD CONSTRAINT order_status_history_changed_by_id_fkey FOREIGN KEY (changed_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: order_status_history order_status_history_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_status_history
    ADD CONSTRAINT order_status_history_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: order_status_history order_status_history_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_status_history
    ADD CONSTRAINT order_status_history_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: orders orders_address_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_address_id_fkey FOREIGN KEY (address_id) REFERENCES public.client_addresses(id) ON DELETE SET NULL;


--
-- Name: orders orders_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE RESTRICT;


--
-- Name: orders orders_courier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_courier_id_fkey FOREIGN KEY (courier_id) REFERENCES public.couriers(id) ON DELETE SET NULL;


--
-- Name: orders orders_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: price_history price_history_changed_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.price_history
    ADD CONSTRAINT price_history_changed_by_id_fkey FOREIGN KEY (changed_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: price_history price_history_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.price_history
    ADD CONSTRAINT price_history_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: price_history price_history_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.price_history
    ADD CONSTRAINT price_history_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: product_categories product_categories_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_categories
    ADD CONSTRAINT product_categories_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: products products_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.product_categories(id) ON DELETE SET NULL;


--
-- Name: products products_container_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_container_product_id_fkey FOREIGN KEY (container_product_id) REFERENCES public.products(id) ON DELETE SET NULL;


--
-- Name: products products_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: regions regions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.regions
    ADD CONSTRAINT regions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: settings settings_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: treasury_transactions treasury_transactions_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.treasury_transactions
    ADD CONSTRAINT treasury_transactions_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: treasury_transactions treasury_transactions_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.treasury_transactions
    ADD CONSTRAINT treasury_transactions_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE SET NULL;


--
-- Name: treasury_transactions treasury_transactions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.treasury_transactions
    ADD CONSTRAINT treasury_transactions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: users users_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: warehouse_items warehouse_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouse_items
    ADD CONSTRAINT warehouse_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: warehouse_items warehouse_items_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouse_items
    ADD CONSTRAINT warehouse_items_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: warehouse_stock warehouse_stock_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouse_stock
    ADD CONSTRAINT warehouse_stock_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.warehouse_items(id) ON DELETE CASCADE;


--
-- Name: warehouse_stock warehouse_stock_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouse_stock
    ADD CONSTRAINT warehouse_stock_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: warehouse_transactions warehouse_transactions_courier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouse_transactions
    ADD CONSTRAINT warehouse_transactions_courier_id_fkey FOREIGN KEY (courier_id) REFERENCES public.couriers(id) ON DELETE SET NULL;


--
-- Name: warehouse_transactions warehouse_transactions_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouse_transactions
    ADD CONSTRAINT warehouse_transactions_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: warehouse_transactions warehouse_transactions_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouse_transactions
    ADD CONSTRAINT warehouse_transactions_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.warehouse_items(id) ON DELETE RESTRICT;


--
-- Name: warehouse_transactions warehouse_transactions_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouse_transactions
    ADD CONSTRAINT warehouse_transactions_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE SET NULL;


--
-- Name: warehouse_transactions warehouse_transactions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouse_transactions
    ADD CONSTRAINT warehouse_transactions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict GB8YnMN9P4x9JcVhUTzysNCDHhZkTo5pindzG3hr0gg9phphE09LpMzlcGsLGDn

