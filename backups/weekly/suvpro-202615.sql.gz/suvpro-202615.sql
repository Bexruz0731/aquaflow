--
-- PostgreSQL database dump
--

\restrict dHCbYRtXFK9TguVhp1WKSn6AYcMf6mb12SwXom6ZmpwQbjBb17PsK5koK8y6YMR

-- Dumped from database version 16.13
-- Dumped by pg_dump version 18.0 (Debian 18.0-1.pgdg13+3)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO postgres;

--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audit_log (
    id uuid NOT NULL,
    tenant_id uuid,
    user_id uuid,
    action character varying(100) NOT NULL,
    entity_type character varying(50),
    entity_id character varying(100),
    old_value text,
    new_value text,
    ip_address character varying(50),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.audit_log OWNER TO postgres;

--
-- Name: client_addresses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.client_addresses (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    client_id uuid NOT NULL,
    region_id uuid,
    label character varying(50) NOT NULL,
    address_text character varying(500) NOT NULL,
    landmark character varying(200),
    apartment character varying(50),
    floor character varying(20),
    entrance character varying(20),
    latitude double precision,
    longitude double precision,
    city character varying(100),
    is_primary boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.client_addresses OWNER TO postgres;

--
-- Name: client_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.client_groups (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.client_groups OWNER TO postgres;

--
-- Name: clients; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.clients (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    user_id uuid,
    first_name character varying(100) NOT NULL,
    last_name character varying(100),
    phone character varying(20) NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    is_verified boolean DEFAULT false NOT NULL,
    is_blocked boolean DEFAULT false NOT NULL,
    has_contract boolean DEFAULT false NOT NULL,
    container_balance integer DEFAULT 0 NOT NULL,
    debt_amount integer DEFAULT 0 NOT NULL,
    advance_amount integer DEFAULT 0 NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL,
    group_id uuid
);


ALTER TABLE public.clients OWNER TO postgres;

--
-- Name: container_client_balance; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.container_client_balance (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    client_id uuid NOT NULL,
    balance integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.container_client_balance OWNER TO postgres;

--
-- Name: container_transactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.container_transactions (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    client_id uuid NOT NULL,
    order_id integer,
    created_by_id uuid,
    transaction_type character varying(20) NOT NULL,
    quantity integer NOT NULL,
    balance_before integer NOT NULL,
    balance_after integer NOT NULL,
    note text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.container_transactions OWNER TO postgres;

--
-- Name: courier_balance_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.courier_balance_log (
    id uuid NOT NULL,
    courier_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    order_id integer,
    operation character varying(50) NOT NULL,
    full_containers_delta integer DEFAULT 0 NOT NULL,
    empty_containers_delta integer DEFAULT 0 NOT NULL,
    cash_delta integer DEFAULT 0 NOT NULL,
    card_delta integer DEFAULT 0 NOT NULL,
    payme_delta integer DEFAULT 0 NOT NULL,
    note text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.courier_balance_log OWNER TO postgres;

--
-- Name: courier_cash_collections; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.courier_cash_collections (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    courier_id uuid NOT NULL,
    collected_by_id uuid,
    cash_amount integer DEFAULT 0 NOT NULL,
    card_amount integer DEFAULT 0 NOT NULL,
    payme_amount integer DEFAULT 0 NOT NULL,
    total_amount integer DEFAULT 0 NOT NULL,
    full_containers_returned integer DEFAULT 0 NOT NULL,
    empty_containers_returned integer DEFAULT 0 NOT NULL,
    orders_completed integer DEFAULT 0 NOT NULL,
    note text,
    collection_date timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.courier_cash_collections OWNER TO postgres;

--
-- Name: courier_inventory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.courier_inventory (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    courier_id uuid NOT NULL,
    product_id uuid NOT NULL,
    quantity integer DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT check_courier_inventory_quantity_non_negative CHECK ((quantity >= 0))
);


ALTER TABLE public.courier_inventory OWNER TO postgres;

--
-- Name: couriers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.couriers (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    user_id uuid NOT NULL,
    car_number character varying(20),
    is_active boolean DEFAULT true NOT NULL,
    shift_status character varying(10) DEFAULT 'closed'::character varying NOT NULL,
    shift_started_at timestamp with time zone,
    cash_balance integer DEFAULT 0 NOT NULL,
    card_balance integer DEFAULT 0 NOT NULL,
    payme_balance integer DEFAULT 0 NOT NULL,
    full_containers integer DEFAULT 0 NOT NULL,
    empty_containers integer DEFAULT 0 NOT NULL,
    preferred_navigator character varying(20) DEFAULT 'yandex'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.couriers OWNER TO postgres;

--
-- Name: debt_transactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.debt_transactions (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    client_id uuid NOT NULL,
    debt_id uuid,
    order_id integer,
    created_by_id uuid,
    transaction_type character varying(20) NOT NULL,
    amount integer NOT NULL,
    payment_method character varying(20),
    description text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.debt_transactions OWNER TO postgres;

--
-- Name: debts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.debts (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    client_id uuid NOT NULL,
    order_id integer NOT NULL,
    original_amount integer NOT NULL,
    remaining_amount integer NOT NULL,
    is_paid boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    paid_at timestamp with time zone
);


ALTER TABLE public.debts OWNER TO postgres;

--
-- Name: notifications_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notifications_log (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    user_id uuid,
    order_id integer,
    telegram_id bigint,
    message text NOT NULL,
    notification_type character varying(50) NOT NULL,
    is_sent boolean DEFAULT false NOT NULL,
    error text,
    sent_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.notifications_log OWNER TO postgres;

--
-- Name: operator_cash_submissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.operator_cash_submissions (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    operator_id uuid NOT NULL,
    collected_by_id uuid,
    cash_amount integer DEFAULT 0 NOT NULL,
    card_amount integer DEFAULT 0 NOT NULL,
    total_amount integer DEFAULT 0 NOT NULL,
    note text,
    submission_date timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.operator_cash_submissions OWNER TO postgres;

--
-- Name: order_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_items (
    id uuid NOT NULL,
    order_id integer NOT NULL,
    product_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    quantity integer NOT NULL,
    price_at_order integer NOT NULL,
    total integer NOT NULL,
    delivered_quantity integer NOT NULL
);


ALTER TABLE public.order_items OWNER TO postgres;

--
-- Name: order_status_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_status_history (
    id uuid NOT NULL,
    order_id integer NOT NULL,
    tenant_id uuid NOT NULL,
    status character varying(20) NOT NULL,
    changed_by_id uuid,
    note text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.order_status_history OWNER TO postgres;

--
-- Name: orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orders (
    id integer NOT NULL,
    tenant_id uuid NOT NULL,
    client_id uuid,
    courier_id uuid,
    address_id uuid,
    status character varying(20) DEFAULT 'yangi'::character varying NOT NULL,
    payment_status character varying(20) DEFAULT 'tolanmagan'::character varying NOT NULL,
    payment_method character varying(20),
    total_amount integer DEFAULT 0 NOT NULL,
    paid_amount integer DEFAULT 0 NOT NULL,
    debt_amount integer DEFAULT 0 NOT NULL,
    containers_delivered integer DEFAULT 0 NOT NULL,
    containers_returned integer DEFAULT 0 NOT NULL,
    comment text,
    cancel_reason text,
    problem_reason text,
    is_phone_order boolean DEFAULT false NOT NULL,
    delivered_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    contact_phone character varying(20),
    cash_amount integer DEFAULT 0 NOT NULL,
    card_amount integer DEFAULT 0 NOT NULL,
    is_walkin boolean DEFAULT false NOT NULL,
    walkin_phone character varying(20),
    walkin_address character varying(300),
    walkin_store character varying(200)
);


ALTER TABLE public.orders OWNER TO postgres;

--
-- Name: orders_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.orders_id_seq OWNER TO postgres;

--
-- Name: orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.orders_id_seq OWNED BY public.orders.id;


--
-- Name: price_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.price_history (
    id uuid NOT NULL,
    product_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    old_price integer NOT NULL,
    new_price integer NOT NULL,
    changed_by_id uuid,
    changed_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.price_history OWNER TO postgres;

--
-- Name: product_categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_categories (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    icon character varying(50),
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.product_categories OWNER TO postgres;

--
-- Name: products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.products (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    category_id uuid,
    name character varying(200) NOT NULL,
    description text,
    image_url character varying(500),
    price integer NOT NULL,
    volume integer,
    volume_unit character varying(10),
    is_returnable_container boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    container_product_id uuid,
    containers_per_unit integer DEFAULT 1 NOT NULL,
    inactive_threshold_days integer DEFAULT 30 NOT NULL,
    show_to_clients boolean DEFAULT true NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL
);


ALTER TABLE public.products OWNER TO postgres;

--
-- Name: regions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.regions (
    id uuid NOT NULL,
    tenant_id uuid,
    name_uz character varying(100) NOT NULL,
    name_uz_cyrillic character varying(100),
    name_ru character varying(100),
    is_active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.regions OWNER TO postgres;

--
-- Name: settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.settings (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    company_name character varying(200),
    logo_url character varying(500),
    bot_token character varying(200),
    work_start_hour integer DEFAULT 8 NOT NULL,
    work_end_hour integer DEFAULT 22 NOT NULL,
    inactive_client_days integer DEFAULT 30 NOT NULL,
    extra_json text
);


ALTER TABLE public.settings OWNER TO postgres;

--
-- Name: tenants; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tenants (
    id uuid NOT NULL,
    name character varying(200) NOT NULL,
    slug character varying(100) NOT NULL,
    logo_url character varying(500),
    bot_token character varying(200),
    is_active boolean DEFAULT true NOT NULL,
    settings text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.tenants OWNER TO postgres;

--
-- Name: treasury_transactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.treasury_transactions (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    order_id integer,
    created_by_id uuid,
    transaction_type character varying(10) NOT NULL,
    category character varying(30),
    amount integer NOT NULL,
    payment_method character varying(20) NOT NULL,
    description text,
    transaction_date timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.treasury_transactions OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id uuid NOT NULL,
    tenant_id uuid,
    telegram_id bigint,
    telegram_username character varying(100),
    first_name character varying(100) NOT NULL,
    last_name character varying(100),
    phone character varying(20),
    role character varying(20) DEFAULT 'client'::character varying NOT NULL,
    hashed_password character varying(200),
    is_active boolean DEFAULT true NOT NULL,
    is_phone_verified boolean DEFAULT false NOT NULL,
    bot_blocked boolean DEFAULT false NOT NULL,
    language character varying(10) DEFAULT 'uz'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    cash_balance integer DEFAULT 0 NOT NULL,
    card_balance integer DEFAULT 0 NOT NULL,
    secondary_role character varying(20) DEFAULT NULL::character varying
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: warehouse_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.warehouse_items (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    product_id uuid,
    name character varying(200) NOT NULL,
    unit character varying(20) DEFAULT 'ta'::character varying NOT NULL,
    is_container boolean DEFAULT false NOT NULL,
    is_full boolean DEFAULT true NOT NULL,
    low_threshold integer DEFAULT 50 NOT NULL,
    out_threshold integer DEFAULT 10 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.warehouse_items OWNER TO postgres;

--
-- Name: warehouse_stock; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.warehouse_stock (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    item_id uuid NOT NULL,
    quantity integer DEFAULT 0 NOT NULL,
    empty_quantity integer DEFAULT 0 NOT NULL,
    CONSTRAINT check_warehouse_stock_quantity_non_negative CHECK (((quantity >= 0) AND (empty_quantity >= 0)))
);


ALTER TABLE public.warehouse_stock OWNER TO postgres;

--
-- Name: warehouse_transactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.warehouse_transactions (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    item_id uuid NOT NULL,
    order_id integer,
    courier_id uuid,
    created_by_id uuid,
    transaction_type character varying(10) NOT NULL,
    quantity integer NOT NULL,
    balance_before integer NOT NULL,
    balance_after integer NOT NULL,
    note text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.warehouse_transactions OWNER TO postgres;

--
-- Name: orders id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders ALTER COLUMN id SET DEFAULT nextval('public.orders_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alembic_version (version_num) FROM stdin;
h3i4j5k6l7m8
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audit_log (id, tenant_id, user_id, action, entity_type, entity_id, old_value, new_value, ip_address, created_at) FROM stdin;
\.


--
-- Data for Name: client_addresses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.client_addresses (id, tenant_id, client_id, region_id, label, address_text, landmark, apartment, floor, entrance, latitude, longitude, city, is_primary, created_at, updated_at) FROM stdin;
68886400-d497-4f1a-ba14-c0e694fc99a4	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	8a25ee5d-ee6f-45e2-ad88-9bd476410e6d	\N	Uy	Test address	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 08:37:57.081437+00	2026-04-01 08:37:57.081437+00
71af213b-9a3e-4b7b-a5a0-7c7346938d78	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	00032968-fb3f-4cb4-860d-e147b698cb9c	\N	Uy	Ломоносова 7а2	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 08:46:12.544418+00	2026-04-01 08:46:12.544418+00
70461bc9-b0b9-4de2-9ac5-46854381533f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	3e0ebe40-7733-4146-af41-a12d82ffebc9	\N	Uy	Navoiy 38b/46	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:15:47.660011+00	2026-04-01 13:15:47.660011+00
eea83a2f-174f-4727-aef9-eea8c90fbbdd	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	bd5c2811-28e4-46e6-b8af-981b1d7ce9f6	\N	Uy	Navoiy 46/21	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:15:48.241841+00	2026-04-01 13:15:48.241841+00
9677bb69-ae56-4887-967d-4f01d9410571	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	a3f487a9-2bb5-4411-84a7-250ecc2531df	\N	Uy	Karimov 107/27	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:15:48.84825+00	2026-04-01 13:15:48.84825+00
2e40f51c-17ac-4c6e-8e77-73cfb43fe4b6	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	b33415e2-8f36-4674-9048-9747f3697356	\N	Uy	E.Sh. Yangihayot 17***	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:15:49.409975+00	2026-04-01 13:15:49.409975+00
b5f280ad-48fe-4ddb-a11b-05f1f17bb6f3	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	058ff8bd-7ae9-4463-aa74-66660d6ec1c0	\N	Uy	Nizomiy 2/35	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:18.43626+00	2026-04-01 13:20:18.43626+00
7e3dac72-8cd9-42c3-b1d7-24b5430b1e14	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	740cee76-3027-4baf-8862-d7c37a7a87a8	\N	Uy	Nizomiy 2/37	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:18.914461+00	2026-04-01 13:20:18.914461+00
fc8a69b0-8a80-497c-b69a-59aaa392a325	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	b3975d51-4977-46df-b994-90410657122d	\N	Uy	Nizomiy 2a/43	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:19.457799+00	2026-04-01 13:20:19.457799+00
10b6e2a5-26ea-4c77-ad31-5f14a4ef46fb	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	50a21fd0-7058-47e5-b040-9c03b42d5de3	\N	Uy	Nizomiy 2a/79	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:19.955955+00	2026-04-01 13:20:19.955955+00
31e41f44-1db3-4e48-ac02-9191051ed044	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	cd8897c1-0b4e-4457-954c-18c10d52a162	\N	Uy	Nizomiy 2a/83	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:20.469444+00	2026-04-01 13:20:20.469444+00
e65928d7-01df-4361-a60a-865ad93dddc9	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	e296833e-9b1c-49b7-b856-5f898785b5fb	\N	Uy	Nizomiy 2a/85	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:20.940928+00	2026-04-01 13:20:20.940928+00
de6d5948-9088-4ea1-94bc-63ee577374d3	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	411257e0-bd3c-49f0-aed7-cd2e34e912b6	\N	Uy	Nizomiy 2a/86	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:21.476312+00	2026-04-01 13:20:21.476312+00
6bfb6816-ea74-4746-ba18-cb732f66afa4	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	597f5c6e-3032-4331-a73d-b4962e295636	\N	Uy	Nizomiy 2a/90	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:21.931355+00	2026-04-01 13:20:21.931355+00
cf10cc5b-f47a-4c9b-aa1d-5bf58ca4af43	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	c0aec8f0-97f5-4330-940d-0b0f0b7de149	\N	Uy	Nizomiy 2b/1	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:22.389551+00	2026-04-01 13:20:22.389551+00
8f0f5e1c-556d-4d6a-96c5-f5a5342cd0cc	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	62d7667a-c240-4fdc-92d4-f3c412060801	\N	Uy	Nizomiy 2b/7	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:22.925848+00	2026-04-01 13:20:22.925848+00
be49a083-7904-4cd9-aa2c-eb0a6d1c65cf	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	ebcb2036-9659-4baf-9972-53675405c5cb	\N	Uy	Nizomiy 2b/8	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:23.51155+00	2026-04-01 13:20:23.51155+00
b5bf8b6e-145a-4acc-8653-80db00ba452c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	5b1bc33d-b13b-47ee-98a5-982cbead4be9	\N	Uy	Nizomiy 2b/9	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:23.972808+00	2026-04-01 13:20:23.972808+00
24a653c3-2191-4746-b1c0-6f8dd5927501	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	728baaf8-634b-4d27-8396-5ab952871069	\N	Uy	Nizomiy 2b/45	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:24.47974+00	2026-04-01 13:20:24.47974+00
9c209884-8a72-4f84-8bb7-ded68459b574	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	1e0defc7-bae1-4774-aee5-5d01be3f0960	\N	Uy	Nizomiy 4/9	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:25.057712+00	2026-04-01 13:20:25.057712+00
2e934205-6f2c-428b-ad28-0bef1ea8c38f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	0f190025-5cc3-49b5-af18-440aef8820e8	\N	Uy	Nizomiy 4/21	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:25.576968+00	2026-04-01 13:20:25.576968+00
c2de13a2-6ef0-4ea6-a3a0-d5f125354eae	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	8986ef33-0d26-46c6-8f5f-9c8e6b2217e2	\N	Uy	Nizomiy 4/27	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:26.127248+00	2026-04-01 13:20:26.127248+00
c81e7fb7-359c-46a9-9217-79fd0d9339d8	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	518f40fd-4dc9-4442-9aa0-515b9331e211	\N	Uy	Nizomiy 4a/7	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:26.678564+00	2026-04-01 13:20:26.678564+00
c525b81a-f5b2-4acf-8814-62a7da5831fa	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	f470bb63-e36c-4ac2-a19b-0c335cc22ad6	\N	Uy	Nizomiy 4a/9	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:27.19106+00	2026-04-01 13:20:27.19106+00
3efce6c9-914e-42d7-93d6-aec15c2abc39	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	9fef4825-4551-4806-b8e0-7842b74d4c8c	\N	Uy	Nizomiy 16/105	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:27.683224+00	2026-04-01 13:20:27.683224+00
d4fab25d-b0b2-4716-9447-fb9872cafe21	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	88793a34-f091-4bd4-baee-2b65763f1f46	\N	Uy	Nizomiy 16/134	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:28.246118+00	2026-04-01 13:20:28.246118+00
0b5b165d-009e-461f-8706-b8075743a702	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	5d15d23f-6331-4b81-9c64-6f979afc377b	\N	Uy	Navoiy 1/2	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:28.712781+00	2026-04-01 13:20:28.712781+00
111dc75a-65d3-48fe-b97d-f2b6ee9c409f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	982a35f9-6f15-4f86-9417-94b1c1a73618	\N	Uy	Navoiy 1a/203	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:29.210041+00	2026-04-01 13:20:29.210041+00
c02e695a-6ff1-4747-8130-1b456e48705a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	0764972e-0604-4069-867e-a6c013883d6e	\N	Uy	Navoiy 1a/204	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:29.720398+00	2026-04-01 13:20:29.720398+00
493b51ae-c3a2-4d02-993c-7436cfa39500	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	25823438-446e-4153-b996-1d84b86a19f3	\N	Uy	Navoiy 1v/12	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:30.2404+00	2026-04-01 13:20:30.2404+00
0d8adfe0-7a14-4162-a3d8-46669e73355d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	b0ef380a-65e2-4f13-9fb2-5191630a81ab	\N	Uy	Navoiy 3b/11	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:30.761547+00	2026-04-01 13:20:30.761547+00
bc67832a-c99b-4067-9b85-d2f589572eda	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	c0a4a6fd-e107-4a7d-9ec4-9197041bf888	\N	Uy	Navoiy 3v/34	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:31.325782+00	2026-04-01 13:20:31.325782+00
f88ae5d2-f6c8-462a-8ed9-3d08bc4ddedb	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	87654fdd-a0f5-4a64-b78c-fc6507bf614a	\N	Uy	Navoiy 3v/50	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:31.800315+00	2026-04-01 13:20:31.800315+00
b1c2bfbf-a96e-4ed9-ac63-7fb77011c53a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	0c2743f0-d0fd-457b-ad77-91b3f4d73822	\N	Uy	Navoiy 5b/1	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:32.278863+00	2026-04-01 13:20:32.278863+00
c8e43275-de21-4196-9c41-8343b60b6262	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	f6d7fd38-a84c-46fc-b9f3-f5c207cee877	\N	Uy	Navoiy 5b/3	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:32.729577+00	2026-04-01 13:20:32.729577+00
8c23b72b-8ba5-4b73-a104-412284f3ff5b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	f560e07a-8bf9-42e5-8b22-091ea150aad9	\N	Uy	Navoiy 5d/23*	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:33.258967+00	2026-04-01 13:20:33.258967+00
cfd7dd10-3e56-47fd-a5e6-9519a713afaa	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	2b570b8b-5138-40ed-885d-4cf2b12129e3	\N	Uy	Navoiy 5d/25***	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:33.784253+00	2026-04-01 13:20:33.784253+00
efe7cea6-a7aa-4160-8dd5-72345fdd20d7	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	24aeab6d-5106-4a0e-b2a1-f8c6bcda6f81	\N	Uy	Navoiy 5d/32	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:34.245871+00	2026-04-01 13:20:34.245871+00
e17e9737-afdb-4e13-81fe-d5ca65acf450	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	69c9e7d6-9c28-4b06-9630-546bc251a72e	\N	Uy	Navoiy 5d/176	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:34.735704+00	2026-04-01 13:20:34.735704+00
79b907f7-1231-4bd3-a01c-450238c81f2e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	83d6ff88-88b7-4159-9c2b-c1414b862e04	\N	Uy	Navoiy 5d/263	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:35.246931+00	2026-04-01 13:20:35.246931+00
af546126-6fd8-49ea-b3e1-1a33261b3a04	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	dddd0db2-bd56-48d3-a615-672bcd1dd407	\N	Uy	Navoiy 5d/281	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:35.74728+00	2026-04-01 13:20:35.74728+00
71f111a7-0d3a-4818-9cc8-06c01ba397e8	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	ef475737-6f1e-4b6a-ba26-d42f77489310	\N	Uy	Navoiy 5d/329--	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:36.273323+00	2026-04-01 13:20:36.273323+00
c64d2cbd-f05a-4bbb-8714-b9acd6549c62	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	3ae1fcee-f18a-4eac-b1d3-24eb59b67acf	\N	Uy	Navoiy 29/53/1	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:36.803007+00	2026-04-01 13:20:36.803007+00
1aa706ca-dfae-44a8-b69f-0f1caafc0567	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	50ac1951-f340-4fe3-91e8-aa5ba518084e	\N	Uy	Navoiy 30/18	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:37.351135+00	2026-04-01 13:20:37.351135+00
e9bd7904-5131-4448-b700-07c5fe0692fe	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	0c7ae2a7-a1ca-4b9c-b74a-26b479cf33aa	\N	Uy	Navoiy 30d/23	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:37.8275+00	2026-04-01 13:20:37.8275+00
6148b1f3-bd86-4a5b-918e-62edc89e88aa	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	70e4380a-c487-4555-ac61-4f2c307bd422	\N	Uy	Navoiy 38**	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:38.333195+00	2026-04-01 13:20:38.333195+00
5c3c9d14-48be-418e-ba49-a87d478bdbc9	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	2b6a30cf-cdb7-4d72-a1a4-714d2edcc195	\N	Uy	Navoiy 38/73	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:38.839306+00	2026-04-01 13:20:38.839306+00
ead391f5-18f4-4eba-89c2-7cf15e2d5d05	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	8912fe08-de80-4c64-9b0b-27def817dfbb	\N	Uy	Navoiy 38a/37	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:39.379962+00	2026-04-01 13:20:39.379962+00
07e8f573-60f2-4a16-a1ef-3529fdda1b18	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	f7fd9fb1-52c7-484b-9b6a-aa5e2c150c09	\N	Uy	Navoiy 38a/44	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:39.861629+00	2026-04-01 13:20:39.861629+00
b9e82346-6236-435a-a386-e7a2abf325a8	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	8ccecceb-4ad4-4fb0-a3fb-0f1a86122e69	\N	Uy	Navoiy 38a/49	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:40.369588+00	2026-04-01 13:20:40.369588+00
375cd9d7-5abc-4f80-a69b-58374988182f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	14bb2d04-deaf-4ce2-a446-9dc919d3c0fd	\N	Uy	Navoiy 39/612	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:40.855183+00	2026-04-01 13:20:40.855183+00
a2f02b53-2c94-4185-bf53-84f0a6838341	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	b69f929f-63d2-439d-b6e8-6fa4bd3eba41	\N	Uy	Navoiy 40a/35	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:41.417104+00	2026-04-01 13:20:41.417104+00
2c0c200b-f1a8-4cc0-947f-382c1690bc0f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	8ab6b117-88b1-4d04-a036-016b9830ce27	\N	Uy	Navoiy 42a/37	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:41.944925+00	2026-04-01 13:20:41.944925+00
6ab034e9-f8fd-42cf-9c2d-6235b9562e6e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	676e8654-63ba-42f0-9b4d-919787e6b455	\N	Uy	Navoiy 45/57/222	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:42.440496+00	2026-04-01 13:20:42.440496+00
06129850-e3f8-43bd-8867-57b33c89e8e8	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	856ec875-6b4e-4f8c-8f13-22ec192f817d	\N	Uy	Navoiy 45/58/228	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:42.886484+00	2026-04-01 13:20:42.886484+00
b7530106-0fc9-4657-bcd1-0e3784b4c85a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	c39e99fc-5391-4bb2-8687-b26ab3b40146	\N	Uy	Navoiy 46/18	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:43.423495+00	2026-04-01 13:20:43.423495+00
44291b28-a473-4c35-90d2-b9957d7846a2	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	51ba792f-b1b1-4c7e-890e-28a7979fd206	\N	Uy	Navoiy 46/43	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:44.013715+00	2026-04-01 13:20:44.013715+00
0ef225c3-0f76-4a87-80de-2b82f4f9678f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	fb73c94a-e21d-4b79-bd52-e8259a315ae3	\N	Uy	Navoiy 46a/30	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:44.492823+00	2026-04-01 13:20:44.492823+00
17082be8-a5d9-4f96-9275-45f4bff2f2ee	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	a66ac0b2-8a31-40f4-8247-cf96ca3f5907	\N	Uy	Navoiy 48/72**	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:44.966949+00	2026-04-01 13:20:44.966949+00
a841b8b3-45a0-4cba-a49a-8afab474200d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	bf732197-c807-402b-a228-f6061b4f7610	\N	Uy	Navoiy 52/6	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:45.489843+00	2026-04-01 13:20:45.489843+00
612fefa7-261d-4e9f-903c-81bca39c7f59	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	ebdb12f4-51c9-47ad-8660-97bdb9be8ef7	\N	Uy	Navoiy 52a/33	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:45.935311+00	2026-04-01 13:20:45.935311+00
3bd6dfc0-34ec-477d-9d7b-013d764b5922	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	f0a57bf5-e14c-49e3-90fa-5a2ee5d8dc8d	\N	Uy	Navoiy 54/15	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:46.455763+00	2026-04-01 13:20:46.455763+00
1fb9ad8e-2554-4fe0-b378-ac3ecd498ccd	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	75b72f20-3fcb-4922-b315-f9caa8bf36b1	\N	Uy	Navoiy 54/29	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:46.982865+00	2026-04-01 13:20:46.982865+00
2ccc986e-c2cf-4127-853b-87ff1fcd6796	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	23e88675-9a67-4275-a319-d566acd58f87	\N	Uy	Navoiy 56/41	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:47.476991+00	2026-04-01 13:20:47.476991+00
f1b40951-8b83-4448-8a2e-67697050aa2b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	6c9ee279-a8c9-4eec-a7e2-949ddb162ff8	\N	Uy	Navoiy 56/46	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:47.943601+00	2026-04-01 13:20:47.943601+00
98b0be7e-58f0-44ad-b882-5deca7def67d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	7c2d0e3a-1354-4196-a844-44d7d5f7883a	\N	Uy	Navoiy 57/52	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:48.496025+00	2026-04-01 13:20:48.496025+00
ead496ec-e5e9-4133-85a6-dc4b9675a2fb	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	5ab10ced-c04e-406b-a627-20d54032f2df	\N	Uy	Navoiy 57v/110	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:48.987932+00	2026-04-01 13:20:48.987932+00
2b3438e9-a928-40d9-a53d-7bffcaadd4db	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	cfa0ffac-d860-420f-9a83-75c33a81d652	\N	Uy	Navoiy 57v/62	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:49.555941+00	2026-04-01 13:20:49.555941+00
18a4cd75-8bd2-4c78-8e32-1805c431af81	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	8c804cf6-8261-4475-b7b1-25a2ab6f0bdb	\N	Uy	Navoiy 58/32	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:50.071334+00	2026-04-01 13:20:50.071334+00
3ed3735d-3e8a-4d55-81ba-08bd5c793693	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	6ff1f745-af21-4d77-8d73-7ba2576244b4	\N	Uy	Navoiy 58/75	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:50.573542+00	2026-04-01 13:20:50.573542+00
7b492a20-76d5-4de5-b0a6-67b28f0cc3c9	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	46902e34-a767-46cb-832c-8f7cb701599c	\N	Uy	Lomonosov 9/9	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:51.268035+00	2026-04-01 13:20:51.268035+00
0992325f-616f-4cfa-81c7-452fdb3860c6	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	6f26e321-0f96-4eb9-8258-8f1bc9f0bb36	\N	Uy	Lomonosov 11b/15	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:51.817796+00	2026-04-01 13:20:51.817796+00
5118bd8f-25fd-4a1e-a76f-cd3f832c6508	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	ab20e2da-c3ed-49be-a6b8-89e863e67cf4	\N	Uy	Lomonosov 13a/53	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:52.309815+00	2026-04-01 13:20:52.309815+00
4d2f1f91-7ca7-4f00-8f1c-92f3896a7a54	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	e318bdc7-90b4-46fe-9f02-c78653667174	\N	Uy	Lomonosov 16/30	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:52.792118+00	2026-04-01 13:20:52.792118+00
b6902629-2ff1-4608-9ff4-fb04468bc62f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	48d4c5bc-7fb9-46a3-b083-5ccb18a90871	\N	Uy	Lomonosov 17a/30	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:53.276299+00	2026-04-01 13:20:53.276299+00
73d80155-b155-4047-bc6a-2c7591b2c2a6	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	65d384ad-ec25-4956-989b-1debd6848a37	\N	Uy	Lomonosov 21/21	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:53.837055+00	2026-04-01 13:20:53.837055+00
37315779-5047-4388-b868-6d72b942c447	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	d5f90dd9-cf40-438f-b0c8-12619634e9cc	\N	Uy	Me'morlar 14/32	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:54.330155+00	2026-04-01 13:20:54.330155+00
f4f01120-d1dd-4672-a434-f9869cd71819	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	e0c9a6ed-be25-4406-8dcf-dbd2560ccb40	\N	Uy	Me'morlar 14/45	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:54.81635+00	2026-04-01 13:20:54.81635+00
e071d1ad-992b-402f-a1bc-dcd1f14edf88	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	6f486f21-cb91-44c3-ac84-6ae90aaccb44	\N	Uy	Me'morlar 15/85	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:55.338571+00	2026-04-01 13:20:55.338571+00
e5975326-2214-4ce8-8e42-963f3cf09962	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	45e1cbf5-99a4-43a2-9c4b-c8f8e87fa42c	\N	Uy	Me'morlar 16/75	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:55.849825+00	2026-04-01 13:20:55.849825+00
3a5a433e-35fe-4b19-a87b-406c1cf351d8	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	e5ba9770-aebd-4b6d-b367-34598576dbb4	\N	Uy	Me'morlar 16/99	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:56.349375+00	2026-04-01 13:20:56.349375+00
e607e01b-15a3-41f5-9fc4-540c1bb25234	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	39fb09f9-d3a2-4c71-9f54-7564a2d5ccfc	\N	Uy	Me'morlar 16a/5	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:56.792834+00	2026-04-01 13:20:56.792834+00
9fb0f481-107b-4b8a-ad54-21e87814f801	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	39546a3e-9d21-4452-8f12-26d653baa73a	\N	Uy	Me'morlar 16a/24	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:57.348972+00	2026-04-01 13:20:57.348972+00
416e6c64-95e9-48fc-a029-79fc3115391f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	1aa7c743-312a-4d96-85a4-9c50dfb0bf8a	\N	Uy	Me'morlar 16a/41	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:57.849841+00	2026-04-01 13:20:57.849841+00
d5075d5c-9cb7-441a-973c-07c3b8b6df1c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	64c9beb9-9d88-4c1b-b0cb-d5daba497dca	\N	Uy	Me'morlar 16a/59	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:58.329785+00	2026-04-01 13:20:58.329785+00
4503cefc-7ba9-49ca-895b-048bdc84d05f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	adfead08-76e5-4e86-82ba-c3dd9460295c	\N	Uy	Me'morlar laylo mchj	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:58.874685+00	2026-04-01 13:20:58.874685+00
fd681028-5c88-410c-afca-a05b9c3d0258	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	07d6aef6-7ac0-43b9-bce7-990c07f2da56	\N	Uy	Me'morlar *	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:59.409799+00	2026-04-01 13:20:59.409799+00
f1c74f02-2bf1-47aa-b2ab-19f7904d1ba3	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	2dcad786-b075-4a20-b5fd-ad4ff9762775	\N	Uy	Me'morlar 20a/15	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:20:59.917701+00	2026-04-01 13:20:59.917701+00
30303694-ed01-4ca7-b94c-5c4d761f887e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	2b201bcd-7989-401b-8c26-8d59820c2ba9	\N	Uy	Me'morlar 21/18	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:00.503008+00	2026-04-01 13:21:00.503008+00
2d35e433-15a5-40be-a0fd-124a1a49b8fe	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	e5b9efdf-3b96-4416-b547-27dd19b87c72	\N	Uy	Me'morlar 21/42	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:00.978496+00	2026-04-01 13:21:00.978496+00
1807ee56-147b-43bf-8af9-0241fc1a63da	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	7d180fc5-63d1-415d-b77a-d9432187ffc9	\N	Uy	Me'morlar 23/21	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:01.504346+00	2026-04-01 13:21:01.504346+00
bee8fd04-dd2a-4023-a9cf-25657a32e0d8	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	38d7d6a2-6199-4e74-be81-5085a697a3ab	\N	Uy	Me'morlar 23/31	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:02.117131+00	2026-04-01 13:21:02.117131+00
549b7d45-0495-4b2a-907c-3735a7bef162	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	88c6a59d-2cdd-42d6-84c3-5bcfd4b9d360	\N	Uy	Me'morlar 27/16	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:02.623276+00	2026-04-01 13:21:02.623276+00
205ecb29-2477-4478-9b28-810143b3c1aa	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	be263a1e-7965-4cd8-855f-43d0178c3271	\N	Uy	Me'morlar 31/92	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:03.095653+00	2026-04-01 13:21:03.095653+00
889717a0-a373-4022-8b96-aae58c897fcf	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	8d4fb535-ca09-4225-9771-c776f4ae4467	\N	Uy	Me'morlar 193/11**	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:03.568859+00	2026-04-01 13:21:03.568859+00
174bec37-799d-466b-b690-5649d98f228a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	37619a3e-0c1f-4ecf-a369-0953678a9760	\N	Uy	M. Ulug'bek 2/28	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:04.169723+00	2026-04-01 13:21:04.169723+00
3cb8e221-527d-43bf-ac20-61aa5b0d7b46	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	23a5e11f-bf5d-4d2b-a9ae-957dd1677135	\N	Uy	M. Ulug'bek 4/8	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:04.635651+00	2026-04-01 13:21:04.635651+00
44525ce6-8900-43f2-bc1c-43041ce97512	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	f53c15b3-5bc6-4417-b6fd-c37e8c0a62ba	\N	Uy	M. Ulug'bek 7/27	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:05.104532+00	2026-04-01 13:21:05.104532+00
144ac8c1-10f8-4e95-9de8-52a25314ae19	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	165943d5-71ca-4948-a24c-ebd6b0f1b993	\N	Uy	M. Uluĝbek 8/68	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:05.575171+00	2026-04-01 13:21:05.575171+00
498e81b2-8b11-47ab-84b9-bb279ad0eb85	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	e2a33e24-7cc1-4b69-bea4-830bd8fabd2d	\N	Uy	M. Uluĝbek 8/123	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:06.075597+00	2026-04-01 13:21:06.075597+00
bb21366a-7d14-4435-8f0b-512f7ebf7a0c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	ffa3a089-7d91-4fca-8176-71e1bd193311	\N	Uy	M. Ulug'bek 11/6	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:06.54793+00	2026-04-01 13:21:06.54793+00
fad7a4a6-3b8c-46b4-9b59-156cb089aa90	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	1706ba1d-a7ad-4708-8f53-65c2fbe153a2	\N	Uy	M. Ulug'bek 19/43	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:07.155314+00	2026-04-01 13:21:07.155314+00
c1e124e2-aec7-49f1-b36e-05c21a91eba9	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	513001b3-97df-43de-9889-e74b9be17ce0	\N	Uy	M. Uluĝbek 19/47	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:07.654543+00	2026-04-01 13:21:07.654543+00
3d6bc296-4846-4103-afdc-5ac339589094	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	144c279a-fbcd-4152-ae1c-ef5e1c155b11	\N	Uy	M. Uluģbek 19/52	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:08.115359+00	2026-04-01 13:21:08.115359+00
33292c2b-22a8-40a5-b430-9821822bb013	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	d5054f11-a456-44b3-a5b6-97400fd59506	\N	Uy	M. Uluĝbek 19/55	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:08.554774+00	2026-04-01 13:21:08.554774+00
a9686084-58e3-4a5a-9c35-c6382958a8f1	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	938c2c4d-495a-4847-893c-d9890c9f88f2	\N	Uy	Tarobiy 5a/42	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:09.07914+00	2026-04-01 13:21:09.07914+00
b6622723-73d3-4eef-a5e9-85e812934b22	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	86c209c2-5d14-4af8-a337-999f3f1fb1a9	\N	Uy	Tarobiy 5a/181**	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:09.586908+00	2026-04-01 13:21:09.586908+00
958fff24-a732-4b27-94b0-5095ced71c1b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	aee10b01-2799-4198-b066-d3a3781c0bee	\N	Uy	Tarobiy 7/117	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:10.099104+00	2026-04-01 13:21:10.099104+00
f41ce65b-b937-4eb1-aaa3-f1d73a7dc3d9	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	fc79bf31-a5fb-4282-ad33-5297aaf448ac	\N	Uy	Tarobiy 38a/94-	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:10.564749+00	2026-04-01 13:21:10.564749+00
ed298502-91b1-40f7-9551-4d3de6cf6a73	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	6d3fe089-52a5-4d75-9b26-c375184d2499	\N	Uy	Tarobiy 38/20	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:11.034434+00	2026-04-01 13:21:11.034434+00
5c64f337-6b92-41d5-b862-ad379903273e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	9d6af115-1b50-41f9-bdc9-6d29b228955b	\N	Uy	Tarobiy 38b/40	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:11.568256+00	2026-04-01 13:21:11.568256+00
da663b71-9916-475f-b897-e2e833169cdc	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	debed304-4c80-421e-9d9d-818369dcf7d0	\N	Uy	Tarobiy 42a/79	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:12.049386+00	2026-04-01 13:21:12.049386+00
7ccc60d6-c106-4439-a3a1-8f2485628747	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	578e99e1-671f-4be0-9430-ba724ad36191	\N	Uy	Tarobiy 42a/131	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:12.608675+00	2026-04-01 13:21:12.608675+00
c30b10a9-7752-4d45-93c3-bf53b2b63715	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	9a8dc426-b5cc-4897-bebb-9db5dda205ce	\N	Uy	Tarobiy 44a/56	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:13.096685+00	2026-04-01 13:21:13.096685+00
ac927240-d246-4ad1-88c8-f2538b461857	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	ee18ffee-13cb-43fe-983d-b9f2aa89cf13	\N	Uy	Tarobiy 44b/108	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:13.575826+00	2026-04-01 13:21:13.575826+00
d189b9ad-727a-47b3-9a0b-baf8e61953ae	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	10779a85-a5a0-4dd8-902f-13bff031e823	\N	Uy	Tarobiy 44a/70	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:14.19002+00	2026-04-01 13:21:14.19002+00
2eb2a2df-f401-492c-8d9b-778530ca9bc2	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	7e12ed7b-53e8-4d20-88d6-913bb9c42186	\N	Uy	Tarobiy 48/2	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:14.702073+00	2026-04-01 13:21:14.702073+00
9ec49afb-981d-407d-b0e5-e711f8a0c54d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	196dde6a-fd12-45de-a079-02320c081a74	\N	Uy	Tarobiy 48/9****	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:15.220117+00	2026-04-01 13:21:15.220117+00
937f29c4-d17e-4e35-b8a6-4ffc5155616d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	28325cd6-06de-4841-ae7d-287464f942b4	\N	Uy	Tarobiy 48/cafe	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:15.69849+00	2026-04-01 13:21:15.69849+00
e25ab51f-4af7-403b-b082-9884316dbf68	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	03f54fe3-c7e1-4c56-8afe-e37c6f5f2ab2	\N	Uy	Tarobiy 48a/137	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:16.148646+00	2026-04-01 13:21:16.148646+00
6be6ba1d-cf13-492b-8543-afbaeceb32b6	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	33738fee-c2f5-4d1b-9f56-9a1c443ce1f2	\N	Uy	Tarobiy 48v/51-	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:16.61911+00	2026-04-01 13:21:16.61911+00
078dc2fe-149f-4cdd-8f22-b9e1568b050e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	904334f2-bf09-4d1a-8fc7-27a74f2a34b1	\N	Uy	Tarobiy 52a/14	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:17.059088+00	2026-04-01 13:21:17.059088+00
207636ed-3e94-4f1c-9501-321b5f89b979	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	21cbfec8-34b4-4b18-a538-24c8936619c6	\N	Uy	Tarobiy 56/44	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:17.610221+00	2026-04-01 13:21:17.610221+00
7f3dea7d-e0a4-41d5-b3ff-491b0088a1f8	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	0f7bd388-c696-4707-8c56-1dbf2cdcb3fa	\N	Uy	Tarobiy 58g/27	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:18.129133+00	2026-04-01 13:21:18.129133+00
ff64bcab-d2bf-4e1e-aec5-a01a3fdaebeb	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	d2ef428f-4ad1-45b6-95f0-c2c3f0e0d681	\N	Uy	Tarobiy 62/18**	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:18.60369+00	2026-04-01 13:21:18.60369+00
f901e755-9acb-4291-9dab-2bcc568afac8	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	67336717-61de-40b3-af37-5c5fa6927b0d	\N	Uy	Tarobiy 77b/7	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:19.085243+00	2026-04-01 13:21:19.085243+00
bd7caf1b-d4d4-4c17-99b3-19603018207f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	4c2b553d-6e3f-462c-80b8-745ea1b72c1d	\N	Uy	Tarobiy 77b/20	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:19.59494+00	2026-04-01 13:21:19.59494+00
45962106-a028-440c-b23f-261ae3d7ea60	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	c28cd3a8-307e-4482-a70d-ab6cf81bf5db	\N	Uy	Tarobiy 79/b1	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:20.265713+00	2026-04-01 13:21:20.265713+00
7e4267cc-7d63-4e00-8e65-238a441530de	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	eb64dfdf-d7b7-4a01-be3f-e17fd24bc982	\N	Uy	Tarobiy 79/b4	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:20.728878+00	2026-04-01 13:21:20.728878+00
ed779ccf-5cd1-46a2-8ef7-b04a7f5bdc4f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	1adce889-24ea-42aa-b602-0e2a9ec2cd52	\N	Uy	Tarobiy 79b/13	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:21.217037+00	2026-04-01 13:21:21.217037+00
aa0dcc87-a6a7-47d2-83d5-43d455ccf8a2	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	118f2fae-6326-470b-b881-efaf14b26e22	\N	Uy	Tarobiy 79/b14	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:21.701305+00	2026-04-01 13:21:21.701305+00
db886c56-742a-4221-a241-7d2ef0b8abce	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	447a6a7a-ee72-4d95-ab7e-e5b783aae080	\N	Uy	Tarobiy 87/13	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:22.248364+00	2026-04-01 13:21:22.248364+00
ef71838e-fc44-4362-9e99-0d0f7fbc1b58	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	b92a912e-22c7-4891-b234-8dac2827ecd9	\N	Uy	Tarobiy 89a/39	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:22.728193+00	2026-04-01 13:21:22.728193+00
aba0d30f-8a51-44aa-a056-73829af5918b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	de90df2d-9ef8-4bca-8131-7cfaa6f6caba	\N	Uy	Tarobiy 95/36	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:23.266506+00	2026-04-01 13:21:23.266506+00
be1cf70e-3539-4e8c-a4b2-ba91461e37fb	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	515cf726-3590-4981-917f-2f126d9af686	\N	Uy	Tarobiy 95/45	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:23.779313+00	2026-04-01 13:21:23.779313+00
17d09984-a83b-4a59-b752-09337124ae77	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	21f19bd1-bca0-45db-a155-75d765af2786	\N	Uy	Tarobiy 99/59	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:24.231437+00	2026-04-01 13:21:24.231437+00
b44bb409-a1e4-42ec-954d-d28099baa69e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	44b1704c-b878-46c1-83f8-8937889db55e	\N	Uy	Tarobiy 99/117**	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:24.798785+00	2026-04-01 13:21:24.798785+00
68f6fc30-cd37-49d3-b89d-343d49bc5714	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	65b7c2b8-a311-47b1-8c4d-8d7d869d1a21	\N	Uy	Tarobiy 108/36	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:25.316732+00	2026-04-01 13:21:25.316732+00
eb059442-5b4d-4a9a-bf3f-1774bf2b932d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	d154bb0c-26a9-4e4a-9a40-971a68e13173	\N	Uy	Tarobiy 108a/32	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:25.799428+00	2026-04-01 13:21:25.799428+00
9455b107-f600-4b85-930d-ad84af122ec6	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	55ca171a-b9b8-420a-8f4a-19b5306c409d	\N	Uy	Tarobiy 108a/75	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:26.301172+00	2026-04-01 13:21:26.301172+00
f00e8b2d-4791-400a-98a9-be7591b1befd	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	ac4623b9-ad79-4087-8e92-63ded56976e3	\N	Uy	Tarobiy 110a/11	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:26.7855+00	2026-04-01 13:21:26.7855+00
2d6eebf1-eb44-40ae-9db4-cd3b79630b3c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	8a8d1269-8d62-4078-92a0-d0ac19fb5d4e	\N	Uy	Tarobiy 110a/35-	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:27.241274+00	2026-04-01 13:21:27.241274+00
e021e911-7b65-474e-be3e-58366c5f04a4	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	112513da-e1af-4c2f-95cf-1f6a68dd6425	\N	Uy	Tarobiy 110a/58	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:27.699097+00	2026-04-01 13:21:27.699097+00
a32f0270-bcdb-4852-922f-ec786e6378ab	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	9b56ec33-efa1-484a-ae8d-e192776832da	\N	Uy	Tarobiy 110a/40*	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:28.207258+00	2026-04-01 13:21:28.207258+00
9f6d63eb-807c-4b88-a7f7-d6d094221531	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	9cf6d0ed-fb4f-4b52-9dc4-25da86b56199	\N	Uy	Tarobiy 110a/60	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:28.656042+00	2026-04-01 13:21:28.656042+00
53e24df7-b79a-46bc-8e3b-de51a1e33a70	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	0196a9d5-edce-44b4-817c-f10ce2de8578	\N	Uy	Tarobiy 110a/102**	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:29.124737+00	2026-04-01 13:21:29.124737+00
b37b1592-dd9f-42ed-bad9-b1061000a3d7	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	079d669d-9b0f-4aba-afe5-380327c971b5	\N	Uy	Tarobiy 112a/7	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:29.64812+00	2026-04-01 13:21:29.64812+00
ebf1e7d5-831d-4dd1-9630-926e69b2e9e1	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	1b972fb8-fa53-4a64-969c-8678fa5feb2e	\N	Uy	Tarobiy 112b/31-	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:30.168662+00	2026-04-01 13:21:30.168662+00
06bb7eec-d0be-44b7-a1bd-5e69da090d9e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	448b590a-6167-4a57-b8d6-03d7fa12c7d8	\N	Uy	Tarobiy 112b/63	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:30.699193+00	2026-04-01 13:21:30.699193+00
8e66a70a-03f6-40d1-85de-cb805bb1ba0a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	6f183e75-2176-43fc-800e-b2da8a2c3638	\N	Uy	Tarobiy 112b/83--	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:31.18955+00	2026-04-01 13:21:31.18955+00
b09d75fa-df16-4b5b-aef6-4f387144d220	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	942aacc3-4169-45bb-ba0c-c22eb2def4fb	\N	Uy	Tarobiy 117b/17	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:31.656996+00	2026-04-01 13:21:31.656996+00
b773d470-2231-4b42-a0a0-e0e37939a847	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	f3609d9b-0a89-473c-bfa1-d2c706cde993	\N	Uy	Tarobiy 117g/16	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:32.160792+00	2026-04-01 13:21:32.160792+00
e4feeba6-476a-4f33-9029-273ba41b5abc	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	55b6eaa0-50cb-4512-848c-5978f185627b	\N	Uy	Tarobiy 120/10	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:32.616463+00	2026-04-01 13:21:32.616463+00
abd115ea-4b80-408d-8afe-7f31b8b58b3e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	15f6fa84-f26d-4182-9777-2c752fb0f246	\N	Uy	Tarobiy 120/14	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:33.160499+00	2026-04-01 13:21:33.160499+00
11aeb0e6-d5e3-4544-9f54-7957649b13ca	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	eeaa80c6-a19c-4221-ad36-b8f8b06a5468	\N	Uy	Tarobiy 125/11*	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:33.63444+00	2026-04-01 13:21:33.63444+00
1d716b3b-965e-40e2-bc81-9535e1f91e37	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	8c4e4001-cb12-4e69-8ffe-1eaedfa6a367	\N	Uy	Tarobiy 125/24-	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:34.111702+00	2026-04-01 13:21:34.111702+00
f943b92f-6ce7-4398-842d-67823ad87b40	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	0fa6090e-f94f-480e-a531-f3a07cfef9c7	\N	Uy	Tarobiy 126a/3	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:34.610561+00	2026-04-01 13:21:34.610561+00
7151abd6-3f01-4939-aa5b-09553503047c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	9e4bffa7-784f-4851-b67b-e481d097938e	\N	Uy	Tarobiy 126a/20	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:35.127361+00	2026-04-01 13:21:35.127361+00
aa643fba-84d7-4d2a-aa07-4fa5d5a7cca7	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	0c4c1a62-27eb-461b-aafc-81632a56ff9b	\N	Uy	Tarobiy 127a/37	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:35.590554+00	2026-04-01 13:21:35.590554+00
5312b664-ef15-47f9-bdc5-4253c811e6aa	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	9ae9556d-2d8e-41db-8a50-0c0403882615	\N	Uy	Tarobiy 127a/39	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:36.054824+00	2026-04-01 13:21:36.054824+00
be901033-a5f2-487d-b186-86a29e609b5a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	111a1c17-a585-4000-9dea-bcd8b099ab21	\N	Uy	Tarobiy 128/65	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:36.524989+00	2026-04-01 13:21:36.524989+00
4b0c0b87-46e6-49cb-903f-845525670bc9	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	e59c6830-5977-4adb-bfdc-bf0c7d61edd6	\N	Uy	Tarobiy 130/82	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:36.989697+00	2026-04-01 13:21:36.989697+00
51496149-eac0-49e5-8644-f37334f90564	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	32ed3797-ed06-4e65-bdc3-1b698a0c2263	\N	Uy	Tarobiy 134/130	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:37.482028+00	2026-04-01 13:21:37.482028+00
9c19ec43-e88c-415d-b758-8ad83cf82948	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	0a62a0d9-de03-4816-b30d-1810d27d89b1	\N	Uy	Tarobiy 136/21	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:38.028308+00	2026-04-01 13:21:38.028308+00
51e998cb-8bfb-4f7f-a6c3-6848decde64f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	23579dfb-ce92-4f39-8ac1-dba98bb6af61	\N	Uy	Tarobiy 136y/22	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:38.556143+00	2026-04-01 13:21:38.556143+00
5fef2fae-02ed-427e-bebe-48ae23c997d5	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	3e9bc7cb-9e76-478d-9084-e1c58c49e360	\N	Uy	Tarobiy 137/15	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:39.064559+00	2026-04-01 13:21:39.064559+00
65beacd0-0b50-4fe6-8b1c-ec6164fcf9d9	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	a396e52d-be9a-47f9-80a2-07e2ddb89ea6	\N	Uy	Tarobiy 140a/69*	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:39.599215+00	2026-04-01 13:21:39.599215+00
53ce49ed-354f-4758-927a-b8c956e9f993	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	b1f6764a-e220-4bbf-a65d-1e87c4a09fd9	\N	Uy	Tarobiy 142a/32	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:40.273024+00	2026-04-01 13:21:40.273024+00
d674f370-5130-49d3-8a4e-762c966462f5	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	6ab17fa7-37a8-4135-8038-c05e488fee6d	\N	Uy	Tarobiy 144/18	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:40.807124+00	2026-04-01 13:21:40.807124+00
d941b7e4-a9f7-461e-a609-410df534ac3c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	786ea369-b6ff-422d-835d-ab0a6da06337	\N	Uy	Tarobiy 144/20	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:41.313193+00	2026-04-01 13:21:41.313193+00
49a93466-1f5b-45ea-9606-42fdf5f0d04f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	d731f460-65a4-49e6-b0cc-0014ea7e3209	\N	Uy	Tarobiy 144/22	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:41.791574+00	2026-04-01 13:21:41.791574+00
824404a5-30f5-43f6-a265-20350bd49544	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	e14dd724-9279-4919-b4cd-79a68027b446	\N	Uy	Tarobiy 144	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:42.310213+00	2026-04-01 13:21:42.310213+00
81ca809d-e04c-442b-be91-e5c92bab9df4	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	fe921da0-ca5e-4e72-81b9-8aded65931ec	\N	Uy	Tarobiy 144	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:42.774845+00	2026-04-01 13:21:42.774845+00
a7bb9cc0-3ef7-4b0e-a694-4f5c8b026040	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	995ca24f-8a3d-4271-a418-69b21875f2ce	\N	Uy	Tarobiy 144b/73	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:43.314592+00	2026-04-01 13:21:43.314592+00
f9b538f5-caaf-4750-9656-2840c7dd5e82	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	2d0446f1-c6ec-49ed-a13b-cc0ce4049546	\N	Uy	Tarobiy 146v/37	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:43.792094+00	2026-04-01 13:21:43.792094+00
0197f566-0862-4eaf-99ff-ceb4dfddad23	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	7cace199-c291-4d81-ad5f-8d1c8f8b2f93	\N	Uy	Yoshlik 7/199--	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:44.306323+00	2026-04-01 13:21:44.306323+00
5267d3b2-a690-4edf-88c6-cf32a4710c34	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	582dc9d6-7fc4-460c-8141-d142d9e270de	\N	Uy	Xonsaroy xola	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:44.764318+00	2026-04-01 13:21:44.764318+00
d81a0e60-963b-4b94-a97b-d0a2e4058b16	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	d2bad280-9f5b-4bed-ab71-7025c7afd48d	\N	Uy	Xonsaroy 96	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:45.295444+00	2026-04-01 13:21:45.295444+00
acf18854-25e5-4ab1-a981-e8b581a173d7	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	f2cea031-fc1a-4d5c-a3fe-df5f19037c11	\N	Uy	Yoshlik 83a/28	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:45.737648+00	2026-04-01 13:21:45.737648+00
6bec8cce-b65f-4a02-8735-2021692d85f8	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	116d350a-1539-4741-afdb-b8ddf40c663f	\N	Uy	Yoshlik 83b/42--	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:46.214059+00	2026-04-01 13:21:46.214059+00
a3aba5ce-df49-4ec8-84df-a9478fd927cc	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	43ca17de-72fb-43c0-8e28-7c12388d078c	\N	Uy	Yoshlik 83b/12	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:46.67223+00	2026-04-01 13:21:46.67223+00
81f96920-30dd-4ff8-8d47-be151d602483	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	c60c0ac9-976d-495e-b9b9-758fdbef2b54	\N	Uy	Yoshlik 83b/14	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:47.140489+00	2026-04-01 13:21:47.140489+00
52dc27b5-2d0c-47aa-9c37-8f93e5d18998	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	73536d83-6fad-49f2-a5b7-d00ce05c6dfe	\N	Uy	Yoshlik 91/85	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:47.573998+00	2026-04-01 13:21:47.573998+00
a7d3cba4-b905-41de-acd5-a22415b1c652	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	57f6ef56-813d-42d2-9cee-de7a2a4faaa1	\N	Uy	Yoshlik 91a/37	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:48.017373+00	2026-04-01 13:21:48.017373+00
aded5212-544c-468a-b5df-3dc6630449d6	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	ef8e194d-2237-452a-8b34-0c08d66be80a	\N	Uy	Yoshlik 114/49	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:48.527425+00	2026-04-01 13:21:48.527425+00
1e4acd3c-a67a-4fdc-869d-3a83716fe7dc	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	370712f0-47ec-4e2d-bb80-2529d067763b	\N	Uy	Yoshlik 116a/1	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:48.964009+00	2026-04-01 13:21:48.964009+00
12a23e24-af2f-4e63-b33f-e6fd336aa676	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	1eadd5b4-4690-4fb6-a6dd-97c061e30bb3	\N	Uy	Yoshlik 116a/68	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:49.417226+00	2026-04-01 13:21:49.417226+00
46309ba1-10ac-434f-8540-6902a303a350	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	eaaec47f-bf8a-4e12-829d-d2a555d7581b	\N	Uy	Yoshlik 116a/70	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:49.871954+00	2026-04-01 13:21:49.871954+00
f3d50d66-5e06-4ce9-b8ea-44760d326c32	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	f38f3dc1-1998-495a-be02-b4061434813f	\N	Uy	Yoshlik 116a/154	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:50.382662+00	2026-04-01 13:21:50.382662+00
ef385e7f-7cf1-4f06-bb24-b309c4eaa99b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	6140df26-668b-4527-a6f5-5a0ce6d968c0	\N	Uy	Yoshlik 118a/102	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:50.855125+00	2026-04-01 13:21:50.855125+00
4209273e-04ed-42d0-8487-7205f906c15d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	fc9bc7a0-32ee-4acf-ba6b-6ef442ddca60	\N	Uy	Tarobiy 122b/309 orzu	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:51.328795+00	2026-04-01 13:21:51.328795+00
1dd9360a-bc8a-4c7d-96d8-60e3fb3df8a4	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	c6da8349-4efb-459d-adf5-f17eb524284e	\N	Uy	Yoshlik 122b/520	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:51.830204+00	2026-04-01 13:21:51.830204+00
d0bffb87-5cde-4dd1-a741-91446b77fbcd	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	26df62c0-a73f-4eff-a713-06ececfe9534	\N	Uy	Haus texno	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:52.320557+00	2026-04-01 13:21:52.320557+00
e55e976d-0b2a-413b-b14e-0a94b2e8c975	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	6288540e-82f1-46b6-beea-7f7b06cfd8fb	\N	Uy	Haus 113	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:52.821324+00	2026-04-01 13:21:52.821324+00
386f297f-5865-485d-8fdf-a078b41ce016	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	96ab8ef8-45e2-47b0-93b8-98aeb9388312	\N	Uy	Karimov 40/42	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:53.380327+00	2026-04-01 13:21:53.380327+00
e08fdfff-95d7-4b0f-a214-f52077925e20	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	b353e0a9-bcda-4a30-8577-027e25a33436	\N	Uy	Karimov 42/20	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:53.916012+00	2026-04-01 13:21:53.916012+00
4eb39e9f-e3cf-4f29-be44-a7d91f444ff4	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	188288fa-615e-4616-98f2-024a6a44b81b	\N	Uy	Karimov 42/58	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:54.359947+00	2026-04-01 13:21:54.359947+00
55d840e6-5beb-4665-84e6-a060aa2c162a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	f7e14876-6244-4ba7-a5a3-208ff72abf05	\N	Uy	Karimov 43/11	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:54.851073+00	2026-04-01 13:21:54.851073+00
f20d3f99-7fa4-496b-a3f2-1a9ba48e5d8c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	9042e8f4-1a60-4a47-b5cc-761e7c6c6f1d	\N	Uy	Karimov 43/42	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:55.405504+00	2026-04-01 13:21:55.405504+00
8cad2f73-aee1-41a9-9cbe-b09628ff3e0f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	8c31180f-f6ed-4686-ba87-eb3cbed41501	\N	Uy	Karimov 46/46	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:55.882726+00	2026-04-01 13:21:55.882726+00
a6810c77-b6be-48f1-b59e-4f46b156b293	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	76f96b25-ca53-4502-8b90-3d6414f9565a	\N	Uy	Karimov 47/64	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:56.380602+00	2026-04-01 13:21:56.380602+00
c74c1cca-a7a5-4a20-835c-920a9a24881c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	6aab9cfb-23de-4416-9c59-af3dfb7023a5	\N	Uy	Karimov 56/72	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:57.017182+00	2026-04-01 13:21:57.017182+00
79eb1ce0-841a-482d-b122-c019c171d74d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	629c8afa-e1c3-4c64-8343-e56fda1baefe	\N	Uy	Karimov 59/9	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:57.507836+00	2026-04-01 13:21:57.507836+00
3050506b-0d5c-4a36-a26d-b0932a570225	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	dad173a5-e674-4b37-a437-318732d781d0	\N	Uy	Karimov 59/23	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:57.958545+00	2026-04-01 13:21:57.958545+00
8bb9db5a-625d-4675-b514-4a04c4129928	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	89e6fe3e-a124-46a3-aa8a-270ae266a467	\N	Uy	Karimov 61/9	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:58.440934+00	2026-04-01 13:21:58.440934+00
a02aca0f-e3fc-49b6-86ff-90c0b7996c34	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	401d7919-4442-4a7f-8fb4-2ddcbb865ca4	\N	Uy	Karimov 61/60--	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:59.019447+00	2026-04-01 13:21:59.019447+00
06ed2c80-ad8d-4788-b1e4-c5084526950a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	b67dda6f-20ff-432b-b66b-1ca13cbcd79c	\N	Uy	Karimov 68/37	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:59.502048+00	2026-04-01 13:21:59.502048+00
d28b1efb-01a2-4de5-a737-6699ad74a62f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	0023dc32-3463-4fa3-bba0-d304996dd52c	\N	Uy	Karimov 70/6	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:21:59.993858+00	2026-04-01 13:21:59.993858+00
5abbfc00-5ffa-48b6-bba9-af47020e72f3	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	c36d897b-6cb6-40dd-a91f-29483b126bce	\N	Uy	Karimov 70/24**	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:00.66399+00	2026-04-01 13:22:00.66399+00
d939b3b0-e9d3-4ee4-8199-a5ef2b436531	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	2194520d-48bd-4b54-8d44-ed8524a2ea03	\N	Uy	Karimov 74/54	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:01.176962+00	2026-04-01 13:22:01.176962+00
136585ee-168a-4e2e-a504-b8d7f1ef9d5c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	13a40732-4e81-402d-adc4-e42b07e60bd5	\N	Uy	Karimov 76/1	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:01.715274+00	2026-04-01 13:22:01.715274+00
6eafafc7-05b7-47d7-bae2-9dc383d36781	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	fac711c4-d52a-48bb-ba20-556472b348f4	\N	Uy	Karimov 76/49	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:02.232016+00	2026-04-01 13:22:02.232016+00
622f98a3-58ae-4858-b27e-6dcfa6a40e47	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	88017df6-bcec-4e4f-8546-508f7d5f6ac6	\N	Uy	Karimov 86a/48	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:02.697826+00	2026-04-01 13:22:02.697826+00
fd2ff1fd-f011-433c-a688-06dba9d9857f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	6d972a50-9b74-47bd-ad64-f7ed1e4bac54	\N	Uy	Karimov 92/37	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:03.33343+00	2026-04-01 13:22:03.33343+00
c139bea8-331a-4caa-abdf-00cbeb738ecb	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	159cd0da-d8df-453c-8dab-c1fee374422a	\N	Uy	Karimov 92/55**	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:03.853207+00	2026-04-01 13:22:03.853207+00
9030af17-9bdb-410e-8e00-769d3f45f1d1	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	9b73de30-2c58-4beb-bf67-27f16bf71277	\N	Uy	Karimov 95/19	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:04.533589+00	2026-04-01 13:22:04.533589+00
2b8eb43a-4997-4e03-a8ea-cb21d12a946f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	d6946742-18bf-414d-8605-b8bfab3ea31c	\N	Uy	Karimov 99/29	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:05.029509+00	2026-04-01 13:22:05.029509+00
6c10a33a-e903-4f1c-8f1c-a26312b0f854	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	655aa5f4-747b-4dd6-bd3a-b1ff881a8510	\N	Uy	Karimov 101/92	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:05.570667+00	2026-04-01 13:22:05.570667+00
2fb61fb9-45a2-4be5-8026-bca6901a0e5e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	12e9fb7b-84d6-4981-86d4-9fb34d251813	\N	Uy	Karimov 102/6	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:06.040485+00	2026-04-01 13:22:06.040485+00
fd8baf2c-420a-490e-a835-2b45c56c0a96	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	70fb25d1-49d5-43af-9e9f-1dfd902c58e7	\N	Uy	Karimov 102/28	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:06.530515+00	2026-04-01 13:22:06.530515+00
fa0725ec-dbb0-414d-8953-ebfad33e7425	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	b3e4f637-e658-4f41-aa1a-cef3ee16553a	\N	Uy	Karimov 102/29	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:06.996841+00	2026-04-01 13:22:06.996841+00
b6cabbf1-9ad2-47fd-ae89-8dec014f4b5a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	29b01617-9bd0-4f56-b04d-67408a6070cd	\N	Uy	Karimov 103a/15	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:07.528362+00	2026-04-01 13:22:07.528362+00
c9d53fd7-1b74-4460-b1e5-a8e3b8dbeafa	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	25cc1b36-517f-47c3-9b21-3aa82d27deb6	\N	Uy	Karimov 103a/17	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:07.996009+00	2026-04-01 13:22:07.996009+00
01d4fc67-9bfb-4226-8eba-12ff732fc542	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	5909a90b-e2dd-44ca-aa95-c19627bbe129	\N	Uy	Karimov 104/65	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:08.434493+00	2026-04-01 13:22:08.434493+00
28d520b3-31c2-4dff-a461-2028104c5bda	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	828c0885-e02c-4176-a7a2-f8c8c12a4b32	\N	Uy	Karimov 106a/1/19	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:08.90184+00	2026-04-01 13:22:08.90184+00
4286c944-c7e6-4d92-acef-9b5d8ca19c98	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	09a672d5-719d-45e7-a0a1-cbee6412eb73	\N	Uy	Karimov 106a/3/5	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:09.432978+00	2026-04-01 13:22:09.432978+00
b3b15dc6-4553-4880-97ed-acb8b18d7473	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	669ac255-7553-482e-bcd8-86104b1f6fe5	\N	Uy	Karimov 107/35	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:10.106849+00	2026-04-01 13:22:10.106849+00
198744e9-4261-48ec-a2d0-5b04b4e45e9e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	eefdfa8a-5885-49fd-92fa-3f6884c75280	\N	Uy	Karimov 107/36	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:10.601338+00	2026-04-01 13:22:10.601338+00
a16956a0-a138-4a24-8aec-7a4950f00617	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	6f2b4a32-65cf-4266-b9fa-f114b563c5ee	\N	Uy	Karimov 108/78	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:11.076157+00	2026-04-01 13:22:11.076157+00
7042169f-e7d1-41c6-b623-0ed4513a3bb4	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	3ef746c0-7d84-4ae4-b96f-8075712cc289	\N	Uy	Karimov 110/22	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:11.540184+00	2026-04-01 13:22:11.540184+00
1cf52584-11d3-465b-8c49-4401833f6b57	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	7005f02a-3e53-480c-96e3-dd4c4c9e7576	\N	Uy	Karimov 112/1	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:11.988334+00	2026-04-01 13:22:11.988334+00
f8d38802-4f25-44c2-a9aa-957232d88095	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	0693be1f-52c7-45bf-9e10-c1debca6f4f4	\N	Uy	Karimov 112a/1/10	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:12.481001+00	2026-04-01 13:22:12.481001+00
861267fd-15aa-4ba5-b4a2-95fc48b794e8	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	e0f7cd8a-7d4f-4ba9-9778-b3083a3b8c7a	\N	Uy	Karimov 112a/3/13--	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:12.98706+00	2026-04-01 13:22:12.98706+00
3696e804-f009-44e9-80bf-750369b46709	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	0e50c0e6-2286-495a-af54-bfb87cecd206	\N	Uy	Karimov 114/7	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:13.471007+00	2026-04-01 13:22:13.471007+00
5782d953-b182-4bc5-9745-e39dc825e4ff	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	8014db7c-2e1b-47d4-b157-133d087d8d04	\N	Uy	Karimov 116a/19*	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:13.901564+00	2026-04-01 13:22:13.901564+00
1ed1c565-b6f8-479e-b2e4-d295f00e2b1a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	c6fece6b-d6d5-4875-9bc1-a1d4d2f64bed	\N	Uy	Karimov 118/7	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:14.395209+00	2026-04-01 13:22:14.395209+00
593d0d79-f51c-4ce8-9f0e-92ccf0bfc700	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	054a05c8-8f3b-4310-96bc-c22e4a4320db	\N	Uy	Karimov 120a/8	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:14.859489+00	2026-04-01 13:22:14.859489+00
b337c7a0-b1c8-43d3-8e35-38d1022ecca3	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	4864a9a0-6e78-4830-9110-a87d05c4f76c	\N	Uy	Karimov 120a/84	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:15.412385+00	2026-04-01 13:22:15.412385+00
b99ba17c-dd18-45d7-9f7d-92babc872a9f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	4856aa55-635b-4629-b9be-8416fe8b55b4	\N	Uy	Karimov 124/8**	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:15.961241+00	2026-04-01 13:22:15.961241+00
e860b948-2386-474e-abdd-28ceed64ed3d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	28baade2-0677-4325-a8a4-855f755c97a1	\N	Uy	Karimov 128/78*	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:16.47305+00	2026-04-01 13:22:16.47305+00
54725028-602a-4ed8-8cbf-e187d33c535e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	36ad7e9d-14b8-4256-af6b-2bc5cb6dbcf4	\N	Uy	Karimov 130a/76**	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:16.964663+00	2026-04-01 13:22:16.964663+00
b510609b-1a6c-4e85-a385-3170b6e2de11	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	327fd4b3-a172-4c7d-b80d-7bb40e30fb93	\N	Uy	Karimov 138/2*	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:17.458972+00	2026-04-01 13:22:17.458972+00
c9c163ea-2d67-43c9-9c29-ecd236ef001b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	aacace3e-bf1c-45d0-bcff-ac072e954d54	\N	Uy	Karimov 138a	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:18.008197+00	2026-04-01 13:22:18.008197+00
a812a57f-595c-44aa-8f9b-c1b2fc699c19	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	b5c64dfd-469c-48f4-aa76-c816e510b808	\N	Uy	Karimov 140a/24	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:18.504036+00	2026-04-01 13:22:18.504036+00
a3ca7eb4-7e44-4894-8ec1-922c3d765da6	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	c6a521a8-6ead-43cf-b818-a188944ea116	\N	Uy	Karimov 142/30	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:18.976056+00	2026-04-01 13:22:18.976056+00
3d7f69b0-3d6e-4ac8-b2a4-f3740ac227eb	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	96bc5cf1-2527-4828-8466-844199fc6729	\N	Uy	Karimov 142/29	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:19.535418+00	2026-04-01 13:22:19.535418+00
a790b369-00b1-424a-99eb-cdb4595a8778	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	0a2a7b0e-df6c-4500-81b4-c968e4008c00	\N	Uy	Karimov 142/47	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:20.068428+00	2026-04-01 13:22:20.068428+00
1f6b3d9d-a42d-46f6-9881-c773abaf16a5	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	bc048a73-43fc-4eb7-bc5d-bde264914012	\N	Uy	Karimov 144/24	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:20.648602+00	2026-04-01 13:22:20.648602+00
63323290-61a3-4c7d-ab7b-04a17ab4a7bb	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	d13d6ef1-e4b5-4c59-96a6-656ad9a15e13	\N	Uy	Karimov 146/35	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:21.221336+00	2026-04-01 13:22:21.221336+00
34b2ec16-6de2-4f14-b659-c64ba84ed30b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	01624890-732d-456d-8ef4-a4c82dada7bc	\N	Uy	Karimov 146a/11	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:21.710229+00	2026-04-01 13:22:21.710229+00
08ed7c04-b710-4c05-9099-0aa07f07faa6	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	12315e4e-f7a1-48bc-9e9c-ceec5a0cc53f	\N	Uy	Karimov 146a/23***	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:22.261007+00	2026-04-01 13:22:22.261007+00
8df2a5cc-4631-48cc-b885-20eabaa099bb	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	fa5a27f3-6337-4eed-9700-2940307f317d	\N	Uy	Karimov 146a/27	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:22.717291+00	2026-04-01 13:22:22.717291+00
35a56467-0128-45bc-80b0-a79abb5578bb	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	90cb9a80-2fa4-44df-bc2e-c1e4ec5ab6f8	\N	Uy	Karimov 148/1/41	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:23.236108+00	2026-04-01 13:22:23.236108+00
eb35abf1-a23a-4412-a81f-49d8c1d728d2	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	538c31d0-c7b9-41aa-a341-565f65b3c34d	\N	Uy	Karimov 148a/31	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:23.705942+00	2026-04-01 13:22:23.705942+00
5d44debd-c125-4336-86e3-db7a38f40e87	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	3073bc1f-2160-49ac-bb5b-3674c2366113	\N	Uy	Karimov 150/1/1	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:24.163366+00	2026-04-01 13:22:24.163366+00
d166af10-b9c4-4d9e-92f7-79c86e80885b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	215b3e7d-3398-42c1-a416-7591a435105c	\N	Uy	Karimov 150/1/16	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:24.682492+00	2026-04-01 13:22:24.682492+00
8babaffc-3bd7-4e33-a23e-9b7f59841640	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	6ee3bfbf-6540-4e5b-8263-b965e01aea3c	\N	Uy	Karimov 150a/21	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:25.203929+00	2026-04-01 13:22:25.203929+00
2b982ea3-03f5-42fa-b3d8-20f1b2b1e5a6	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	2656a520-f666-4a3b-8464-730c3924f694	\N	Uy	Karimov 150a/23	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:25.686039+00	2026-04-01 13:22:25.686039+00
e7129c09-49c6-4c42-8822-0601be51732a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	7566520f-0917-4bac-826f-538e7c603a66	\N	Uy	Karimov 152/3/2	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:26.280092+00	2026-04-01 13:22:26.280092+00
45cf7e3d-f391-4925-8777-82221ea7cec5	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	8eea2a8a-92eb-491e-a558-04f7eac78cb4	\N	Uy	Jasorat 2/24	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:26.744248+00	2026-04-01 13:22:26.744248+00
8fa521ce-7867-43fa-8482-39da1bf46af9	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	4dbf9dda-9608-45b2-80bc-b89caf3cbc22	\N	Uy	Jasorat 3/69	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:27.231286+00	2026-04-01 13:22:27.231286+00
0db98701-5594-4f9e-b22e-4ef5486f12d9	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	0f1e04cf-a859-4fe4-b793-af2f3b92e624	\N	Uy	Jasorat 5/18	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:27.699341+00	2026-04-01 13:22:27.699341+00
55350ada-9c26-44ef-a40c-248c4e3185a5	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	5b9da1ff-d4ed-4deb-93c8-73e718ea6262	\N	Uy	Jasorat 9/32/1	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:28.238539+00	2026-04-01 13:22:28.238539+00
e8449b8e-187c-4c7e-a025-20e02cf0c960	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	c3179273-2f26-4942-9f83-d49fe722b777	\N	Uy	Jasorat 10/47	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:28.73615+00	2026-04-01 13:22:28.73615+00
917cb41e-f1de-4f94-bb41-5be228ace791	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	f929df47-afba-4b72-9a62-5a372a8c04ca	\N	Uy	Jasorat 10/135*	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:29.262543+00	2026-04-01 13:22:29.262543+00
1ed0e193-fb66-49bc-91cc-fe612182f81c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	474fd354-a6e8-49a7-9bc3-699f4695b155	\N	Uy	Jasorat 12/34	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:29.839184+00	2026-04-01 13:22:29.839184+00
b7a9cd54-6b2c-4c23-98dc-f85de0e26afd	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	bbb9e653-efa2-483e-ba3a-2e75cc022489	\N	Uy	Jasorat 12/48	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:30.336784+00	2026-04-01 13:22:30.336784+00
4c671924-3978-4122-82fb-793e1cd3447d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	916eb90b-c545-47b1-8dd6-3667a87ca5be	\N	Uy	Jasorat 12/53	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:30.795862+00	2026-04-01 13:22:30.795862+00
3aaf021b-33d9-42c7-a382-6c758db257bd	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	471eead6-b1c4-4e68-b68e-2e1fb5fd3b76	\N	Uy	Jasorat 18/4	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:31.406493+00	2026-04-01 13:22:31.406493+00
0cb26c25-8140-4839-9189-eca4061edeb1	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	e98a8d71-a658-4ba4-b082-dc02e96876d3	\N	Uy	Jasorat 20/33	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:31.902603+00	2026-04-01 13:22:31.902603+00
b83d3f74-0dd8-4690-902d-32244d0c1fca	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	b1d387b0-0d63-4278-a227-e1bd0d10095a	\N	Uy	Jasorat 20/34	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:32.36925+00	2026-04-01 13:22:32.36925+00
0e646a2f-feda-4787-981a-bec1cffe8804	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	ad32d797-5e4c-4bad-a88a-cb71fc82d516	\N	Uy	Jasorat 22/12	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:32.808777+00	2026-04-01 13:22:32.808777+00
ecd0e2fc-21cb-4475-b79b-dbb9896f327d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	01c64783-f6d8-497b-8c93-21f0c6c447c8	\N	Uy	Jasorat 22/34	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:33.302812+00	2026-04-01 13:22:33.302812+00
a27498e0-4c22-47c8-84e8-29aa3a7aea9e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	79065c59-199c-497d-801b-1eb358840833	\N	Uy	Jasorat 23a/19	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:33.791846+00	2026-04-01 13:22:33.791846+00
fe8f05fa-f2e7-4f4a-9d9e-18e69d99eec7	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	be8d6f5b-c917-4d31-bb23-02033e3de73b	\N	Uy	Jasorat 30/40	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:34.262459+00	2026-04-01 13:22:34.262459+00
15cea593-d86e-4e58-bfdf-767e4d6bf2d6	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	10ebf47f-7ef3-406f-bc53-773d07876991	\N	Uy	Jasorat 30/51	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:34.782691+00	2026-04-01 13:22:34.782691+00
3c705b97-694e-47f5-a099-ee5fcaf24e5a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	fab46f07-d860-4c70-a32d-b84e9f6ed13c	\N	Uy	Jasorat 31/28	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:35.250581+00	2026-04-01 13:22:35.250581+00
24c3c91c-9515-49d5-a0f9-55b813e1c9cf	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	3288fa37-9f75-4d43-92d8-7c7eff5736de	\N	Uy	Jasorat 34/40	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:35.681969+00	2026-04-01 13:22:35.681969+00
1c5306d1-59d0-4d8c-8cdc-15597a247a3d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	3ee471ba-4889-4d51-8987-161961bb8500	\N	Uy	A.Temur 7/31	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:36.136668+00	2026-04-01 13:22:36.136668+00
c7ebeab7-b8e5-4c62-bcde-799516cd9e15	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	53d8f0f8-4225-4821-97f6-34865f03105c	\N	Uy	A.Temur 7/60	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:36.677348+00	2026-04-01 13:22:36.677348+00
1b48f920-4d50-47ff-ad59-6a83aa72b1af	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	b19eef0b-8b34-4fd1-af37-848b15305173	\N	Uy	A.Temur 7/71	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:37.177328+00	2026-04-01 13:22:37.177328+00
962b3c64-6657-44a6-a4cc-bf265eb519b4	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	31edeb90-48e3-4515-ae86-809c9bd444ee	\N	Uy	A.Temur 7/109	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:37.626138+00	2026-04-01 13:22:37.626138+00
436d5d57-c4fc-494f-8308-20df460e9f59	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	d5ec1631-daeb-47c1-b87c-7b72529bf1b4	\N	Uy	A.Temur 24/14	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:38.104337+00	2026-04-01 13:22:38.104337+00
8b9f513f-0482-4d83-9bf7-e585262278ba	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	244ae957-1182-4f6f-964d-d9080bad2ebd	\N	Uy	A.Temur 34/40	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:38.554291+00	2026-04-01 13:22:38.554291+00
4612a75e-aece-4c6e-a4e9-bba43fad7bb6	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	d5844533-626d-455f-9b2e-26f740822f1e	\N	Uy	A.Temur 36a/22	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:38.993073+00	2026-04-01 13:22:38.993073+00
a80b7f74-0b81-43d8-97ef-cc137f7c465d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	e61c8caf-1391-4864-a880-e6b667c58709	\N	Uy	A.Temur 38/26	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:39.570333+00	2026-04-01 13:22:39.570333+00
28a3f641-344e-4c7b-be8b-dd0a6244aec0	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	02438bb5-4312-49af-bb9a-786e87bd5378	\N	Uy	A.Temur 38/28	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:40.221219+00	2026-04-01 13:22:40.221219+00
59e60a81-c06e-47b1-bb00-e19402c672bf	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	5196e352-6adc-4d67-a874-a4841e190fb2	\N	Uy	A.Temur 38/30	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:40.758638+00	2026-04-01 13:22:40.758638+00
8de9b915-ba57-4b19-b607-c6c790842eba	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	ce7325fc-096a-4d25-b592-f7cc58105b4b	\N	Uy	A.Temur 40/12	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:41.40609+00	2026-04-01 13:22:41.40609+00
35f6bd94-be92-49ec-81ab-3c343c5de4ee	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	7c9adbad-d6e2-445a-bfe1-a62e5f684298	\N	Uy	A.Temur 44g/40	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:41.944571+00	2026-04-01 13:22:41.944571+00
5865a4b2-10dc-4953-a9b5-091f11f58962	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	e08669ea-3f84-40b0-bb46-b3eb839324d1	\N	Uy	Barkamol 7/2 ment	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:42.469203+00	2026-04-01 13:22:42.469203+00
d840a6bc-151e-4738-bbc0-3783b04f2d33	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	9cf55705-d56b-48a4-8b52-def37c42e258	\N	Uy	Barkamol 15/23	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:42.990056+00	2026-04-01 13:22:42.990056+00
c507f6e7-2135-418e-9c78-d2eb3f42f754	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	037cb998-e247-44fb-bf8c-a3b5401731a3	\N	Uy	Barkamol 15/28	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:43.498099+00	2026-04-01 13:22:43.498099+00
98e96e9a-de9b-43d8-a381-508c6eddf2b2	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	994cc689-85c4-48c7-b3ec-7570fa843c4d	\N	Uy	Barkamol 21/33	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:43.934433+00	2026-04-01 13:22:43.934433+00
2a4b41b8-d6d7-4c91-be45-92cfa0453784	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	6cd013b8-9fb3-46bf-828c-e3e124ab98b5	\N	Uy	Yoshlik 9/3	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:44.459572+00	2026-04-01 13:22:44.459572+00
a5b2b79f-1cc4-44f8-b33a-29c040d81e94	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	c9802412-7dc3-4bea-8414-66e4a90a3501	\N	Uy	Parvoz  9/7	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:45.046731+00	2026-04-01 13:22:45.046731+00
0d534aaa-3a3e-48d9-be12-fa99559dabf4	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	856e43ae-9ab1-43ec-bbfd-dc3af8a3cd07	\N	Uy	Shaboda 9/5	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:45.499593+00	2026-04-01 13:22:45.499593+00
4f4100f8-7050-49f7-95fc-156fd3016aff	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	d633304c-b412-4405-82b6-c7d9dd255051	\N	Uy	Shaboda 9/65	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:45.930157+00	2026-04-01 13:22:45.930157+00
ee1e2782-09df-46eb-8e25-815083a4fe93	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	b1a56ecf-ae1e-407f-ab9a-7c1eb4ccacaf	\N	Uy	Shaboda 9/102	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:46.372747+00	2026-04-01 13:22:46.372747+00
a2fef323-4389-44a4-ba6c-cf5a7405c41b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	89240faf-747c-4ddd-b2b2-f9fb47e3cc0d	\N	Uy	Uzbekistan 8/8	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:46.875582+00	2026-04-01 13:22:46.875582+00
61f69711-4f65-441d-a49d-561f415a3cc0	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	d7d96b97-6c20-4acd-a3bd-49f7411e0c41	\N	Uy	Shodlik 9/1	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:47.487185+00	2026-04-01 13:22:47.487185+00
449dc68e-ce11-4cf5-9c0e-f4e3c5e45cfd	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	0d732736-5ed5-41e3-8ecd-0fe12ba1c332	\N	Uy	Shodlik 11/19	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:47.995118+00	2026-04-01 13:22:47.995118+00
ad71619e-aa57-41a7-8b76-938b0739c925	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	db9565ea-a1d3-45d3-a932-f2eab274aff7	\N	Uy	Shodlik 13a/4	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:48.449315+00	2026-04-01 13:22:48.449315+00
5143507e-b06d-4382-b544-4f9adc594f06	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	2b9b72fe-42db-47c7-9f99-5789111d7bb4	\N	Uy	Nurafshon 3/31---	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:49.051509+00	2026-04-01 13:22:49.051509+00
421c4f3f-545c-41d0-a80b-5d44c8248252	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	462ad9a1-741c-4611-863c-e0f40c1ddb55	\N	Uy	Nurafshon 4/31***	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:49.539628+00	2026-04-01 13:22:49.539628+00
1819912c-e49d-448f-bc5e-87cafe166667	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	c9f74a2b-35c1-4e4f-aea0-7a193172b9e2	\N	Uy	Nurafshon 5/2	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:50.087227+00	2026-04-01 13:22:50.087227+00
52809881-2085-4a24-882f-97d323817837	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	11691e0d-9d7d-4ef6-aca7-bd7428707cdd	\N	Uy	Nurafshon 5/10	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:50.583876+00	2026-04-01 13:22:50.583876+00
cb09a569-8179-4679-bbe4-2febda691751	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	f2d3dfc0-2d80-4c5d-b0a6-4a6edb7d8709	\N	Uy	Nurafshon 5/11	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:51.06683+00	2026-04-01 13:22:51.06683+00
652fac36-ff2e-437b-9d41-635ad9429626	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	5bd09ba0-c2f5-4bf4-be32-1662ce724e02	\N	Uy	Nurafshon 6/42	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:51.571959+00	2026-04-01 13:22:51.571959+00
ee2c2322-3e17-4823-a3cf-9becf58f9d36	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	626f0742-3307-4341-a272-0f9f9b8a0ceb	\N	Uy	Nurafshon 6/45	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:52.106488+00	2026-04-01 13:22:52.106488+00
21bbd76d-7d6f-478e-af22-4e25c24e5868	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	e4ae1513-c3e2-46ea-a7d2-df582481c061	\N	Uy	Nurafshon 17a/20	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:52.5968+00	2026-04-01 13:22:52.5968+00
4cf7c2b6-c174-44fd-9635-5ca3d1e606dc	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	ad0381e1-72af-4d92-b1dc-f6cf4edbd436	\N	Uy	Nurafshon 17a/39	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:53.054245+00	2026-04-01 13:22:53.054245+00
4d781953-3b8a-4bac-bff3-772e13cc17a5	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	4cc93c72-4bc3-41ee-96aa-522a4f2141db	\N	Uy	Zarapetyan 20/38	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:53.567796+00	2026-04-01 13:22:53.567796+00
62c09a67-7fb4-470a-b8e4-4f7cab3b0a51	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	48d76ef0-494a-42a0-8218-2511ca80d223	\N	Uy	Spitamin 11/28	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:54.08484+00	2026-04-01 13:22:54.08484+00
cc829f88-8dce-447d-a73c-d647c5e5d62b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	3343ee4d-a8f0-406b-8238-65b46f78d194	\N	Uy	Spitamen 13/39	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:54.558031+00	2026-04-01 13:22:54.558031+00
8f462ab3-430c-421e-b17e-9b3f8b0c97e1	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	61be5be5-f2f0-4499-b77a-225865150ea1	\N	Uy	Spitamen 9/12**	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:55.282652+00	2026-04-01 13:22:55.282652+00
0d13b6a3-6df5-40a0-9353-7b7b42c9045a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	d9c2ea5d-2866-44d3-97be-2fc633758138	\N	Uy	Qurilish 1/8	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:55.773037+00	2026-04-01 13:22:55.773037+00
39f62d24-75b2-4a26-ad50-f22e09d4c8c4	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	95cbab60-8481-459c-bb7c-cb98d0130878	\N	Uy	Qurilish 1/25	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:56.280357+00	2026-04-01 13:22:56.280357+00
5a539647-2e16-430c-99c9-302c62435eeb	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	4ad71fa0-463f-4d08-bca9-43dbaedebf41	\N	Uy	Qurilish 5/12	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:56.790048+00	2026-04-01 13:22:56.790048+00
28916574-f166-408b-aad8-bc6c45e1cb68	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	234daee3-a587-465f-b961-bdc9260a300f	\N	Uy	Qurilish 6/4*	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:57.497586+00	2026-04-01 13:22:57.497586+00
ded9a1e7-df8b-4218-a4d2-38753a6ef595	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	d50dc5f6-e580-4770-a6da-64c71884b47b	\N	Uy	Qurilish 6/12	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:58.077184+00	2026-04-01 13:22:58.077184+00
9d747319-0990-4cf8-8037-685a9fb1f558	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	84a5a246-17d6-4f2b-901f-96f76ba034bd	\N	Uy	Qurilish 6/14	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:58.632925+00	2026-04-01 13:22:58.632925+00
7773d05c-a85b-4660-97eb-690e4eb7c3cc	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	f2c77a94-d7ca-465e-a773-89d901e5849b	\N	Uy	Zulfiya 1/33	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:59.183722+00	2026-04-01 13:22:59.183722+00
e0f0e695-5468-4000-9baa-6d4016e2b8c7	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	8ab10e51-5916-4461-b6a1-8d2b3f1ed89c	\N	Uy	Zulfiya 1/34**	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:22:59.68265+00	2026-04-01 13:22:59.68265+00
48e4c725-56ce-46dd-818a-52aebf1abf54	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	6ae0c596-32a7-4665-a254-f148bab037fd	\N	Uy	Zarafshon 3/59	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:00.317657+00	2026-04-01 13:23:00.317657+00
cf216479-921f-43ea-9964-ad7ce4d11498	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	764a8eda-8b72-4942-b588-59f0f053ccb9	\N	Uy	Zarafshon 6/25	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:00.858232+00	2026-04-01 13:23:00.858232+00
14a4c71b-c243-4db9-af22-c02e4a9988e1	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	305add72-1d0b-4260-95d6-e92d0ad0a4b1	\N	Uy	Zarafshon 6/33	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:01.371328+00	2026-04-01 13:23:01.371328+00
832606db-1e68-4c99-be60-f4a85a4f7f9d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	9510b260-b97b-49e6-8665-e5ca025703db	\N	Uy	Zarafshon 10a/20	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:01.795643+00	2026-04-01 13:23:01.795643+00
93620c42-704b-4a9f-b631-e6637707081e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	6c83e5ef-423e-4248-b9d5-ab49af47ef40	\N	Uy	Sireynaya 13 /46	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:02.339256+00	2026-04-01 13:23:02.339256+00
9c4ef36b-bcb5-4977-98fe-cd055582882f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	89837f6e-c92e-49c6-a4b7-744a8916ada8	\N	Uy	Kattaboĝ 98	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:02.785585+00	2026-04-01 13:23:02.785585+00
398d296e-5caa-42ae-a896-da4e9be73fcf	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	ad31e76a-60ce-4f41-8948-9ea84941c62a	\N	Uy	Agronom 544	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:03.296225+00	2026-04-01 13:23:03.296225+00
383344ce-af91-4c30-98ce-c712a9545b13	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	f6b12263-ef39-43d2-9233-745caf77e2c0	\N	Uy	S. Ayniy 69b/46	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:03.761342+00	2026-04-01 13:23:03.761342+00
a8ed0930-e865-4632-9797-fb48a31af8bd	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	f958cdba-80f5-49f1-a33a-5110bafaf2d2	\N	Uy	S. Ayniy 69c/106	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:04.234957+00	2026-04-01 13:23:04.234957+00
d417626d-e65f-431f-a99b-588dea8138ac	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	8cf3411c-dbb7-4704-90c1-88f2e937b648	\N	Uy	S. Ayniy 69v/302	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:04.69263+00	2026-04-01 13:23:04.69263+00
47275d0b-6074-4813-b268-81572a33b28c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	920fd145-bfe8-4608-b9da-fd8be86c513b	\N	Uy	S. Ayniy 71/51	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:05.155995+00	2026-04-01 13:23:05.155995+00
96b01ec9-0db4-47af-ae8f-e63cc7f01483	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	075e3a76-1e42-4dc2-8bc3-4fed2f86aef3	\N	Uy	S. Ayniy 71/60	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:05.80063+00	2026-04-01 13:23:05.80063+00
19f469a5-86e7-4d47-b701-eaea07265fcc	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	d690c3e2-fde2-49bd-8a1c-c94709c7194f	\N	Uy	S.Ayniy 71a/16	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:06.34468+00	2026-04-01 13:23:06.34468+00
300b5250-05a8-4746-aa33-ac101aa4e62e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	606eb0d3-0727-4219-b232-7bf37ec31aad	\N	Uy	S. Ayniy 73a/51	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:06.859401+00	2026-04-01 13:23:06.859401+00
ad8b6cd0-364d-45a7-9a6f-b3167cf24e04	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	eac385b6-b8cc-4baf-97af-0098e5a88a9c	\N	Uy	S. Ayniy 77/22**	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:07.395395+00	2026-04-01 13:23:07.395395+00
e4caa2e0-57f3-4b06-b598-074c3b758784	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	e3b613ab-fb0e-4c78-9098-c658a93d8821	\N	Uy	S. Ayniy 77a/5*	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:07.936665+00	2026-04-01 13:23:07.936665+00
c33a82cc-3cce-499e-baba-ed298ffdb8e3	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	7dcd8087-b88c-4a98-a7c8-ebd16eda0ce5	\N	Uy	S. Ayniy 77b/35	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:08.41692+00	2026-04-01 13:23:08.41692+00
7b11faf0-42bf-4403-945d-ff93e489931e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	f84c46b6-4773-4613-9bb0-9baab4b0b67d	\N	Uy	S. Ayniy 97/31	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:08.906615+00	2026-04-01 13:23:08.906615+00
53ad89c8-d679-4122-8801-b9f06afaff54	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	e2840844-e4f9-4788-bd6c-14fc015f8af8	\N	Uy	Bogidilkusho 5	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:09.438956+00	2026-04-01 13:23:09.438956+00
4c08c310-3960-4ea6-a9fe-0d64c53502e1	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	e44fb511-a1a5-487d-9ffa-1dc68c5e79dd	\N	Uy	Vadakachka ****	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:09.944154+00	2026-04-01 13:23:09.944154+00
061200ea-f88d-4ed9-b523-9ec6fae6908c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	d5da9baa-4f4d-4b0d-8a88-bb71c915008f	\N	Uy	Vinogradnaya 12/39	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:10.454789+00	2026-04-01 13:23:10.454789+00
ab0c1880-0f7d-4570-8acd-9c7ee8e01fdb	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	d7b3e917-a68f-40cd-8b97-cafbc267b4d3	\N	Uy	Pushkin 8a/59	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:11.265231+00	2026-04-01 13:23:11.265231+00
c07f010b-2957-474f-ad70-701395b5300f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	6cd0a008-4cd8-4a27-9284-b21d624380a8	\N	Uy	Pushkin 4a/57**	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:11.714736+00	2026-04-01 13:23:11.714736+00
39720b13-8df8-40c4-b9b6-ff3e3c224943	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	420cb719-fe40-4f70-9396-48b875c0b323	\N	Uy	Pushkin 12b/35	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:12.240164+00	2026-04-01 13:23:12.240164+00
a85dd646-036f-4426-a454-dd2915f2dc63	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	73ed9b63-6212-4d33-86b3-7f3cad4b8857	\N	Uy	Yangi dom 12	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:12.734554+00	2026-04-01 13:23:12.734554+00
1ddfa5be-131c-41a1-a8f4-ba800de729e8	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	66549d8b-6809-4a31-b0c4-d2a5fd47fcc1	\N	Uy	Uchquduq 2a/1	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:13.192008+00	2026-04-01 13:23:13.192008+00
4f647d92-3f68-4844-86b6-a125a0edabb7	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	37aa4d28-0cec-4f62-a7fe-1095f5b0ef2e	\N	Uy	Uchquduq 5/1	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:13.63839+00	2026-04-01 13:23:13.63839+00
57e76252-03da-4a3e-b106-94d11276e2dc	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	fd8dbcdf-4933-45dc-b7b3-cc60329e65c8	\N	Uy	Ibn Sino 2/17	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:14.093823+00	2026-04-01 13:23:14.093823+00
87288acb-b713-4583-871c-7bb2970c50f4	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	b6d3d7bb-fbfa-4676-8e3b-30f7a4019e2a	\N	Uy	Ibn Sino 11/1	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:14.534262+00	2026-04-01 13:23:14.534262+00
dbc26e0f-d3f4-48e9-b610-595768ea08dd	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	24b589d3-f9ff-42b4-80e3-bd366fa1659b	\N	Uy	Ibn Sino 16/16	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:14.98846+00	2026-04-01 13:23:14.98846+00
aef4ce99-7063-436a-b57c-aa80ab1761f6	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	df3d153e-3d76-40fb-8eca-81fab0b3ce37	\N	Uy	Ibn Sino 20/59	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:15.48326+00	2026-04-01 13:23:15.48326+00
e9389720-6ebf-4710-a177-79e0504409a8	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	a9358538-ea53-4037-ad97-af19b485c330	\N	Uy	Ibn Sino 20/72	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:15.99212+00	2026-04-01 13:23:15.99212+00
16087c7c-a797-4673-a90e-55e87e9bab95	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	e988bc4d-48f9-44cb-ad6a-ea46c12317ff	\N	Uy	Ibn Sino 39/9	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:16.455843+00	2026-04-01 13:23:16.455843+00
ed085ec9-d700-44e1-afaf-658b765c0dbc	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	48e60118-7f9b-4226-be9e-6ffa93e81ea7	\N	Uy	Ibn Sino 39/22	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:16.910649+00	2026-04-01 13:23:16.910649+00
3ff99fc3-e605-495a-9c47-a2984c944ec9	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	210ef789-7b1d-4f56-a9a5-1f7932103fda	\N	Uy	Ibn Sino 40/32	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:17.52762+00	2026-04-01 13:23:17.52762+00
02825069-4edf-415f-910e-526f5ce8c034	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	064b7ed9-a807-47f1-b1c1-42ed5a362a60	\N	Uy	Tolstoy 4/69**	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:17.958239+00	2026-04-01 13:23:17.958239+00
98b8a6f0-a803-456d-a7d6-f12f2e0e6da7	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	b9d4db45-8429-4683-ba3d-9e2a9cdfc6ac	\N	Uy	Tolstoy 6/23	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:18.414121+00	2026-04-01 13:23:18.414121+00
81342ede-30c3-4dcf-9067-a9e41986ea4c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	a35e5df0-5b60-4231-a316-618e071f2858	\N	Uy	Tolstoy 8/63	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:18.869519+00	2026-04-01 13:23:18.869519+00
68a6121d-9bb2-4eb7-a078-37b99e0ed09a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	6f227f12-b472-41ae-be21-686e9903e785	\N	Uy	Tolstoy 11/5	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:19.413196+00	2026-04-01 13:23:19.413196+00
8909b6d3-32ce-4b1c-a13e-4e1e95cf8b3c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	8dbd2b4e-0fea-4fc9-9d9a-646f50cc68a2	\N	Uy	Tol 11/salon	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:19.905585+00	2026-04-01 13:23:19.905585+00
df23f0e8-dd56-43cc-97ea-1e47ab9c4c61	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	9484423c-94e4-44cf-9e0a-089055166311	\N	Uy	Tolstoy 16/7	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:20.379532+00	2026-04-01 13:23:20.379532+00
fd1dbef2-8774-4a1f-a972-2268ca9b00ee	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	2b92548c-4535-46b8-86a2-355696800f04	\N	Uy	Tolstoy 21/9	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:20.838951+00	2026-04-01 13:23:20.838951+00
2e00f0e9-036a-42aa-ad1d-9ba914c654b1	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	c43327fe-dfde-4b09-afe0-1a7defe4622c	\N	Uy	Tolstoy 21/22	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:21.393789+00	2026-04-01 13:23:21.393789+00
b11d911b-474c-4490-8114-f346b98755f5	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	f98fcdc0-4882-41b6-bbdb-a5ea99aeb035	\N	Uy	Tolstoy 21/33	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:21.816215+00	2026-04-01 13:23:21.816215+00
136d9a62-9d79-4506-a542-20aa174a2928	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	436f3dfb-e72f-46ee-876f-bebc8bf11e24	\N	Uy	Tolstoy 25/9	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:22.528039+00	2026-04-01 13:23:22.528039+00
713c2231-e1ae-4801-aaea-60ce76c18321	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	9c992e40-103e-4f42-90a5-ea9b29007b61	\N	Uy	Tolstoy 34/38	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:22.99584+00	2026-04-01 13:23:22.99584+00
d1177339-01ee-4ab5-9589-73f695f8c02b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	ec532b90-2517-4259-81f6-cdb31b38fafb	\N	Uy	Tolstoy 36a/15	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:23.499111+00	2026-04-01 13:23:23.499111+00
89c78238-174e-466d-a241-e8f125df56ff	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	39ba6d40-eaf6-486c-b7a2-a5e2468d738b	\N	Uy	Tolstoy 38/30---	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:24.029726+00	2026-04-01 13:23:24.029726+00
c7cdd897-15ae-4545-a540-2505eb644136	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	4a97f34b-ed04-4574-8a2b-0c21ed34b92e	\N	Uy	Tolstoy 42/22	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:24.570164+00	2026-04-01 13:23:24.570164+00
878e1982-bd2a-4fb2-bcf0-274124cac2e1	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	29f8ba53-233a-4eb7-a140-c44651b267f7	\N	Uy	Tolstoy 42/33	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:25.103253+00	2026-04-01 13:23:25.103253+00
b372c953-f76b-4848-97dd-6b4dfcdde4dc	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	d1565c8d-22e6-4769-adb5-3d4dd3df969f	\N	Uy	Tolstoy 50/50	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:25.574944+00	2026-04-01 13:23:25.574944+00
a1097abd-6e8e-4aca-875e-a5b5422d50fd	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	131cdbc9-209c-4c25-b851-0587ca1e536a	\N	Uy	Tolstoy 50/112	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:26.031258+00	2026-04-01 13:23:26.031258+00
61c78a54-ec77-43d9-b61c-a820a4f97dbb	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	fbb5915f-92e5-470b-8076-08825a8a12d6	\N	Uy	Tolstoy 50/127**	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:26.520658+00	2026-04-01 13:23:26.520658+00
e4cf5d14-4b8e-4620-ac58-6029134f72dc	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	08e72f13-0e55-409d-947e-c81d0d0f2449	\N	Uy	Tolstoy 50/130	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:26.984084+00	2026-04-01 13:23:26.984084+00
f3150a20-4f8d-4795-8792-35fb442ac4be	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	f55c58e7-ca39-4caa-98fd-3a18d7b41ad0	\N	Uy	Tolstoy 51/6**	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:27.473039+00	2026-04-01 13:23:27.473039+00
a5ab0290-cee6-41c0-8ed2-ae77006f2b7c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	bf35e1a6-5230-4165-a891-796bcd19eebc	\N	Uy	Tolstoy 51/63**	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:28.031836+00	2026-04-01 13:23:28.031836+00
71741bbb-abc1-4a9f-9d95-21285b860a18	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	a1dae8ac-bd49-4a1e-a0a6-28e998cb4f30	\N	Uy	Tolstoy 51/87	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:28.543642+00	2026-04-01 13:23:28.543642+00
85d08f3a-8b4b-4426-8659-d64938e4a22c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	5a06e635-7b5d-484e-bf7f-09625b9f02b0	\N	Uy	Vatanparvar 46/14**	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:29.027592+00	2026-04-01 13:23:29.027592+00
ebcc78b3-cfb8-4dde-9612-e9e01b9a7e5e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	b5f93600-4a1a-4f9e-b3fa-a5a772a0239b	\N	Uy	Vatanparvar 46/19	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:29.514281+00	2026-04-01 13:23:29.514281+00
9a6a0a66-684f-46ac-a329-4de42d269713	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	a8ced727-ffde-43ff-ac27-73a2016c2ef1	\N	Uy	Energetic 1/4***	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:29.983261+00	2026-04-01 13:23:29.983261+00
4e01767a-e4c1-4674-85fe-4bbb14728dd0	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	111a8d21-4be8-4261-8d3e-43ac79a78249	\N	Uy	Energetic 8/24	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:30.527168+00	2026-04-01 13:23:30.527168+00
ebc0bcc1-089c-4563-960f-f59d3d3e88b8	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	c23d2a8f-8307-4bdc-a875-04fa03665516	\N	Uy	Energetic 10/70	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:31.012932+00	2026-04-01 13:23:31.012932+00
795d244e-c264-445a-a77b-de2ada3a3980	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	edc79e78-357e-4aa6-b75d-cc751f125e15	\N	Uy	Yujniy 1a/6	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:31.568799+00	2026-04-01 13:23:31.568799+00
d7416a10-c1fb-4d53-844f-b52ab4cb273e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	dbe46c91-5482-457d-a82c-2f5fa970096e	\N	Uy	Yujniy 8/9 katej	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:32.035332+00	2026-04-01 13:23:32.035332+00
61ebde2e-1a5b-4cd3-b667-a0f5257343c7	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	66e116f9-9a9e-4295-bf86-31dadd6dadd6	\N	Uy	Yujniy 9/4 katej	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:32.522962+00	2026-04-01 13:23:32.522962+00
225fa1d6-1695-458f-840e-38790820d8ab	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	072efbab-73a9-49b7-a1d3-b1160e32ce1f	\N	Uy	Yujniy 8/11*	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:33.059313+00	2026-04-01 13:23:33.059313+00
a730db79-2ba5-4ce7-b35f-cc5d349ee726	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	e1b7f1f9-ab03-4d82-8a02-9fa66d98da49	\N	Uy	Yujniy 10/6**	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:33.536977+00	2026-04-01 13:23:33.536977+00
674ca8e4-ec5b-449d-88dd-3a08619ec589	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	eab5efa6-9e7f-411c-b577-bf0253f9d7a5	\N	Uy	Yujniy 10/8	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:33.972196+00	2026-04-01 13:23:33.972196+00
47af2c38-23b7-45b8-a90f-022d9b1bb7c6	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	bbe2fa89-9888-4597-a17f-500c02c7ca2e	\N	Uy	Yujniy 20/31	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:34.43059+00	2026-04-01 13:23:34.43059+00
bd66d4ea-08d5-4b58-aaaa-bbca547d3856	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	106c0098-ea6f-4b5a-adbb-666b77cd8ecc	\N	Uy	Yujniy 20/55**	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:34.926281+00	2026-04-01 13:23:34.926281+00
c4c3567e-668d-4bd1-a833-6fdb8071b091	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	2e1d0c49-8ce0-4a3e-8430-da6c7136655f	\N	Uy	Yujniy 20/74	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:35.436317+00	2026-04-01 13:23:35.436317+00
39b128ca-6b11-4fd8-86cc-86de829fe4ce	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	499527a8-60ac-4ff3-b32d-383fcbe32c37	\N	Uy	A Avloniy 1/2a*	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:35.890561+00	2026-04-01 13:23:35.890561+00
c9b76acc-c46a-4832-beca-a28bd6fe90b4	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	df2d183b-e661-4f5c-8e90-0ad0115b2a8c	\N	Uy	A.Avloniy 20/26	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:36.416385+00	2026-04-01 13:23:36.416385+00
48f65f6a-c4fd-40eb-bf0a-06867f2b3e7a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	f5ab7458-4c32-47a2-8812-b13c9ee5347d	\N	Uy	A.Avloniy 37/38	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:37.077644+00	2026-04-01 13:23:37.077644+00
d54c7359-3bdb-4c2e-82cf-bfdd50e24e20	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	cb8f365b-c1f3-48a8-a1cc-6da09d7af357	\N	Uy	A.Avloniy 39/3	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:37.534059+00	2026-04-01 13:23:37.534059+00
80596d18-73ad-4ad9-acaa-dd49a7c97de8	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	3569b818-5989-49da-bc06-acb7d3a05b93	\N	Uy	V. Nonvoyxona	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:38.068751+00	2026-04-01 13:23:38.068751+00
3a7854fe-6edf-4fba-af90-43c223a45b3d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	55661e0d-4686-4af0-8092-78803fb66646	\N	Uy	V. Chinor 4	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:38.525772+00	2026-04-01 13:23:38.525772+00
4722a73b-8ac2-4c53-8657-e377f2109303	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	c99e232a-f998-4da1-9a2e-cc3912f74375	\N	Uy	V. Paxtakor 12	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:38.974157+00	2026-04-01 13:23:38.974157+00
46f85edb-4700-4316-8c38-a25bf5256cbc	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	06fb3c2b-382b-4ef5-84f6-137e43ccf2a8	\N	Uy	V. Yangiobod 19	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:39.488266+00	2026-04-01 13:23:39.488266+00
3d573e44-ba9b-4ee8-9aba-6ca2f688c566	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	0250f1d0-04dd-4c97-9f58-0d4d7d58eb22	\N	Uy	V.G.Bunyodkor 8a/5	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:40.026389+00	2026-04-01 13:23:40.026389+00
ef1999c6-e15f-4d75-b8b4-511bb6cf9563	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	53861b78-13c1-4f29-8fc0-2e243c38976c	\N	Uy	V.G Bunyodkor 17/1***	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:40.50604+00	2026-04-01 13:23:40.50604+00
7cb2be5a-9d7f-491f-9a31-4521786bae16	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	3871ee1c-1e8d-4288-a7a6-c15462a21057	\N	Uy	V.G Binokor 5/3	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:40.949752+00	2026-04-01 13:23:40.949752+00
b8ad2944-50bf-4221-9a87-a1fae9d91249	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	72b4157d-29c8-480a-a057-9ff3aef65c33	\N	Uy	V.G Binokor 13/14	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:41.554858+00	2026-04-01 13:23:41.554858+00
74ce8aff-0245-4b2d-8328-a7258bd7d094	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	3b273c06-b5a3-4bdd-8c96-9c42c717cad8	\N	Uy	V.G Talabalar 53a	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:42.023082+00	2026-04-01 13:23:42.023082+00
252eea4f-839b-402f-81d8-318a9ebd79d3	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	dd5a9ed0-bc8e-4be0-a3eb-a42b68ac9fb7	\N	Uy	V. S.Ayniy 43	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:42.521562+00	2026-04-01 13:23:42.521562+00
83c91795-50b4-4c4f-8070-8574dd38d02c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	b73afcfe-156a-4fe2-93d8-d88c3cae7dbb	\N	Uy	Galaba 71/6	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:43.04498+00	2026-04-01 13:23:43.04498+00
6d106e38-0a98-4a79-8b8a-9d922b8dba05	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	e04f45a1-ac80-484e-8388-6101c2f47822	\N	Uy	Galaba 71/54	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:43.533213+00	2026-04-01 13:23:43.533213+00
f47e5923-dd56-457b-8635-d6a9df469038	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	dc333dd2-b63a-4836-8722-378635bdf61a	\N	Uy	Galaba 71/55	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:43.984117+00	2026-04-01 13:23:43.984117+00
263c4b1c-9a6e-47c1-924f-f4cc04500df3	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	e4ec6ecf-0e00-41fe-abba-efad1364382c	\N	Uy	G'alaba 77/8	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:44.481837+00	2026-04-01 13:23:44.481837+00
d35d4693-4f20-4453-8dac-4e7ac6c6811c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	61579bf4-beb4-418d-b45c-307ee6561067	\N	Uy	Galaba 77/15 --	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:44.967113+00	2026-04-01 13:23:44.967113+00
ed55d5c0-f324-4bad-8822-5f6953ff0a41	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	e5ba8d94-8740-4569-b7cd-889419a4f4c5	\N	Uy	Galaba 77/34	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:45.453364+00	2026-04-01 13:23:45.453364+00
afed3745-1c83-44f2-9719-da15c7e8e82f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	aee67132-c499-4e26-ba27-00d9dec1a6e6	\N	Uy	Galaba 77/48	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:45.95619+00	2026-04-01 13:23:45.95619+00
9c7e5c89-c8fb-4d00-9498-a147176e7024	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	444069bd-e6f0-4984-9e5d-05444bb22424	\N	Uy	Galaba 79/4 --	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:46.447286+00	2026-04-01 13:23:46.447286+00
dbbf97d8-cb66-484d-8d62-27d2d7f63181	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	8149fbcb-f47f-43d3-af4d-b5a3e4c3aaee	\N	Uy	G‘alaba 79/22	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:46.935979+00	2026-04-01 13:23:46.935979+00
38000835-40f3-4800-9968-065913a3b53e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	f15a6fd0-95fc-4dbc-9e10-979a72807259	\N	Uy	G'alaba 79/49	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:47.429419+00	2026-04-01 13:23:47.429419+00
935f6a48-6e27-42e6-96b1-f74948f10599	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	c39075a8-e115-4bef-a286-7347b01e0909	\N	Uy	Galaba 81/42	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:47.862473+00	2026-04-01 13:23:47.862473+00
246fed6f-7b17-42fd-a0b4-db2e5d38ba81	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	f72897a2-d084-458c-88eb-d7506ffab2ef	\N	Uy	Galaba 83/64	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:48.366864+00	2026-04-01 13:23:48.366864+00
8dfffc5c-c4e6-4557-a4f6-4b937ef68204	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	7f6d242c-ee4a-4630-bbdf-3345a3c49453	\N	Uy	Galaba 85/91	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:48.801469+00	2026-04-01 13:23:48.801469+00
4cdaf07c-e27d-4e2f-bd41-91790fc221c4	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	ebbdf4e3-145c-4bdc-bdc4-0938ff30a40f	\N	Uy	Galaba 85b/39	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:49.283291+00	2026-04-01 13:23:49.283291+00
a483bfb6-0567-448d-9fca-5a5569b4a63b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	63ac14b0-5479-493e-ba55-6fbbc1812783	\N	Uy	Galaba 85b/43	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:49.779462+00	2026-04-01 13:23:49.779462+00
eeeebcdd-9f23-4d9a-8598-0bd801ddc18b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	23fd2107-93aa-4f58-b67d-2be09d07699b	\N	Uy	Galaba 87/23	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:50.289397+00	2026-04-01 13:23:50.289397+00
34309944-1235-40b9-83dd-9d2872df80de	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	cd103036-321e-4f79-9b1c-da0486312e17	\N	Uy	Galaba 87/45	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:50.788775+00	2026-04-01 13:23:50.788775+00
f6bdb1cd-3997-423b-82f1-10b45068d917	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	b3afc62a-5e6a-4756-9f95-4970ecfc8455	\N	Uy	Galaba 89/26	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:51.322835+00	2026-04-01 13:23:51.322835+00
50b2b88a-5e2b-4295-a2b0-0e84781f8a50	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	a5f6a0de-f886-438d-9644-0edb63a3a62c	\N	Uy	Galaba 89/33	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:51.806812+00	2026-04-01 13:23:51.806812+00
326b27c8-406e-4b1f-a195-86f2f6b2ebfc	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	898578c3-7965-4fc3-af5e-fa53c0354e82	\N	Uy	Galaba 106a	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:52.31268+00	2026-04-01 13:23:52.31268+00
458402cc-4100-4fc9-8518-675f1d672aa6	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	e3d53f9c-4972-4dc7-be99-e1eed6175b63	\N	Uy	Galaba 107/7	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:52.790211+00	2026-04-01 13:23:52.790211+00
9f1fe17a-b2e1-4cbb-b484-dcfb07e96435	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	54a5e554-1a95-46cf-99db-96a96e6f55a7	\N	Uy	Galaba 111/36**	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:53.353729+00	2026-04-01 13:23:53.353729+00
b7850d10-a67a-404c-8bb5-a1da9fbc270c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	debf7984-3143-4531-959a-988ed16ff245	\N	Uy	Galaba 111/44	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:53.837868+00	2026-04-01 13:23:53.837868+00
fdfd705a-c3d6-4b81-ba1b-1869e8e145fe	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	11a5a3dd-bb7b-4c95-bb77-bdc8cdf597db	\N	Uy	Galaba 115/29**	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:54.347157+00	2026-04-01 13:23:54.347157+00
d6816641-16a8-4502-bafc-208574867afd	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	5d00144e-227f-42be-9cda-5a2d3e957912	\N	Uy	Galaba 125/42**	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:54.847926+00	2026-04-01 13:23:54.847926+00
11368222-34b5-4aed-8f92-b904a0f0ee15	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	fca8a80c-67a3-4f35-bc85-ba15cd39aa40	\N	Uy	Galaba 125/78	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:55.410186+00	2026-04-01 13:23:55.410186+00
f0d71592-f649-4142-8ea3-07c1d2ccd9e9	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	75e7aec7-141c-49fd-a6b8-85c4b2129baa	\N	Uy	Galaba 125/81	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:55.906556+00	2026-04-01 13:23:55.906556+00
32116c7d-23d3-490f-a012-25e952984ced	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	2d894c91-3685-4ed9-af96-47724bac7cd7	\N	Uy	Galaba 127/79	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:56.449493+00	2026-04-01 13:23:56.449493+00
04ce8b5e-e88c-48ae-ad62-aa115f37577d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	8a7a20a5-5706-4871-82e0-edf6bb97bd24	\N	Uy	Galaba 127/124	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:56.995915+00	2026-04-01 13:23:56.995915+00
01a0aaa9-2ea4-467e-ab63-c97800af6ed5	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	1a85b3f4-61ca-43c1-8ea1-d5b1bed2de04	\N	Uy	Galaba 127/132	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:57.506799+00	2026-04-01 13:23:57.506799+00
e572cd2a-9189-4220-b3b6-a4b04469da1f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	a9dbcf31-12dd-499e-881b-c3b5854f56ba	\N	Uy	Galaba 127/139	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:57.939814+00	2026-04-01 13:23:57.939814+00
825615cf-cb54-4d9b-be1d-e917b71f06af	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	261b3526-f134-47d7-8616-81e353fc5a6f	\N	Uy	Galaba 133/78**	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:58.501021+00	2026-04-01 13:23:58.501021+00
04b5bcad-22a9-4ad5-bc41-7c25bfcf11e7	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	d20b38a3-fa4f-43f9-b1e6-b238e242352c	\N	Uy	Galaba 137/1/15	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:58.916456+00	2026-04-01 13:23:58.916456+00
8ffc48e5-21a6-4bd7-8024-7228f7065f85	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	ad0815af-f3ae-4455-8088-078246b4ab7b	\N	Uy	Galaba 139/1/37	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:59.358266+00	2026-04-01 13:23:59.358266+00
d1212f69-8a45-4ed9-b3b3-6cae35428a17	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	93d5734f-f91d-40bb-a845-80960edee28f	\N	Uy	Galaba 139/2/36**	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:23:59.797183+00	2026-04-01 13:23:59.797183+00
77b77034-62e8-4115-bcfa-d347ed65223d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	d3811557-86b3-460f-a1c9-3460b20e057e	\N	Uy	Galaba 139/3/19**	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:00.297073+00	2026-04-01 13:24:00.297073+00
77530222-3022-49a6-920f-3c0149099826	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	99e3b206-f7f4-4c1f-a57b-9e2cfd9f9daf	\N	Uy	Galaba 139/3/29	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:00.805765+00	2026-04-01 13:24:00.805765+00
bb7d835b-3fc4-4bac-9126-3855a6e92cee	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	d9f78b84-d676-42fc-b06f-d4d6c718f427	\N	Uy	Galaba 139/3/30	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:01.372257+00	2026-04-01 13:24:01.372257+00
93670775-4efa-4212-a8c1-b3d9dea62d6d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	b26b3dbe-5199-4d52-9750-851be763e3e7	\N	Uy	Galaba 145/18*	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:02.010711+00	2026-04-01 13:24:02.010711+00
f044b550-9318-4c9f-9705-6dbed62cfbff	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	edcce916-4eb7-4244-b293-6854fa7d7ac5	\N	Uy	Galaba 147a/7	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:02.647226+00	2026-04-01 13:24:02.647226+00
b9217f83-89b0-420a-abd0-56c4eed3ad42	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	b9d1d0a2-3b34-4489-9061-dbeec668917d	\N	Uy	Galaba 147a/11	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:03.154415+00	2026-04-01 13:24:03.154415+00
bf1b1ef7-5a91-4947-a5fd-c7381a331403	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	8561c9d5-576b-4ce8-9f0d-b24091c8a953	\N	Uy	Galaba 149b/3	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:03.650719+00	2026-04-01 13:24:03.650719+00
1058e824-8aa6-4d44-886c-5c3d330511d8	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	7f261050-e655-4667-b06a-fd01f64dfcd3	\N	Uy	Galaba 147b/40	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:04.119722+00	2026-04-01 13:24:04.119722+00
ff1c4dfa-4d83-460f-81d4-c8ae661f245b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	91f773c7-98a2-4d8f-b838-95ef7ca79566	\N	Uy	Galaba 157a/32	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:04.579656+00	2026-04-01 13:24:04.579656+00
616015ad-086a-48cc-845c-071026b1658c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	301812aa-f04d-4862-bfb5-8c9a596f4ba2	\N	Uy	Galaba 159/21	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:05.055867+00	2026-04-01 13:24:05.055867+00
b38fbd3e-f48f-46cf-8d81-e758bd272300	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	a3ea5b21-4772-4fb9-bff7-f14e0956d4f3	\N	Uy	Galaba 160b	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:05.507186+00	2026-04-01 13:24:05.507186+00
a8d3936d-d6bd-4e1b-b23e-6a868a870e17	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	03b998c3-6769-4a9b-8236-1fb0a8948653	\N	Uy	Galaba 188a/2	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:05.944036+00	2026-04-01 13:24:05.944036+00
019e22ad-66ed-4ffd-8139-694172d97459	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	c4875fa6-7606-4a4d-b4fa-35a20c3338ec	\N	Uy	Galaba 188b/2	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:06.415557+00	2026-04-01 13:24:06.415557+00
42b5f6a2-e001-4cce-bf66-ed746ff82b4b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	3ef9fe7c-13c0-4738-8767-d412f82d6070	\N	Uy	Galaba 188b/7	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:06.851848+00	2026-04-01 13:24:06.851848+00
08afb378-2893-4499-816f-3643b1ab633a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	aa7c942a-5ea7-4220-a794-464ff98165b5	\N	Uy	Galaba 188b/13	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:07.412242+00	2026-04-01 13:24:07.412242+00
6b298b43-195a-4512-add4-e3dfb7ac7e70	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	bac3d156-22a6-49e6-bd0f-73fbef06fbe3	\N	Uy	Gʻalaba 172a/38	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:07.888032+00	2026-04-01 13:24:07.888032+00
3c3d2e89-1c17-4b9a-bc2e-ce51b44e09e6	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	4a13cbcd-98df-4c88-bbf9-900443b45149	\N	Uy	Galaba 194a/38	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:08.442007+00	2026-04-01 13:24:08.442007+00
219c2fa6-39da-4985-b3a3-e5fce4a7c4c3	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	2ac26eb9-db0f-47fa-971f-6421418e4697	\N	Uy	Galaba 196a/6	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:09.029226+00	2026-04-01 13:24:09.029226+00
38a53e20-ddbf-46ce-86ca-930414fde9e2	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	4a233dde-0e31-4086-8549-dbcd2890f34d	\N	Uy	Galaba 198/21	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:09.617171+00	2026-04-01 13:24:09.617171+00
10d1d47d-7230-4a80-9b4f-b01f12f55754	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	79fd5b33-33b4-458f-9555-e8fc8121b649	\N	Uy	Galaba 200/31	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:10.142914+00	2026-04-01 13:24:10.142914+00
b19f535a-e393-4492-8794-8388fe310f6c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	44556f24-f520-447b-9668-ca65ed851cdd	\N	Uy	Galaba 204/87**	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:10.622711+00	2026-04-01 13:24:10.622711+00
ac7ff421-66d2-49ee-866c-37cb72506851	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	4243e5b2-b553-42e4-b9fa-fee9b85ab5cd	\N	Uy	Galaba 206a/27	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:11.111483+00	2026-04-01 13:24:11.111483+00
d45e58cc-1e72-4ffb-a636-22c759e56789	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	12c8c269-4002-416d-814c-b9ff748bb68c	\N	Uy	Galaba 208/24**	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:11.690216+00	2026-04-01 13:24:11.690216+00
e5f3bd68-e00e-4351-8b41-01824c290a7f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	a841f652-72be-413c-88fc-e8dc7327ad79	\N	Uy	Galaba 212/7	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:12.383237+00	2026-04-01 13:24:12.383237+00
8d5f7c73-1316-4a85-a491-d8e77476447a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	3ed89eb6-3754-438c-b75f-f455a042facb	\N	Uy	Galaba 212/10	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:12.883575+00	2026-04-01 13:24:12.883575+00
93c7f163-1396-4d41-a864-6c3970f96944	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	3e9b3c1b-a1d3-4fb0-b2ba-7a09fb6123b2	\N	Uy	Galaba 214/43	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:13.377714+00	2026-04-01 13:24:13.377714+00
3ec40240-ba71-4c56-b7c3-239d8490acac	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	a29253e4-a94d-4347-bfee-c1e9b105aac0	\N	Uy	Tinchlik tashkilot	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:13.873996+00	2026-04-01 13:24:13.873996+00
3d06f11b-5498-44ca-a490-052ccfb73636	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	4fb6d6f3-a459-47a2-9fbf-74d1ed8e28cb	\N	Uy	Tinchlik 6/2	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:14.388523+00	2026-04-01 13:24:14.388523+00
d5b403b7-91d9-4b0c-896c-9b16602767a7	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	003cc1f1-ad96-4426-b4a9-ea38241740cb	\N	Uy	Tinchlik 11/3	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:14.860924+00	2026-04-01 13:24:14.860924+00
3e4def37-9be6-4d03-9d53-dbe7827d3c2b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	f9a7fb04-0196-4c92-b095-6e7392430210	\N	Uy	Tinchlik 15/6 Xasan	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:15.393308+00	2026-04-01 13:24:15.393308+00
fd03fc0a-97dd-4252-96e0-2974cea5bd27	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	1e202b44-c623-4b5f-9c6d-6c6ad53c381a	\N	Uy	Tinchlik 24/5	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:15.869271+00	2026-04-01 13:24:15.869271+00
e623a86d-e4a6-4921-b8d0-2d665f6bb2e7	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	209926fe-8695-47e0-9994-be764d4f4dad	\N	Uy	Tinchlik 24/17	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:16.419257+00	2026-04-01 13:24:16.419257+00
85c0cc75-fdb3-4501-ba4b-486d38aa2ed9	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	544923ab-3af5-41fa-9477-28acdd5fc9fd	\N	Uy	Tinchlik 24/18	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:16.899555+00	2026-04-01 13:24:16.899555+00
6c5bdba7-faaa-4a2e-990f-886feb7b2294	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	f897790b-3e06-4ea4-b8dd-d16035b4d8eb	\N	Uy	Temir yul 32/2	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:17.363813+00	2026-04-01 13:24:17.363813+00
10604bd5-517b-45af-8472-20f43edc90ca	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	6efe7f33-ec96-42b1-90ba-8aecfe06d9d4	\N	Uy	Poliklinika.                           ,116-, 120-, 121 936659397, 124,125,128, 127,129-,130,131,142, 212*,214,220 ,222,223,224,225,226,227*228,229,231,244	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:18.008953+00	2026-04-01 13:24:18.008953+00
a9d2304f-4ef3-4d9d-895b-d94ad0ded476	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	b501e78a-4044-4be3-87b3-941af8fcd82d	\N	Uy	Guliston 13/2	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:18.447157+00	2026-04-01 13:24:18.447157+00
1d542bda-5903-453b-9d39-5491ba78b3f1	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	ea8b1a4f-4119-4984-abd4-b46a402f9790	\N	Uy	Guliston 1/1	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:18.981778+00	2026-04-01 13:24:18.981778+00
d13fee3b-ff42-4e87-8019-816b7c3b9bb3	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	b415f473-adc1-4d4c-ac74-17f8d0594873	\N	Uy	Guliston 3/78	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:19.462077+00	2026-04-01 13:24:19.462077+00
25f0f67c-5436-4076-af95-80f723b4347e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	02066572-aca7-4389-8a06-963cf9569a8b	\N	Uy	Guliston 3/390	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:19.943979+00	2026-04-01 13:24:19.943979+00
dea43e2f-5f61-438a-9a39-31cfd286c306	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	7a8b9715-c10b-4aff-afac-550ccae2a9a5	\N	Uy	Guliston 3/419	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:20.434622+00	2026-04-01 13:24:20.434622+00
9f7da557-ef67-4cf2-bb25-452ec055bcb8	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	4b42e6f8-de09-450c-b13d-5a30907bc2e3	\N	Uy	Guliston 3/494	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:20.895861+00	2026-04-01 13:24:20.895861+00
c869854c-65d5-4645-87a1-ba3b45daf452	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	dad338b6-dd95-4cf1-b41a-200b3980a4e3	\N	Uy	Guliston 3/548	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:21.404249+00	2026-04-01 13:24:21.404249+00
cf05e8a4-5d81-400a-bd3b-0a8802274f5b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	a9ac3aba-3099-4166-9a45-e8f5ee619aee	\N	Uy	Guliston 3/599	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:21.854026+00	2026-04-01 13:24:21.854026+00
5ccfa4f4-61c1-4e48-b66c-d5a606b187fa	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	6022233f-5295-4e75-a2b8-a40ab1e31c8d	\N	Uy	Naqshbandiy 11*	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:22.326535+00	2026-04-01 13:24:22.326535+00
1bdfe0d3-5f29-4ec2-80ab-740c62a8a2f9	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	7bb79e53-4e60-4bce-9d41-7fa887e5e760	\N	Uy	Naqshbandiy 43	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:22.835052+00	2026-04-01 13:24:22.835052+00
c5f08ba6-4865-4af1-855b-7e4c05ecd852	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	b602bc68-920c-496c-a868-0616a69d8463	\N	Uy	chutqara med	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:23.325587+00	2026-04-01 13:24:23.325587+00
50f99bc6-db5c-4d09-8def-330e94f63d9c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	d91368ec-3b7f-49df-a7ae-ab4ba7452d4b	\N	Uy	A. Buxoriy 5	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:23.734868+00	2026-04-01 13:24:23.734868+00
c6b71a59-2ec4-49a0-b47d-4bde8033b05c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	32b3aaad-a9f6-4938-8f00-2b16e696a519	\N	Uy	A. Buxoriy 217	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:24.359611+00	2026-04-01 13:24:24.359611+00
64c99c05-460a-4f8a-8baf-6012bbe54324	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	ed5f173e-5eff-4d01-8613-70456a1792f7	\N	Uy	A. Yassaviy 139*****	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:24.819855+00	2026-04-01 13:24:24.819855+00
688a4f44-6778-40d0-ba7c-0f2b4e269165	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	bc9a4815-3777-4959-a6e7-1f393463bf07	\N	Uy	A. Yassaviy 244	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:25.348592+00	2026-04-01 13:24:25.348592+00
8fa89b21-5712-43af-bc62-f6946b64a15e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	04bde6c0-5018-4d97-a636-5d7671f4f736	\N	Uy	Registon 2/30***	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:25.808437+00	2026-04-01 13:24:25.808437+00
5cdc5965-bc3d-42eb-8380-9c274edc2f79	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	45183256-1265-490d-8ec9-094db721d0dc	\N	Uy	Zirabuloq 17**	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:26.261521+00	2026-04-01 13:24:26.261521+00
1dc29c27-2fc3-4237-8d32-b0270955bfd7	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	f8f3f5db-9d6c-4cc3-932d-6c7f74dc4c2f	\N	Uy	Zirabuloq 18	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:26.680492+00	2026-04-01 13:24:26.680492+00
fa4f77df-9c32-4ebd-845c-2fdc69f529ec	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	6fc404fc-81bd-4fbb-bd05-afa36d2a7229	\N	Uy	Naqshbandiy 315	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:27.12884+00	2026-04-01 13:24:27.12884+00
2a167290-8dca-4488-b609-29aeb60e1693	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	f50ee6a9-b1a7-4980-bb45-79dc00fa6bf9	\N	Uy	Naqshbandiy 356	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:27.571527+00	2026-04-01 13:24:27.571527+00
958e4ae0-36f1-487d-bab7-4a6a49c084ab	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	a3628222-1eb0-41be-9544-8aff59b38caf	\N	Uy	Qizilqum 408	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:28.061215+00	2026-04-01 13:24:28.061215+00
5a5c3e97-db60-4393-8443-bd5eb8fe44a1	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	3ec2c733-fcae-4212-94d9-c0f3971c50ad	\N	Uy	Termiziy 33	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:28.519969+00	2026-04-01 13:24:28.519969+00
7804f451-f520-44c0-9e78-57381c0fc011	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	2290367a-1612-486c-9c89-12695914b909	\N	Uy	Zirabuloq 32	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:28.963171+00	2026-04-01 13:24:28.963171+00
f0ec3009-76b9-40f6-8b02-70800553d72e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	2a34aafa-aaa5-4ebf-b331-a2c438607a4c	\N	Uy	Mehr 6	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:29.508936+00	2026-04-01 13:24:29.508936+00
ba4fe187-331e-4bbe-806e-ab56a2491641	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	f787a2ea-e303-4b7c-9128-dffc4c8f0aa7	\N	Uy	Afrosiyob  35	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:30.003015+00	2026-04-01 13:24:30.003015+00
89d71544-cf15-47a8-8d6c-0e9592200500	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	d486645a-67dd-4300-964e-b0b031ad3a19	\N	Uy	Maʼnaviyat 145	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:30.523043+00	2026-04-01 13:24:30.523043+00
ea5330fb-dcb0-4d66-a4a3-4ec09e9011bb	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	079082d0-582a-47e0-a833-1b1d54801357	\N	Uy	Manaviyat 13	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:30.981316+00	2026-04-01 13:24:30.981316+00
59216c20-2dbd-4759-a79c-a91dfa0e69be	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	2b704768-d7f9-4eda-9ec1-7a4f261e7d93	\N	Uy	Nihol 200	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:31.496031+00	2026-04-01 13:24:31.496031+00
963d4911-93f1-46cb-91e5-492e00ff0ba3	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	3f4fea26-ae3a-4554-99f4-071e55124f2e	\N	Uy	Gulboĝ 1/13	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:31.969446+00	2026-04-01 13:24:31.969446+00
1ca7f201-b075-4375-a549-7c85e370b8f4	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	477ac103-024b-40ce-826c-b81777aabbd3	\N	Uy	Gulbog' 88	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:32.442054+00	2026-04-01 13:24:32.442054+00
2a12a4ab-6938-4867-9b4c-8c3e840e3d16	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	9d1e9c08-1317-4163-928f-5b780fb4d16a	\N	Uy	Marifat 23****	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:32.968487+00	2026-04-01 13:24:32.968487+00
c40072d7-948a-4bd8-a302-4b831b722476	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	b2fdf877-50b4-4c2e-854c-0ec0880c49ab	\N	Uy	Tong yuldizi 54	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:33.445858+00	2026-04-01 13:24:33.445858+00
37e9efcd-2e74-4ea9-9bf1-3e2dfb1ff78b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	4a0c92ad-9f5b-4c53-801e-20c9ebcf1047	\N	Uy	Istiqlol yuldizi 27	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:33.871494+00	2026-04-01 13:24:33.871494+00
c757d998-9923-4dc2-9011-7e91ba6d6f18	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	6340f5d9-c977-4ab1-9885-4f3f0a3fbb7c	\N	Uy	Me'morlar 57	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:34.371565+00	2026-04-01 13:24:34.371565+00
4bd9666f-0bf6-466c-9941-abee851f2e31	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	4a766f0f-29f3-40f5-b37e-62b728c203c5	\N	Uy	Nizomiy 96a	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:34.820369+00	2026-04-01 13:24:34.820369+00
e4c6bd5b-75ae-4a23-923f-de37ef1c00c0	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	92f61f46-b859-415b-baa9-4bec87a3f21d	\N	Uy	Gulchilar 57	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:35.296431+00	2026-04-01 13:24:35.296431+00
65269d72-2fab-49a3-a5a3-4aa37b16a0d6	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	8f1fab06-3273-40a0-8301-18887f770f12	\N	Uy	Baxt 31	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:35.767831+00	2026-04-01 13:24:35.767831+00
aad19b12-6c9d-4a8a-8c5f-b829b6c51690	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	fa5d4ea3-63ec-4dee-af23-d9425bc5e449	\N	Uy	Yangiobod 9	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:36.231171+00	2026-04-01 13:24:36.231171+00
ff50409d-2f8b-4002-a923-5cc88cfb0fd0	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	147e0489-1efc-4c98-a9ee-20633cefe5cb	\N	Uy	Shifokor 14*	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:36.683289+00	2026-04-01 13:24:36.683289+00
99c7448d-87e8-4c22-ad30-24c7b779ed60	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	661ff2ec-2b79-4620-8853-9cd9055d7af7	\N	Uy	Varq 162	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:37.155649+00	2026-04-01 13:24:37.155649+00
bef332b1-0d74-41d4-a0ea-4acb0f3ae615	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	1081f144-218f-41e6-a28e-4b7686e429e4	\N	Uy	Birdamlik 48	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:37.724366+00	2026-04-01 13:24:37.724366+00
7b345501-5d74-48d0-83de-4c8cbe3e5875	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	41e2e791-e6bf-4df7-8be4-61f9a4c44e60	\N	Uy	Birdamlik 121	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:38.21915+00	2026-04-01 13:24:38.21915+00
47de9d0c-15d5-46d5-8954-5fbe366496ba	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	0ccecc9c-3e23-4ef3-a897-861d289f62c9	\N	Uy	Birdamlik 196	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:38.69332+00	2026-04-01 13:24:38.69332+00
6756e658-7f76-4441-acdf-65ca27a5b239	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	19a4ee72-6578-4e49-8e65-b1fbd5c1835f	\N	Uy	Sardor aka	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:39.188071+00	2026-04-01 13:24:39.188071+00
ef6b6038-937d-42b7-b07e-398f60094e97	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	5c5c49d9-ba2f-41ae-a370-26b675e1b90c	\N	Uy	X. Dòstligi 23****	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:39.753914+00	2026-04-01 13:24:39.753914+00
99d861ae-5b48-4cd1-baff-cf590ad657e9	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	d9ff1b3d-0093-46a6-8921-ed4dfc250a00	\N	Uy	Alpomish 57*	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:40.270631+00	2026-04-01 13:24:40.270631+00
33a8d119-70b2-4eb9-8667-aa2b761ed423	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	30acff12-02aa-4d13-bc2f-845c3375a68e	\N	Uy	Alpomish 64****	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:40.751548+00	2026-04-01 13:24:40.751548+00
49f8c951-8713-4a21-a9f6-6c17b656f7fc	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	d3aa5020-704a-432a-83ed-f8ff92a088bc	\N	Uy	Bog' vatanparvar 15	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:41.281865+00	2026-04-01 13:24:41.281865+00
02a6d6b0-5945-4d89-af63-eb5344a78a4d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	4965bb0d-1b64-4f68-a0ba-622dc3625816	\N	Uy	E.Sh. Kalovot 134	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:41.826093+00	2026-04-01 13:24:41.826093+00
2680cac1-da47-45db-b262-3b574e850e82	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	fb739ef5-6857-405e-803b-be80de7a5ceb	\N	Uy	E.Sh. Qiyot 7	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:42.323357+00	2026-04-01 13:24:42.323357+00
29d66cd1-7239-4b2b-bbe8-d4cc88a18d17	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	24851f68-c232-48a4-bac8-16480f740b04	\N	Uy	E.Sh. Qiyot 356	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:43.019211+00	2026-04-01 13:24:43.019211+00
5b8e8a5e-5286-4efd-878b-86d81fbc4d9e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	d74010e7-e71b-477c-a34d-c31fa046dc84	\N	Uy	E.Sh. Bahor 65	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:43.711108+00	2026-04-01 13:24:43.711108+00
e462c66b-e23e-4ef4-a480-2129d835e5bb	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	15faeee7-7963-4081-92d7-ecc4bfd0b7a8	\N	Uy	E.Sh. Bahor 176	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:44.222957+00	2026-04-01 13:24:44.222957+00
0e7f049f-e10b-4b28-9ba0-2335fa532f67	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	1ceb4b86-a900-4227-bedd-bd09fff066c0	\N	Uy	E.Sh. Uzb 51	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:44.741303+00	2026-04-01 13:24:44.741303+00
b1c1a4c7-326a-4a44-af53-bf44559f7b02	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	5ae5bcb5-1998-4489-a804-32205d3522d4	\N	Uy	E.Sh. Uzbekiston 20	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:45.275419+00	2026-04-01 13:24:45.275419+00
ac943838-1d76-4db5-976f-d16d980fef1a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	1ed50ffd-d3bd-4082-a831-77f5402adde4	\N	Uy	E.Sh Uzb 29	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:45.77041+00	2026-04-01 13:24:45.77041+00
8864ebcc-38b0-4cae-92d3-7ccd1893449a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	91ccd181-dd45-444e-94d3-baea58e6ab8e	\N	Uy	E.Sh. Uzbekistan 112	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:46.301521+00	2026-04-01 13:24:46.301521+00
f057dec0-e687-489b-978e-787edb4adb6c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	9e769539-1f71-4d65-9ce9-c2d9128c3ff5	\N	Uy	E.Sh. Uzbekistan 215	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:46.958625+00	2026-04-01 13:24:46.958625+00
8f9f1cd5-6d1b-4afe-a3be-c49daceb15ed	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	a700bef1-b65b-4c50-b909-f56c81c49d1a	\N	Uy	E.Sh. Chexova 49	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:47.494387+00	2026-04-01 13:24:47.494387+00
03ff63a4-28a4-4d22-851b-25be99c2f69c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	ea04dc5c-a088-4c9e-8d79-21625fe59dc8	\N	Uy	E.Sh. Qosim Shayx 17	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:47.941109+00	2026-04-01 13:24:47.941109+00
4b778c82-cb6a-41d4-bf7c-9c90253f2a5b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	d09f4527-4938-4c36-b543-85f13208d56a	\N	Uy	E.Sh. Qosim Shayx 26	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:48.486799+00	2026-04-01 13:24:48.486799+00
17f0d55b-f8c6-4e4a-9e44-917799af7bf8	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	13ab0ccf-d75a-43de-aa11-4ea627ddc52e	\N	Uy	E.Sh. Mulkobod 98a	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:48.946112+00	2026-04-01 13:24:48.946112+00
62a68a35-6210-4c63-b2e8-1b683d5dc02a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	b5ae0c60-4b00-4ea1-96e0-356175b7b7e9	\N	Uy	E.Sh. Mulkobod 198	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:49.498792+00	2026-04-01 13:24:49.498792+00
47db0d0e-9f32-4a50-8282-5600d811d886	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	95920c3b-7a97-4c5d-9554-18803bb585f8	\N	Uy	E.Sh. Argon 1/3***	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:50.242309+00	2026-04-01 13:24:50.242309+00
0764a946-3c8a-412f-b254-a809af01beb7	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	54720f4b-248a-4093-a71e-37dbbfde4f6f	\N	Uy	E.Sh. Argon 17	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:50.711662+00	2026-04-01 13:24:50.711662+00
e38a3bbd-286e-4619-ab9e-96782bc35a0e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	7fa1be37-b546-4d16-afd5-9942f66b6c26	\N	Uy	E.Sh. Arģun 32	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:51.253664+00	2026-04-01 13:24:51.253664+00
3fb96c10-c87b-4649-8a9f-820f7958cf9b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	2bc3c5d4-b742-4bb3-9158-d19b73c7acf3	\N	Uy	E.Sh. Argon 147	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:51.720598+00	2026-04-01 13:24:51.720598+00
95a30203-0ac9-4246-9b1f-6b7e57eb943c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	181d868f-f755-4410-b306-6464d45122b4	\N	Uy	E.Sh. Shodlik 3	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:52.221508+00	2026-04-01 13:24:52.221508+00
eeb38026-e1a0-4704-8e38-c9b969fe494e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	ad91bc56-95e2-42a0-93af-e73d009762c3	\N	Uy	E.Sh. Shodlik 8	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:52.667445+00	2026-04-01 13:24:52.667445+00
b0138c39-8d21-438b-b65b-dacd685d8ac5	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	0f2c1388-e768-480b-8273-605e3d941e23	\N	Uy	E.Sh. Shodlik 11	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:53.119462+00	2026-04-01 13:24:53.119462+00
9077ad5b-ff7c-4fd3-b08e-83c5784d334a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	9575391e-4334-4798-a4c7-77bf0a36d7e0	\N	Uy	E.Sh. Shodlik 13	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:53.685388+00	2026-04-01 13:24:53.685388+00
4d5175f5-7ff5-425f-a9fc-372fcf29182e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	f9244e5d-0aea-4b1f-a885-a5c5ebd2fce9	\N	Uy	E.Sh. Shodlik 34	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:54.17685+00	2026-04-01 13:24:54.17685+00
5557710c-ed18-47c4-92a4-037a4f56f8fd	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	a51e6fd9-c501-46ef-84cb-1d0116e701cc	\N	Uy	E.Sh. Muqumiy 75a*	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:54.667469+00	2026-04-01 13:24:54.667469+00
97fb44d0-5cd9-49c9-8de4-18b4412411e0	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	596ebc0e-f791-4f02-b832-e6803572d40d	\N	Uy	E.Sh. Yangiariq 24**	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:55.378991+00	2026-04-01 13:24:55.378991+00
d3ade740-ab2e-416a-88b6-2ce4327cb527	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	a3115180-2fac-43a2-8f9a-1af1f7197ee2	\N	Uy	E.Sh. Yangiariq 100a	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:55.860667+00	2026-04-01 13:24:55.860667+00
6b59480d-2285-43ae-94ac-dca57792b32d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	21617674-8198-4d2d-83a1-d1be3e4d2bdd	\N	Uy	E.Sh. Yangiariq 246	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:56.40926+00	2026-04-01 13:24:56.40926+00
42169d44-6c8a-4e00-8b43-8cd3b83f7b42	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	a2f66d78-1d31-49ce-b523-e4560e8c0f37	\N	Uy	E.Sh. Xujahayron 66	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:56.898671+00	2026-04-01 13:24:56.898671+00
82875657-60fc-430e-8e6d-1ee8aa4e4c04	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	18f14b24-4f17-4e47-887f-cf79eac106c0	\N	Uy	E.Sh. Chorboĝ 85	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:57.400138+00	2026-04-01 13:24:57.400138+00
f8478a70-60d0-455c-b249-b894149b811b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	8e8bf47d-99c1-4010-8c0d-50e6ce584497	\N	Uy	E.Sh. Ilĝor 40/1*	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:57.850071+00	2026-04-01 13:24:57.850071+00
224b8dd6-c185-4c70-8666-145e8dd557b3	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	7e3cec7f-36ae-4aa7-8bdf-fd0d9a394c96	\N	Uy	E.Sh. Ilg'or 44/2	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:58.304417+00	2026-04-01 13:24:58.304417+00
188297ff-b28d-48c9-a542-acb5e567ea0f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	8d54ad74-36ce-43da-97ef-8472d2e24779	\N	Uy	E.Sh. Ilĝor 45/7	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:58.850628+00	2026-04-01 13:24:58.850628+00
71fe10c2-ed68-4c0d-a856-76bf9a522a9f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	c6fa8718-acee-4eef-ae43-ae217a563d89	\N	Uy	E. Sh. 5etajka 54	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:24:59.632329+00	2026-04-01 13:24:59.632329+00
8f0243aa-07ab-41ee-8145-d95bbe5729ba	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	d1ce2f03-0679-4177-b431-b2df0a131bae	\N	Uy	E.Sh. 5etaj 63	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:00.163605+00	2026-04-01 13:25:00.163605+00
dc996ce3-20ef-48f5-9052-5b3637531e18	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	3dd1ae5e-7ec5-45f2-9195-861732d82329	\N	Uy	E.Sh. 5etaj 46	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:00.663061+00	2026-04-01 13:25:00.663061+00
35b8b4c9-a141-450b-8aa9-e552cf98695f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	a6702838-8531-49d1-9319-44b0b36d801d	\N	Uy	E.Sh. 5etaj 56	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:01.230559+00	2026-04-01 13:25:01.230559+00
5ed67880-68c1-4148-b901-8993572599eb	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	2c2b2d91-1dbf-4e95-9c9a-2c1df30ae396	\N	Uy	E.Sh. Shirin 2/2	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:01.694683+00	2026-04-01 13:25:01.694683+00
7155d1b9-aaa9-44ed-b20d-4933b8e02ca1	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	6aa785b3-e1ea-47b0-94bc-0f1b83d1c736	\N	Uy	E.Sh. Shirin 2/7*	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:02.215539+00	2026-04-01 13:25:02.215539+00
136f1324-66c4-4f95-b93e-152163fd1f68	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	53370087-9c36-4f2e-8208-1a541f547cb5	\N	Uy	E.Sh. Shirin 2/9	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:02.667386+00	2026-04-01 13:25:02.667386+00
d5eaee1d-5b51-4e05-a319-dc7c87a3cf75	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	83cad9c4-1abe-417b-88c3-fbbeae03a500	\N	Uy	E.Sh. Shirin 14/5	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:03.166253+00	2026-04-01 13:25:03.166253+00
7df66049-11b8-4d54-bdbe-7da58eb014f6	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	d07142d9-3ef1-4ce8-b481-75a791a78e3c	\N	Uy	E.Sh. Shirin 46	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:03.638688+00	2026-04-01 13:25:03.638688+00
92341f68-01be-43e7-8430-e668cea4c05c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	6d44d8d7-8b2e-4b47-9759-29bd28bdbe99	\N	Uy	E.Sh. Farxod 30/12/1	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:04.151719+00	2026-04-01 13:25:04.151719+00
1af19c38-61ec-460f-94a9-d09deb1bcddd	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	3d7a8d38-1dec-4972-9969-da4a0c1e06f5	\N	Uy	E.Sh. Gulbog 6	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:04.628064+00	2026-04-01 13:25:04.628064+00
c11b2cf8-22b8-4f6c-ad00-9afa7acef3e8	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	b9698bb9-df94-401d-b8fe-ae781cab118a	\N	Uy	E.Sh. Gulbog 29	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:05.120175+00	2026-04-01 13:25:05.120175+00
157e1cc5-9ab9-4c52-8c83-0b5e8dbf69e2	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	aa46a08e-dd6c-4a6d-8d13-ef72c2f10db2	\N	Uy	E.Sh. Karmana 87	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:05.625914+00	2026-04-01 13:25:05.625914+00
491a1a9c-53e5-4fde-9d24-86e9cc8fc7c4	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	82be5dd2-6baa-4fa4-a081-f73d160419cd	\N	Uy	E.Sh. Toshkent 47	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:06.088599+00	2026-04-01 13:25:06.088599+00
a1022261-a425-4b18-96bd-c2da65e21202	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	4bf25a7c-2c42-404c-9b86-437081001cd7	\N	Uy	E.Sh. Toshkent 95**	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:06.519052+00	2026-04-01 13:25:06.519052+00
3ca540a4-e7d7-4c17-93a3-f4b38bbb2478	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	ea14e67e-7b90-474d-9816-7341d4c5ad57	\N	Uy	E.Sh. Gulzor 21a	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:07.011786+00	2026-04-01 13:25:07.011786+00
7753cb78-a1f2-4ae6-8dc9-df10570df099	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	9760942a-0be5-455c-8e28-391a31e78078	\N	Uy	E.Sh. Kuxinur 39	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:07.523589+00	2026-04-01 13:25:07.523589+00
e691b0c1-9d82-47ca-9d09-73c3669d2ed6	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	955bbd70-6f96-4ecd-b581-f40ffd92c0d0	\N	Uy	E.Sh. Jasorat 12	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:08.027782+00	2026-04-01 13:25:08.027782+00
9a39a8fc-1ff3-40b8-b63e-0f4f52845316	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	96089e5c-4ef2-4a34-9a36-6c5f16a61348	\N	Uy	E.Sh. Jasorat 28**	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:08.513629+00	2026-04-01 13:25:08.513629+00
cbef0bc9-5bef-47c9-874f-928122a285f3	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	87b13e1d-079a-4f5b-b84e-3f04369e4edd	\N	Uy	E.Sh.Afshona 45	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:09.251962+00	2026-04-01 13:25:09.251962+00
f0b52194-25ea-4b0b-bb98-ad17af9ac06d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	77e42a02-ffda-49a8-a477-66eb41ac7464	\N	Uy	E.Sh. Usto Shirin 49	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:09.812342+00	2026-04-01 13:25:09.812342+00
a909e709-77a0-4222-b0f0-bfccebc6a2b8	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	180302dc-2922-4d38-ab55-d9413b50b305	\N	Uy	E.Sh. Bunyodkor 26	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:10.389831+00	2026-04-01 13:25:10.389831+00
415a5234-39fa-44df-87bf-61d3f052bd73	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	8b2fad8d-877f-4da7-b78c-ce03239b766b	\N	Uy	E.Sh. Bunyodkor 28	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:10.951307+00	2026-04-01 13:25:10.951307+00
8b5e32dc-7aa4-450c-bf95-dab264c402e9	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	c6abd21b-a1f5-4839-b001-36ea56ceba94	\N	Uy	E.Sh. Karmana city	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:11.518185+00	2026-04-01 13:25:11.518185+00
7171ea3f-1746-4c0e-b4cf-e854be9669b8	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	b67d45cc-903f-4fa2-a881-c3fb22c5c984	\N	Uy	E.Sh. Talqoq 2/37	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:12.050005+00	2026-04-01 13:25:12.050005+00
31cb010f-adb5-4856-9c26-4463be2c145b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	7444462e-085c-4137-87af-5a34f41f813b	\N	Uy	E.Sh. Talqoq 2/52	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:12.583294+00	2026-04-01 13:25:12.583294+00
c1f6d0ca-c6a2-4686-86a3-e392f830dded	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	43842f42-5ec2-444f-a268-32c8f40ac4c5	\N	Uy	E.Sh. Talqoq 4/12	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:13.061469+00	2026-04-01 13:25:13.061469+00
7f479742-41b7-4d2f-be27-a5bc9c377fde	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	1b737d3b-8740-4a57-b326-359dcf82f7db	\N	Uy	E.Sh. Talqoq 4/29	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:13.577094+00	2026-04-01 13:25:13.577094+00
f3d70f74-a919-4461-b4e6-6fab9ef9e848	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	5d6d0567-966f-426f-88c6-def59b2fd3bb	\N	Uy	E.Sh. Mustaqillik 56	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:14.084548+00	2026-04-01 13:25:14.084548+00
809604ff-e4f2-46db-9095-196a9f2c2d00	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	df5aac24-d8df-4127-a063-57d3e087ea38	\N	Uy	E.Sh. Mustaqillik 57	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:14.549089+00	2026-04-01 13:25:14.549089+00
627635ea-dd42-4cc4-a719-ffb298fcb199	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	9579eb94-c005-4c9a-8dec-951ff9c68ee2	\N	Uy	E.Sh. Mustaqillik 58	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:15.03077+00	2026-04-01 13:25:15.03077+00
c8ba4095-7776-4ac6-8985-ac5f3fef6faa	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	7560ce80-df95-4121-9d7f-091ebffd667a	\N	Uy	E.Sh. Transport orqasi	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:15.530838+00	2026-04-01 13:25:15.530838+00
8dea33c3-4ec3-400d-bdb2-2da1dc6816c6	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	1f2d82fa-ab24-45b1-9044-9959f3eca6a5	\N	Uy	E.Sh. Bogimurod 1	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:15.997346+00	2026-04-01 13:25:15.997346+00
5fe19485-26fe-4c0b-9f26-4a92b08d0553	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	cf695924-2fd1-4fb9-9189-522cf03b2477	\N	Uy	E.Sh. Obranon 294	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:16.486996+00	2026-04-01 13:25:16.486996+00
0bd2a366-08fe-4ded-b4b9-ede40ec32ce9	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	ff0e6363-5dcc-4582-a1dc-79e6d11d77d2	\N	Uy	E.Sh. Nurafshon 359 Jaloyir	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:16.920144+00	2026-04-01 13:25:16.920144+00
42bb17f3-4c28-428b-bb9a-fa773b800587	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	50f377a2-0731-4230-b352-24a7b5ae18c1	\N	Uy	E.Sh. Barchinoy 21	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:17.377902+00	2026-04-01 13:25:17.377902+00
47d114a2-1240-473b-8f30-219183111452	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	9a8250f6-c56e-4817-9032-aad5c3f2d1ec	\N	Uy	E.Sh. Barchinoy 22	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:17.857632+00	2026-04-01 13:25:17.857632+00
c392dfb4-db79-4da0-aed5-1c86dd84e477	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	7b2e88e7-951b-4913-9ad5-de95c406125f	\N	Uy	E.Sh. Qavaltepa 96	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:18.32529+00	2026-04-01 13:25:18.32529+00
7a24d8ac-7e4e-4bb5-bb62-b6c28426d17a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	c8d5da56-efef-40fa-89c5-141b910e521c	\N	Uy	E.Sh. Qavaltepa 187	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:18.783866+00	2026-04-01 13:25:18.783866+00
0831fccf-ec3e-423a-a188-41a14337cdb5	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	f62f4699-9571-410a-a003-87bb0a8f6002	\N	Uy	E.Sh. Madadkor 31	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:19.323031+00	2026-04-01 13:25:19.323031+00
acfb4189-f8d7-430e-b627-2b024e6de0da	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	55c4ba2e-ac87-4dd0-95a8-b801706fe09c	\N	Uy	E.Sh. Kattaqurgon 43	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:19.796149+00	2026-04-01 13:25:19.796149+00
2052a86d-63c8-401b-bfe2-5c1da617f4b7	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	9e8d70d0-a74f-447a-a404-1a4346b0f090	\N	Uy	E.Sh. Kattaqurgon 60	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:20.365954+00	2026-04-01 13:25:20.365954+00
61d6b4e1-4a09-4f18-90ab-59b4a86a966f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	f6a47482-8433-49eb-933a-3013319c46bc	\N	Uy	E.Sh. Kattaqurgon 70a	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:21.021647+00	2026-04-01 13:25:21.021647+00
415c1d6d-21d3-412e-844c-68b9d7d9b156	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	4a3ebeef-9619-41b9-bb95-8d2552f10daf	\N	Uy	E.Sh. Furqat 1/14	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:21.540304+00	2026-04-01 13:25:21.540304+00
0fb28be6-6f8b-4499-8f8f-2dd9b2fdcf71	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	9fa1c040-5bbd-4fee-9b7b-7c3767836c92	\N	Uy	E.Sh. Furqat 16	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:22.027817+00	2026-04-01 13:25:22.027817+00
621300cc-c753-4e8e-b9ad-c022cf8257cd	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	e7acbeab-2843-4861-8181-839ee95c2bea	\N	Uy	E.Sh. Farĝona 6	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:22.52376+00	2026-04-01 13:25:22.52376+00
bf191e5f-efa2-4e71-8a9a-4ca3f140d54e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	ffb7f9f6-7d03-44aa-8338-4ef7066134f2	\N	Uy	E.Sh. Farĝona 7	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:23.021774+00	2026-04-01 13:25:23.021774+00
b9bb56ab-462e-4043-bfb3-f724329165a8	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	cc43da7d-ab6f-4ac2-bec3-e75d23e14d6a	\N	Uy	E.Sh Nizomiy 20	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:23.545812+00	2026-04-01 13:25:23.545812+00
ee305b23-71df-4dc1-b6c9-68281b6d4694	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	5e72fa52-d8af-4302-9a75-932dd359b6bd	\N	Uy	E.Sh. Kulol 95a	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:24.0374+00	2026-04-01 13:25:24.0374+00
ea8a9d97-4324-45ed-9c1e-8daa47c45962	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	b8572e44-1b58-4d65-a149-ea2ff82aaf47	\N	Uy	E.Sh. Usmon Nosir 13****	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:24.666709+00	2026-04-01 13:25:24.666709+00
c301632c-1402-42c7-ae93-cc6a9b7406fc	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	7555c4bb-71ca-4d3a-8af4-1bdb5a262992	\N	Uy	E.Sh. Beshkent 11	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:25.243127+00	2026-04-01 13:25:25.243127+00
55062c2a-b923-4839-8014-ebb43191b6dc	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	369a4795-3364-4046-ba66-a2bfae4173fe	\N	Uy	E.Sh. Beshkent 13	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:25.770955+00	2026-04-01 13:25:25.770955+00
54f5aa19-2383-4046-909a-4f055b1a10cd	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	877330b2-42f2-4ffa-8773-a0e4591eca35	\N	Uy	E.Sh. Beshkent 18	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:26.287847+00	2026-04-01 13:25:26.287847+00
db97f560-918e-4261-abfd-84ed0a795177	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	8037ab97-00fc-425d-8c96-533649f2beb1	\N	Uy	E.Sh. Degaroniy 2/3	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:26.72657+00	2026-04-01 13:25:26.72657+00
1d85fe3c-12a1-4b26-b5fc-965d6f685e63	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	23242ca0-b4ef-46c6-8b14-881ee878f8a0	\N	Uy	E.Sh. Gagarin 23	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:27.1861+00	2026-04-01 13:25:27.1861+00
e9054557-78bd-41f6-b296-76a8ba937e09	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	974df00f-832e-48d6-9b75-b2994e91119d	\N	Uy	E.Sh. Gulom 20	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:27.623817+00	2026-04-01 13:25:27.623817+00
208fa7c1-73cd-47a9-89f1-bb0282f3fee2	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	afa03d10-c27e-41f4-ac85-465f3eccb0c0	\N	Uy	E.Sh. Mirsaid Bahrom 37	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:28.123582+00	2026-04-01 13:25:28.123582+00
1efff2ca-f68b-44bc-8181-5dc71a6897ff	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	a991e8da-d648-4adb-922d-1db8a78bb458	\N	Uy	E.Sh. Fitrat 5	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:28.58684+00	2026-04-01 13:25:28.58684+00
c79ba769-3516-450a-8da6-9ce214073c90	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	b666fec3-b580-4726-a2e2-05c2e6cf708e	\N	Uy	E.Sh. Dehqon 20	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:29.050634+00	2026-04-01 13:25:29.050634+00
fb06122f-9d0f-4545-a1e4-17b7492586f1	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	35542ff9-fd55-4e1b-b1cd-82d044a9604e	\N	Uy	E.Sh. Dehqon 41	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:29.6467+00	2026-04-01 13:25:29.6467+00
802d696a-b90e-45ae-8987-485bd11801ab	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	fc3d666b-7c17-4fc5-9764-1a15b350f849	\N	Uy	E.Sh. Dehqon 47	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:30.098074+00	2026-04-01 13:25:30.098074+00
478ed510-1109-4cfb-9d0c-16f8c94d988d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	89b8e7e7-7383-44db-8b21-17c81b949c03	\N	Uy	E.Sh. Xizmat uyi	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:30.589627+00	2026-04-01 13:25:30.589627+00
2c2165d5-c3e2-4ea5-9e63-cb968c5f9456	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	d0bbf5af-9813-494b-9c11-0f1ae496bbcb	\N	Uy	E.Sh. Gulobod 103	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:31.158261+00	2026-04-01 13:25:31.158261+00
76427086-411a-4210-b5ae-712f373bae0f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	afeecf5d-ab45-4660-b762-fbe0fb291706	\N	Uy	E.Sh Aliqushchi 1	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:31.607689+00	2026-04-01 13:25:31.607689+00
578cd89b-2da7-4857-b158-f9a9acf7287c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	014fceb0-3aaa-4fa4-a94c-957afa784de5	\N	Uy	E.Sh. Aliqushchi 39	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:32.039519+00	2026-04-01 13:25:32.039519+00
b3c17221-441e-49e3-961e-335241940330	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	1ea97899-6d3a-483e-944b-00226e4a7a72	\N	Uy	E.Sh Narvoncha	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:32.541742+00	2026-04-01 13:25:32.541742+00
b8e8ec1d-e788-4aab-93c8-07983ff3131c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	4792d0f3-9947-4de0-853b-ba1a00df7651	\N	Uy	E.Sh. Uyrot 47	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:33.218006+00	2026-04-01 13:25:33.218006+00
79efdd45-d40f-4b45-81b2-df721a4baf8f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	650dd524-71f2-498d-bcfb-14cac4e20c25	\N	Uy	E.Sh. Uyrot 53*	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:33.694125+00	2026-04-01 13:25:33.694125+00
2a14a6e1-741d-4645-b2db-c4af0dce459f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	75dc85df-f3be-4b1a-8d13-52282523651e	\N	Uy	E.Sh. Nurchilar 32	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:34.167234+00	2026-04-01 13:25:34.167234+00
9bc3b3df-f35d-459b-9360-30b68dfbb526	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	09bddfbf-afab-4db1-84b1-66ecdafe7d7e	\N	Uy	E.Sh. Nurchilar 84	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:34.691871+00	2026-04-01 13:25:34.691871+00
551c6cda-0352-4dc7-964c-bf3876b9065a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	663ac071-22af-4473-9d77-72fe476c1297	\N	Uy	E.Sh Nurchilar 119	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:35.149075+00	2026-04-01 13:25:35.149075+00
f63803c4-ecd4-4b75-b287-c54608924fc0	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	7be5fa1d-cddb-43bd-a6e1-1767bf41ad4b	\N	Uy	E.Sh.Nurchilar 121a	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:35.656623+00	2026-04-01 13:25:35.656623+00
935fba49-c0f9-4ffd-992c-ee1334526bae	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	9da9e8ce-e37f-45f9-816e-03088a1d4cbe	\N	Uy	E.Sh.Nurchilar 121	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:36.200998+00	2026-04-01 13:25:36.200998+00
0460b7df-0e55-4def-9b0e-f5e1ebd342b3	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	87ccf651-8739-4590-bf50-0fc0dcd1805b	\N	Uy	E.Sh. Nurchilar 124	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:36.646561+00	2026-04-01 13:25:36.646561+00
9e03b249-665e-4e05-9d20-933fec0bd7c9	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	5ed02d60-6e0b-4661-bdc7-a9ab63c95ceb	\N	Uy	E.Sh. Nurchilar 125	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:37.094654+00	2026-04-01 13:25:37.094654+00
197bc42c-de0a-4d5a-9fbc-fade8645b1f0	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	efec2a34-76d7-465f-9dee-93256478e664	\N	Uy	E.Sh. Nurchilar 126	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 13:25:37.566777+00	2026-04-01 13:25:37.566777+00
b691de53-507c-4948-8c7c-6fe03ead3dd3	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	4ad54089-6bce-4516-bb99-e6b2ca3eef37	\N	Uy	Ziyokor 153	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 14:09:44.451031+00	2026-04-01 14:09:44.451031+00
ecd27ca4-76e0-49a8-bd78-ad6e5b46278e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	7719bb2a-30e2-4dd3-906b-559d34c9c217	\N	Uy	Tinchlik Qoʻrgʻoni	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 15:33:15.324194+00	2026-04-01 15:33:15.324194+00
292799e0-c247-4c24-bd2b-edbd53d168e2	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	498ba42d-93a5-422f-a3bb-38584ccda1ba	\N	Uy	Tinchlik qoʻrgʻoni	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 16:09:06.986348+00	2026-04-01 16:09:06.986348+00
333dd9fc-ba7c-41ba-98f1-b58239410fa0	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	498ba42d-93a5-422f-a3bb-38584ccda1ba	\N	Boshqa	Niz 4/3	\N	\N	\N	\N	\N	\N	\N	f	2026-04-01 16:15:18.659804+00	2026-04-01 16:15:18.659804+00
057a43d8-2b83-4200-be93-f4a53160748c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	2576b21a-b0a2-4bc5-8c15-fcd2b7f23919	\N	Uy	Nizomiy 2/20	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:43:40.556664+00	2026-04-01 17:43:40.556664+00
33cf369a-e983-4bbe-a1ec-938629e1f681	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	1ccb0024-76f4-4f4d-ba9a-92a9cc66259f	\N	Uy	Nizomiy 2/24	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:43:41.057249+00	2026-04-01 17:43:41.057249+00
a193e442-a0cd-400f-8a54-6c38d8755077	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	9d67c915-05d4-448c-8057-c37a65df9c34	\N	Uy	Nizomiy 2/28	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:43:41.621029+00	2026-04-01 17:43:41.621029+00
5876f12e-7cdd-470a-b516-12377bd8bc1a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	ea5bc104-1b53-4154-aeee-911125a5f07f	\N	Uy	Nizomiy 2a/11	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:43:42.557108+00	2026-04-01 17:43:42.557108+00
0b65846c-5c4e-417f-8d52-305bd431b2ad	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	9ff5ebf5-d8c2-4343-84ec-00f2147bf17f	\N	Uy	Nizomiy 2a/15	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:43:43.164941+00	2026-04-01 17:43:43.164941+00
f28d7af3-96f9-4cac-ade2-8d7c87abae62	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	9ea09128-c3e7-460e-b1f3-6cf0c3b49b6b	\N	Uy	Nizomiy 2a/88	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:43:44.433872+00	2026-04-01 17:43:44.433872+00
5312751f-6423-49d9-b8a4-2d3397f3c87e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	2a52b6db-f7d5-47a1-ba55-c8258e751905	\N	Uy	Nizomiy 2a/112	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:43:45.087871+00	2026-04-01 17:43:45.087871+00
0fc6c822-79fe-4787-ae44-520ed4860e6e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	5789c989-5b21-4cc6-8e19-f0037f573dd4	\N	Uy	Nizomiy 4/7	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:43:46.554497+00	2026-04-01 17:43:46.554497+00
947528eb-0b38-41ef-80f2-ceb259efb751	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	5454a179-6c63-42fd-bd2f-b53da8731f66	\N	Uy	Nizomiy 4/16	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:43:47.23899+00	2026-04-01 17:43:47.23899+00
cb9f5872-212d-454c-988b-7e064088b1ba	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	750175ab-d48a-44bc-9a60-ba576a4f1f07	\N	Uy	Nizomiy 4/18	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:43:47.76094+00	2026-04-01 17:43:47.76094+00
6584ebb5-379d-40fb-833a-9f6b1f76691f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	dd72382a-ea5d-42d2-af55-10a802c5e848	\N	Uy	Shagzod, Islom	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:43:49.304455+00	2026-04-01 17:43:49.304455+00
4b82b4c3-259d-4145-a64d-6db2902e5e84	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	ef4ba25e-fc17-41a4-877f-fa427c3f0c4f	\N	Uy	Navoiy 46/33	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:43:55.18815+00	2026-04-01 17:43:55.18815+00
e28562f7-3b0a-4b1e-972b-0a1fe44c11d0	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	ed45443b-b464-4336-99fd-120b1f484237	\N	Uy	Navoiy 46/37	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:43:55.684269+00	2026-04-01 17:43:55.684269+00
9defb62a-9bba-485f-ac3f-3021d98209a0	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	7d34322e-44fe-4d86-850e-e102f3c8c23c	\N	Uy	Navoiy 52/66	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:43:56.850246+00	2026-04-01 17:43:56.850246+00
546439e8-c517-4a1c-82d8-0e148ca232bd	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	7e4473b3-b9df-4bce-9f6b-b9f3d42e3af9	\N	Uy	Navoiy 52a/b34	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:43:57.400468+00	2026-04-01 17:43:57.400468+00
85da61fc-fc08-4e8f-a9d5-a0581129605c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	5832ab74-e8b9-4e10-95bf-8bc6e1025029	\N	Uy	Navoiy 52a/38	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:43:58.15615+00	2026-04-01 17:43:58.15615+00
a8e414d1-e82e-4192-8f66-598382c98a8c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	2f43b891-7c89-4943-981b-4888063ab0ad	\N	Uy	Navoiy 54/27	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:43:58.944142+00	2026-04-01 17:43:58.944142+00
550581ac-e516-4490-9a9b-c335c4d8be7f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	db3c3d4e-8999-4264-abad-d60affdae5a5	\N	Uy	Navoiy 56/45**	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:43:59.840235+00	2026-04-01 17:43:59.840235+00
c0f212da-51a9-4852-9ae0-910b6f3c51fb	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	2efe2b86-ce51-47d3-b17a-5c8f78fb30b4	\N	Uy	Lomonosov 17a/5**	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:44:02.356646+00	2026-04-01 17:44:02.356646+00
0600c649-d8bb-40df-a285-1abcd0648a4b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	b053e2c1-0bf7-4310-858e-42cc3947e495	\N	Uy	Lomonosov 21/42	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:44:03.298843+00	2026-04-01 17:44:03.298843+00
45c8f837-af8c-424f-b47d-e5b066df6831	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	8b597269-391b-4983-91a7-1fad4cfdbb14	\N	Uy	Me'morlar 15a/26	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:44:04.376033+00	2026-04-01 17:44:04.376033+00
bddff664-3b0b-41b4-9154-24ad3d55f4e3	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	a4737ddb-833e-46f5-9e9f-e78e0ee1ea41	\N	Uy	M. Ulug'bek 1/23	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:44:07.654518+00	2026-04-01 17:44:07.654518+00
486a479c-0ad5-44c2-9485-3cef11989e79	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	c5eb2e30-d0bb-4cfe-9a08-7daa1a64658e	\N	Uy	Tarobiy 44b/65	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:44:11.734505+00	2026-04-01 17:44:11.734505+00
3afa58aa-cb92-4401-96d7-d7057b8eecfb	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	f245d534-1146-486b-bb2f-7a2cb6c4beaa	\N	Uy	Tarobiy 58/35	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:44:14.02583+00	2026-04-01 17:44:14.02583+00
eea13837-fa21-4199-a2b4-df6a64d161e4	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	8805867c-160e-4fbd-8326-b1fce9cefdb1	\N	Uy	Tarobiy 108/23	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:44:17.491026+00	2026-04-01 17:44:17.491026+00
825ef54e-1247-4254-91ff-5f90be34bed6	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	c0321a33-6996-40dd-96d5-5fa81bad2b66	\N	Uy	Tarobiy 109b/45	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:44:18.873011+00	2026-04-01 17:44:18.873011+00
e52bb1b5-0c09-448f-9b3d-67d5e3e1283e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	96259350-df59-478f-9cbb-331bb9212cd3	\N	Uy	Tarobiy 137/16	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:44:21.819413+00	2026-04-01 17:44:21.819413+00
16f72fbd-7265-436e-b79c-5ba55f0e8e83	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	a811a59e-1868-440b-a0ef-fcfa8e871d16	\N	Uy	Tarobiy 126a/12	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:44:23.274057+00	2026-04-01 17:44:23.274057+00
243f64d3-c439-4dcc-a775-1feb783ac36c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	9acdea56-814b-4170-b615-3f9160a450a7	\N	Uy	Tarobiy 136/23	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:44:25.313528+00	2026-04-01 17:44:25.313528+00
0a4534ff-dc16-4f30-9d21-7140ee46e42c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	22c6aeab-fa65-4d8a-9b70-c1c96b5293e0	\N	Uy	Tarobiy 136d/58	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:44:25.798319+00	2026-04-01 17:44:25.798319+00
709ab56b-73df-493c-b6c5-67cc42d92482	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	b98ccca0-f79b-4a4b-8dca-1f848ab89f63	\N	Uy	Yoshlik 7/117	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:44:28.702141+00	2026-04-01 17:44:28.702141+00
ab2e0bb8-6fa7-466d-b9d9-491b650e8243	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	bb42fd0f-dc6e-4882-b62b-e60756ca3d72	\N	Uy	Yoshlik 91/101 Maqsud aka	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:44:30.166979+00	2026-04-01 17:44:30.166979+00
9a2b5565-e933-4b67-9c58-6771cbf8a2f8	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	f66f3fb1-65c0-4217-a842-dff0ed47f721	\N	Uy	Yoshlik 114/11	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:44:30.835461+00	2026-04-01 17:44:30.835461+00
54b1d326-4029-4229-9685-2e5730485816	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	172fb0ba-a080-4ae6-85dd-d59495f966b1	\N	Uy	Karimov 3b/30**	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:44:32.887003+00	2026-04-01 17:44:32.887003+00
af4137a6-3e25-43e5-b2a7-c13c3462262b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	07d469f6-712b-4663-9004-589d66d9aae3	\N	Uy	Karimov 42/5**	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:44:33.565067+00	2026-04-01 17:44:33.565067+00
3438c0a6-bab3-4361-ae32-d725839a2f95	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	44428ef2-b48a-49fa-b8d6-d9a6d522b2b3	\N	Uy	Karimov 55/22	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:44:35.421481+00	2026-04-01 17:44:35.421481+00
3f9bb4f7-7e2d-409f-bc28-6385fcf87b2c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	c4a18744-8a5b-4410-9264-9e5902d01e39	\N	Uy	Karimov 70/25	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:44:37.346558+00	2026-04-01 17:44:37.346558+00
2b7c43b4-5c72-4c18-9b82-a5b9c6678e15	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	0bd6673b-8c97-4c9c-bb4a-45697cd24c34	\N	Uy	Karimov 96/104**	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:44:39.247854+00	2026-04-01 17:44:39.247854+00
3883852d-99cd-49ed-9b42-43716997be24	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	e73da619-943a-44eb-a5d5-4cb789198397	\N	Uy	Karimov 98/72	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:44:39.745237+00	2026-04-01 17:44:39.745237+00
9ba416d3-3a6d-46a8-8a6e-7780a29a826e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	42d42d5c-bcad-4007-aa91-eb904ccfdae6	\N	Uy	Karimov 146/30	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:44:46.317266+00	2026-04-01 17:44:46.317266+00
80aa7a45-5a59-4136-9fc2-135c8cfcd197	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	4d96d518-52c2-41bf-b3e8-a133703c6f13	\N	Uy	Karimov 148/3/45	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:44:47.709146+00	2026-04-01 17:44:47.709146+00
71e7f047-d956-4a50-8ce3-6103351cb30e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	4e5449ba-91dc-489b-878f-4c1178f05cbb	\N	Uy	Jasorat 30/50	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:44:52.080625+00	2026-04-01 17:44:52.080625+00
32cc138d-9b8b-459d-b65b-220a2ebc3d08	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	84b80046-fa01-4010-949a-c6d2f3fe49bd	\N	Uy	Jasorat 32/24	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:44:52.886137+00	2026-04-01 17:44:52.886137+00
cb080a63-ea56-44ea-9e5a-d4f711f40603	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	b4a52c9d-e881-40e9-be9d-39d5cdc9f392	\N	Uy	A.Temur 16/20	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:44:54.429688+00	2026-04-01 17:44:54.429688+00
b885728b-abf5-494c-9379-42982e233ec0	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	54483acb-42ff-4798-8f62-d75a915a986d	\N	Uy	A.Temur 36a/1	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:44:55.184297+00	2026-04-01 17:44:55.184297+00
94b3a60e-a1a1-439d-87f7-c3c2a3dc9b90	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	91cd510f-4a02-40be-beaf-8832a17da49f	\N	Uy	Uzbekistan 8/9	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:44:58.318558+00	2026-04-01 17:44:58.318558+00
0d3f21d1-8336-4bb5-96b4-d00b10d11661	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	c52c1ea7-8dcd-438b-a360-0bad42373ff9	\N	Uy	Zarapetyan 20/23	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:45:01.323803+00	2026-04-01 17:45:01.323803+00
540d29e1-b187-4c72-9efe-304160af35a4	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	49576e4e-162a-4c3b-bc88-b5387f7d121c	\N	Uy	Zulfiya 5/62	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:45:04.211789+00	2026-04-01 17:45:04.211789+00
6c9ffa80-9357-45f7-a9d3-3b900febd160	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	b41954f6-4ce0-4942-9a5a-8760e4f1b3a3	\N	Uy	Kamalak 70	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:45:08.052578+00	2026-04-01 17:45:08.052578+00
53f3b0f3-2f84-4c73-8a60-3eab8db32657	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	95951353-bd43-4505-b285-24efa5a7047c	\N	Uy	Ibn Sino 39/20	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:45:11.284917+00	2026-04-01 17:45:11.284917+00
2c5bdd97-13e6-4090-9c71-f4ba90a36a24	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	f60a9cbd-ad1a-4b35-a4a8-176a4b835d79	\N	Uy	Tolstoy 8/7	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:45:12.807872+00	2026-04-01 17:45:12.807872+00
124c4203-120c-4b9e-8fcb-bbfc7a78d4ba	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	d7a9a16a-cc6c-42d7-8e6a-7dfa0efe2266	\N	Uy	Tolstoy 47/36	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:45:15.714462+00	2026-04-01 17:45:15.714462+00
2fd1f0b5-0046-4430-878e-1845d218eded	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	2f072d90-ea37-4f3b-a364-e80efe69dc73	\N	Uy	Tolstoy 50/11	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:45:16.339138+00	2026-04-01 17:45:16.339138+00
b7b85f27-a243-46ab-a488-bf29ba333aa1	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	901f04b8-318c-450d-b694-5f1c7fd5ab07	\N	Uy	Tolstoy 50/37	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:45:16.81003+00	2026-04-01 17:45:16.81003+00
54aeb486-7d48-48a5-ab04-5e75cfb26b20	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	d8eb1bb0-739d-4048-a39f-f3e6f5647505	\N	Uy	Tolstoy 51/47**	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:45:18.065381+00	2026-04-01 17:45:18.065381+00
4dae3d21-7e6a-4501-9698-8ef486c294a3	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	35cd48a8-9c82-4fbb-8a4a-97ac809dc730	\N	Uy	Yujniy 7a/25	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:45:19.885877+00	2026-04-01 17:45:19.885877+00
b9b359ba-c1bc-4004-a2ca-bdd4235f4b92	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	5de00ad1-ed89-4de6-b476-2ed2bfedd978	\N	Uy	A.Avloniy 37/37	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:45:22.493442+00	2026-04-01 17:45:22.493442+00
2a26e535-3833-4418-8e8b-fbcd5f3ae3b8	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	f226190b-7a6b-46e4-be55-b50a3340d54a	\N	Uy	A.Avloniy KFS	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:45:23.432699+00	2026-04-01 17:45:23.432699+00
ceb379b8-7634-41db-be43-062c69a2439e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	253c85e6-987b-42aa-82e2-8bf3bebc4529	\N	Uy	Nurniso	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:45:23.93756+00	2026-04-01 17:45:23.93756+00
c9ec6941-abc7-4b43-9023-2205dc1b3c25	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	3c9cf004-be83-47df-b94c-1486b2ca8332	\N	Uy	V.G Bunyodkor 6a/2/3	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:45:25.301656+00	2026-04-01 17:45:25.301656+00
39a9ef01-1651-4e83-a04f-c3552242bbd4	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	c1df720a-6642-4922-9c86-fc91fa7c1ccb	\N	Uy	Galaba 81/47	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:45:28.736616+00	2026-04-01 17:45:28.736616+00
cced854f-4aaf-468a-b7e5-e5eba004441e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	bf3b552e-74d8-471d-9b73-1c5d8f8c73f6	\N	Uy	Galaba 147/51	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:45:34.480785+00	2026-04-01 17:45:34.480785+00
6ce77d9b-e464-419d-8471-87b8e14fdea1	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	65aecf3a-2206-488d-b825-bd2bf5171e81	\N	Uy	Galaba 188a/22	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:45:36.31086+00	2026-04-01 17:45:36.31086+00
d0b6ef68-f97a-4c62-94a2-275e84cb292a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	11d5905b-6f21-4074-baf8-d1a3b4988423	\N	Uy	TINCHLIK	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:45:39.525167+00	2026-04-01 17:45:39.525167+00
d24dc841-d4fb-4600-a3ad-af4c195f5777	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	c1b405ea-ae55-4f34-9440-d089fc7ccd47	\N	Uy	Tinchlik 13/2	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:45:40.56472+00	2026-04-01 17:45:40.56472+00
47890931-cc4c-474b-ace4-16e2ebae744d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	aeab8a6e-8258-4f8a-8e15-6f7e8d697937	\N	Uy	Tinchlik 24/7	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:45:41.432299+00	2026-04-01 17:45:41.432299+00
e6915830-8646-4a4f-b718-48c660461a5e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	5d690bed-491e-4525-9f2a-0100e094b498	\N	Uy	GULISTON	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:45:42.642687+00	2026-04-01 17:45:42.642687+00
ac01a130-93fb-4568-a80a-f816dbeeb3e8	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	e48a50d0-a3a9-4265-ad9e-c2ca01d3cf10	\N	Uy	CHUTQARA	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:45:45.474567+00	2026-04-01 17:45:45.474567+00
b77ede8e-3055-4963-998e-60bfc9f197c2	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	e83ab3f4-3d40-4cc7-a25e-45f107334e42	\N	Uy	Turkiston 27	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:45:47.182571+00	2026-04-01 17:45:47.182571+00
70d67ce1-029c-4e73-87d6-9e6b2978b132	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	8f0ad807-586c-4533-acfe-faf4256f76ae	\N	Uy	Registon 4/62	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:45:48.011851+00	2026-04-01 17:45:48.011851+00
1b4a84a2-e857-47e7-bd17-7e54a72a91b3	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	8247d082-3744-4c41-a22b-95a3d528da06	\N	Uy	Naqshbandiy 348	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:45:49.209639+00	2026-04-01 17:45:49.209639+00
f158ed62-0859-4d9c-8df9-cc3770f27fee	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	6be012f2-0ba2-4034-a3b9-123f27c4f462	\N	Uy	Naqshbandiy 333	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:45:49.857949+00	2026-04-01 17:45:49.857949+00
1ca294bb-6df5-4167-8c31-92d6a611e9f9	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	c4db3096-2e52-49f4-a20d-dd89f34fef9c	\N	Uy	DO'STLIK	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:45:51.203463+00	2026-04-01 17:45:51.203463+00
69b9b9e7-e73c-4643-af35-731d6f5c24dd	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	c98c4ff0-2fe1-4b9c-89df-6f108b3a6982	\N	Uy	Uluĝbek bobosi	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:45:52.190917+00	2026-04-01 17:45:52.190917+00
f338cbb4-6085-4281-b0a0-0761c53023d0	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	9187db33-aa29-421d-b6fd-e788a2921534	\N	Uy	UMID QURGONI	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:45:52.894249+00	2026-04-01 17:45:52.894249+00
c08f064e-f8fa-443d-840c-56261afd2593	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	1f61ca20-a029-4b95-ad0c-8364e3557214	\N	Uy	Gulboģ 90	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:45:53.788033+00	2026-04-01 17:45:53.788033+00
f4075a90-9bed-4f37-9d50-2f7009f1ab30	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	4c8a94c0-ecf6-4e1c-9a3f-81068a460b29	\N	Uy	Niz 2/59 Akmal aka	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:45:54.319654+00	2026-04-01 17:45:54.319654+00
37d5b4fa-9856-4a16-9d14-afe94a7c9342	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	c0321e4f-69cc-4a0f-b18b-8c10fcf9a218	\N	Uy	Niz 2/12	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:45:54.803616+00	2026-04-01 17:45:54.803616+00
563ef4e4-d35f-4860-b15d-bb91ff021708	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	c0108b0e-4a53-4a41-a4bf-47f096291cb0	\N	Uy	NARPAY	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:45:56.255148+00	2026-04-01 17:45:56.255148+00
72b8f5be-0f80-4929-bc16-1db316a02ad5	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	1bd49053-a2e1-4d50-abb8-ef24f984a0ed	\N	Uy	Karvon 69	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:45:56.739835+00	2026-04-01 17:45:56.739835+00
ea42a9f5-7bd2-4633-a4e7-e1f1c8b12611	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	876cde96-df35-4bfa-a16c-6f9f8e83f244	\N	Uy	Deya kateji	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:45:58.790851+00	2026-04-01 17:45:58.790851+00
a826a376-79ab-4703-8c88-c9d080cf1dcc	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	1b916815-9712-4651-acfb-e1eb01024208	\N	Uy	ESKI SHAHAR	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:46:00.017484+00	2026-04-01 17:46:00.017484+00
f17b4662-f3b2-494d-89e6-85d5827e06e2	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	4fbd8e1a-c0af-4576-b0ab-4fba15bb2ee7	\N	Uy	E.Sh. Bahor 37	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:46:01.675241+00	2026-04-01 17:46:01.675241+00
f33c2d92-2ce5-4694-988e-5e46e17634b7	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	4d13f79f-9884-4c35-b69f-348697616ef4	\N	Uy	E.Sh. Uzbekistan 38	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:46:02.332009+00	2026-04-01 17:46:02.332009+00
dc101cc1-4988-4afc-9dca-181c7a974b7e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	efeffa3a-f465-4f67-8333-0a2e5d3d635d	\N	Uy	E.Sh. Uzb 40	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:46:02.849529+00	2026-04-01 17:46:02.849529+00
fde8865b-2d71-4eab-b14c-ef7b0d9e8ef5	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	bab74d08-9f0b-49ff-a81e-ccbdfba6401d	\N	Uy	E.Sh. Saxovat 30	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:46:04.968402+00	2026-04-01 17:46:04.968402+00
c34ea065-9700-4305-9f9c-b532c2638447	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	a623f68a-8dd3-4e62-bfdb-cb4bf1d6f022	\N	Uy	E.Sh. Mulkobod 242	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:46:05.896932+00	2026-04-01 17:46:05.896932+00
0495e22a-5f90-4545-9360-027e25580337	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	5788538b-17a8-46d9-8222-2e36e0952bb2	\N	Uy	E.Sh. Argon 30	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:46:06.770844+00	2026-04-01 17:46:06.770844+00
749709f9-6a2d-4dfc-a6ac-8b1e64487b1e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	2e469a62-fdb3-4d2e-a21c-fe74a4ce2a4e	\N	Uy	E.Sh Axmad Donish 2	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:46:10.37034+00	2026-04-01 17:46:10.37034+00
16f58198-40b9-44a4-868d-007a5e03c8b5	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	7e7744c0-bce7-482e-ba48-cf757635bfef	\N	Uy	E.Sh. Jasorat Behruz	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:46:14.662163+00	2026-04-01 17:46:14.662163+00
e3faf467-df54-4e0b-a49a-f99574193008	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	b779333f-beb0-4dd7-9c74-07fc4acc90d5	\N	Uy	E.Sh. Kuxnaqo'rg'on 25	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:46:15.480982+00	2026-04-01 17:46:15.480982+00
4287d3d2-26d4-4f6f-bb73-89ba4927bfae	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	3f1c9476-49ab-41d9-a857-38d54a21a53b	\N	Uy	E.Sh. Bahor 51	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:46:20.578955+00	2026-04-01 17:46:20.578955+00
b0a5d8e2-5fb6-4cb1-aa54-169daa3b6b01	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	cdb2da54-227e-479e-88d6-836ba3317fe2	\N	Uy	E.Sh. Kattaqurĝon	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:46:23.69895+00	2026-04-01 17:46:23.69895+00
6c7acf85-4690-4d8d-b54b-a2d818e9b90c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	8da8a133-022f-4e85-9e4b-c8d70b3b6df9	\N	Uy	E.Sh. Chorravot 67	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:46:24.603394+00	2026-04-01 17:46:24.603394+00
2cb533c1-9c0d-4cea-818d-814bef2106e9	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	f8988854-92ae-417a-b5c8-9918f4936720	\N	Uy	315.0	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:46:27.064295+00	2026-04-01 17:46:27.064295+00
965f2ec0-f9bd-4694-b7d9-c7b12608dd5a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	a83c6785-b580-4d69-aac5-95419f6d802e	\N	Uy	2365.0	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 17:46:27.575792+00	2026-04-01 17:46:27.575792+00
c215485f-342b-468c-bd17-5ec1c41556a8	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	03c4b6b2-a592-447f-8258-fb56cdce6701	\N	Uy	Kids world	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:28:25.31966+00	2026-04-01 18:28:25.31966+00
60ec7f4d-0d85-4f38-b52a-33a7f9b2ea1c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	19f0f9af-e859-455b-9625-31aa17dbba20	\N	Uy	Tohir moyka	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:28:25.829551+00	2026-04-01 18:28:25.829551+00
fa7a64ab-7f43-4829-989b-07d4778f3f31	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	3b76ed23-0c4b-4956-844c-839d81071b57	\N	Uy	Avtotuning	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:28:26.366345+00	2026-04-01 18:28:26.366345+00
c00d6994-0f7b-49fa-b1e4-5ed2a691dd52	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	48ce15c7-decb-49f0-b5c1-bc9d3b131822	\N	Uy	Turon Avtozap	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:28:26.882524+00	2026-04-01 18:28:26.882524+00
4041cabe-b702-42e5-85e8-3f0d489e48ae	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	732995d0-c108-4b06-b381-e957010c8501	\N	Uy	Akfa	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:28:27.576617+00	2026-04-01 18:28:27.576617+00
29dcf018-eeef-4316-9b7b-a9fb41891275	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	20e6fde7-d94f-46ff-a6d0-edcc614b4e17	\N	Uy	Nanocarwash	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:28:28.0903+00	2026-04-01 18:28:28.0903+00
c34db247-f303-477b-a949-b23898b43c27	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	3f751ddb-c690-4791-a704-ce6fa9b028ed	\N	Uy	Magazincha ***	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:28:28.861319+00	2026-04-01 18:28:28.861319+00
51f6aeb2-d772-4d74-83a3-fac3a19ae2b4	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	6ee3d6f7-8e9d-48c0-a37f-b218f3790396	\N	Uy	Maktab	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:28:29.401823+00	2026-04-01 18:28:29.401823+00
eeb5aebb-2e02-4f61-a31d-7ebc9970c4c5	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	624ee260-9cbe-457d-a6dd-aced3bffdf40	\N	Uy	Hamkor Qurilish	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:28:29.90685+00	2026-04-01 18:28:29.90685+00
6f6b6c17-6ec0-44e3-8bba-efc5380efb3b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	3949025b-76f0-4c06-b4ce-42f51d6f89aa	\N	Uy	Polik	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:28:30.464293+00	2026-04-01 18:28:30.464293+00
1e149262-6a62-494b-bbc1-372d9b82e074	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	5937e9b6-042e-40c6-86b7-9d4432364118	\N	Uy	Asko	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:28:30.959377+00	2026-04-01 18:28:30.959377+00
d0daf245-4082-49c5-8e2d-e3fc5b2fc53b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	107ba811-3dcf-45af-8b76-740b2e5f7976	\N	Uy	Baron Hostel	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:28:31.464369+00	2026-04-01 18:28:31.464369+00
d839a152-b870-4eac-8151-e60624999caa	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	300d200d-a8ef-46c2-a6a2-8851e52e54b8	\N	Uy	29 zona	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:28:31.917924+00	2026-04-01 18:28:31.917924+00
d8aa3164-3120-4d22-976f-885d13bf5a68	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	dbcac118-81e6-49e9-b5ff-ada87dbacfd5	\N	Uy	Perfectume notarius	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:28:32.451427+00	2026-04-01 18:28:32.451427+00
7f4bd4fd-df8d-4f12-9432-d162b0b2f947	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	4226a37b-5abc-4e2e-8d73-59d15e44d4be	\N	Uy	9 tikuvxona	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:28:33.063218+00	2026-04-01 18:28:33.063218+00
e6849afe-5a51-41ac-b19c-a7482b1388f6	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	537ab793-6cd9-4c30-8204-f8f1e48f1382	\N	Uy	11 Bogcha	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:28:33.54025+00	2026-04-01 18:28:33.54025+00
ddec6fae-2383-4caa-8be7-b6857447bfd8	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	63ca8318-1a56-40f4-a54b-009747795ff8	\N	Uy	GostStandard	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:28:34.237978+00	2026-04-01 18:28:34.237978+00
b87801dc-39a5-47ea-a888-4c5e7f7aaeb2	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	ce010c20-a9b7-430b-bd31-ce2b712cf4a7	\N	Uy	Sentr bug 2	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:28:34.902166+00	2026-04-01 18:28:34.902166+00
94d75e6d-111c-40e2-8dd9-a7329978f239	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	8d43be71-dfd5-414d-b8ec-daee2ca12991	\N	Uy	Sentr bank	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:28:35.392999+00	2026-04-01 18:28:35.392999+00
9e4d1c31-9b97-45e2-9def-61da7328fa6c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	79228f67-ab3d-4f0e-a26a-54537a85b028	\N	Uy	Sentr devonxona	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:28:35.857201+00	2026-04-01 18:28:35.857201+00
67a29b4e-c116-42cf-bed1-ffd6b581b334	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	f794d673-f4f5-493d-92b0-3ef6ce270ca6	\N	Uy	Tarobiy Shirkat	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:28:36.538968+00	2026-04-01 18:28:36.538968+00
851cd677-4e3f-4e5c-890e-9e4b3b8ed3ca	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	7c2c4a17-b8c1-4d95-9fa7-f37ca207711a	\N	Uy	Navoiyfuqarloyiha	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:28:37.243075+00	2026-04-01 18:28:37.243075+00
7245b08d-b4bc-469a-9c5e-96e9b91aed6a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	efd6da47-e380-4f2d-affc-5325ce9e6c85	\N	Uy	4-polik	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:28:38.138957+00	2026-04-01 18:28:38.138957+00
3ceb85b9-08cb-4523-a94d-6be4e2fb0fe4	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	4f47b697-d8d6-4ac0-9388-f5e627a596a5	\N	Uy	Bozor 58	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:28:38.615467+00	2026-04-01 18:28:38.615467+00
7c168e11-6cfd-41e1-af1f-3df7a2d40199	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	10d94320-df8e-47e4-b5e3-d0d84463ec57	\N	Uy	Bozor 76	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:28:39.091845+00	2026-04-01 18:28:39.091845+00
83e267d8-9612-4f25-9867-700275ca2ffb	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	16258b36-b30b-41d8-91db-445ba4748e07	\N	Uy	Bozor 2/89	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:28:39.66901+00	2026-04-01 18:28:39.66901+00
8cd4cd8b-13e7-4fdf-91a8-27e35765fdd0	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	7ab93631-1167-460f-a3a6-e2724caf63f5	\N	Uy	Bozor 89	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:28:40.173034+00	2026-04-01 18:28:40.173034+00
66f3f510-949b-4e13-81f0-e5d83db8e6e1	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	af44cf36-cc80-4ede-8dee-101a616c847e	\N	Uy	Bozor 122 tillo	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:28:40.686015+00	2026-04-01 18:28:40.686015+00
45044925-e2ce-45c6-a192-60e2e075afd6	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	79a3f7c0-148f-44b5-b0b1-dbf043c2b5f2	\N	Uy	Bozor 56*	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:28:41.198384+00	2026-04-01 18:28:41.198384+00
4fdfc4cb-1dd7-4457-bed9-d1c811ce5c28	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	577fbf8b-efd0-4c67-abff-37f1d187e8c2	\N	Uy	Bozor 195	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:28:41.687353+00	2026-04-01 18:28:41.687353+00
5b02439e-9435-4c94-870c-77a5b07952c5	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	aafe6824-a41a-48a0-a146-22688d0b4531	\N	Uy	Bozor material/289/288	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:28:42.186226+00	2026-04-01 18:28:42.186226+00
e28a11a4-4442-4187-b063-5ec0b9060700	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	d7f561d1-3d78-43d9-8ad6-cf7a1d032489	\N	Uy	4 etaj 69	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:28:42.67227+00	2026-04-01 18:28:42.67227+00
6b06f4d8-fa6d-4602-9e91-6f4024824bbf	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	865a489e-dde3-4c8d-8f68-bf6edba03504	\N	Uy	4 etaj 87	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:28:43.206416+00	2026-04-01 18:28:43.206416+00
fe8ad126-5b0e-463f-bfb6-416678eeed51	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	b8c93a21-f760-41e5-bb8e-6a0784e2a9b3	\N	Uy	Giper 88	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:28:43.70165+00	2026-04-01 18:28:43.70165+00
168b3527-c568-4f26-aa2a-833a833cc4cb	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	a7e89539-82f4-48be-8ae2-a70a8c184c7c	\N	Uy	Giper 89	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:28:44.162035+00	2026-04-01 18:28:44.162035+00
a60bb3a9-b98b-442b-b1d9-e94cdcc9ece4	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	6e810270-02e6-4351-ac47-b285637c404c	\N	Uy	Giper 92	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:28:44.772063+00	2026-04-01 18:28:44.772063+00
e319f3c3-b39d-4f88-b943-79a5a959c843	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	b19d7c14-2b15-4eb9-a302-e57f8f869eb3	\N	Uy	4 etaj 98	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:28:45.381421+00	2026-04-01 18:28:45.381421+00
9b38ab1d-d0be-40f7-bfb4-73bbca2ed6d7	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	78424c22-2668-4234-82bd-baa9364ac513	\N	Uy	New Brand Markaz	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:28:46.048547+00	2026-04-01 18:28:46.048547+00
1ca30496-52b3-4a46-b4b8-e3dd369b6f5a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	9d9f2539-ceb1-4a75-9725-b2440300cf4a	\N	Uy	Marvarid salon	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:28:46.708279+00	2026-04-01 18:28:46.708279+00
75441176-56ac-463e-8c12-430277f7fef2	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	bbe1b2d2-5849-4b28-b8d1-4dcebc9dce6d	\N	Uy	Crystal salon	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:28:47.254423+00	2026-04-01 18:28:47.254423+00
b394e604-7272-4c2e-a649-88b4ecd59dd8	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	24776c81-d7b7-4829-a9ea-c9efa6e4a1e6	\N	Uy	Deya	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:28:47.75378+00	2026-04-01 18:28:47.75378+00
9671f38d-ecc9-46b4-9fce-4ec230741353	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	6938eef9-b4d5-4763-8c6d-dc0b6a71d59d	\N	Uy	Deya office	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:28:48.305079+00	2026-04-01 18:28:48.305079+00
9aac6465-96ea-4255-b7bd-adc49eb31ffc	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	0b5c573d-9f25-41e7-be5f-f925de3368b7	\N	Uy	Imzo	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:28:48.936316+00	2026-04-01 18:28:48.936316+00
2c653c17-4279-435f-b991-66188807cbc0	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	59f57da7-7739-4703-bb8a-43c36795cd5b	\N	Uy	Bonum	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:28:49.483322+00	2026-04-01 18:28:49.483322+00
c4e13457-1a28-4219-bca9-42e316367bd4	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	94070549-c817-4d9b-b20c-e84005f0ffd4	\N	Uy	Hokimiyat	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:28:50.006153+00	2026-04-01 18:28:50.006153+00
e5d15514-93c0-4c5f-a4c4-1ca7d00b08f3	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	894b028b-a528-4755-9d17-07360f1f5150	\N	Uy	Stefano Shoes	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:28:50.561388+00	2026-04-01 18:28:50.561388+00
2126275f-275c-4755-94b1-5feec27a478a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	3d27a502-4265-4959-8285-41eea675c569	\N	Uy	Sayqal cafe	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:28:51.023464+00	2026-04-01 18:28:51.023464+00
7979cbd3-b8b4-4446-97a4-9340826bce2f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	3ee5948e-e29a-4f93-bf67-834a6dfcdcee	\N	Uy	Avtocesmetika	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:28:51.661754+00	2026-04-01 18:28:51.661754+00
89f7db75-f7f2-456d-a546-a2edba9bb08c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	f9d02251-98b6-423d-a65d-561e498f82e1	\N	Uy	Aver	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:28:52.132617+00	2026-04-01 18:28:52.132617+00
2e1bb6b1-6c63-46ba-85b4-534a46c19477	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	912c5eb2-d94e-4227-a857-f9eaeea1c2f2	\N	Uy	MS/79	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:28:52.925906+00	2026-04-01 18:28:52.925906+00
9d2291b8-908a-498a-98b2-73c3164da986	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	addd5e2d-e902-44d7-b068-ade7b2ff2d80	\N	Uy	NKMK 2	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:28:53.769347+00	2026-04-01 18:28:53.769347+00
ef1caca3-8ef9-4312-a104-86413c759827	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	6fb2b287-cb89-4cd8-9385-c4d35483d2f9	\N	Uy	NKMK Jamg'arma	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:28:54.254399+00	2026-04-01 18:28:54.254399+00
05c7a94e-1f38-4281-9cca-7b25280c37b5	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	a364fb60-7060-4332-9b2d-cd2a9ca9b2db	\N	Uy	3 Avtobaza	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:28:55.034533+00	2026-04-01 18:28:55.034533+00
bbf108a7-d979-4684-bc7f-549d71e6ba75	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	097b99cc-71f1-45f7-b42f-b975d62ba9e1	\N	Uy	GMZ XVOST	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:28:55.584692+00	2026-04-01 18:28:55.584692+00
f6f8a575-2786-486f-95db-5e1347ac5655	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	298ff33f-bf0f-4828-acfa-7001245fe7c9	\N	Uy	GMZ	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:28:56.097934+00	2026-04-01 18:28:56.097934+00
dcd54ed9-f443-478c-b0f1-4ae830001e37	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	3142f475-c045-44d6-8ada-355fa67fec64	\N	Uy	Uran 1	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:28:56.77951+00	2026-04-01 18:28:56.77951+00
915c1f99-2edd-472d-ac87-3a7eefc646b5	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	02b80790-13fb-458f-bf92-dc1b13912ef0	\N	Uy	Uran deklaratsiya	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:28:57.549801+00	2026-04-01 18:28:57.549801+00
ce757e41-5628-4eee-89c9-bb7a5d273539	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	bdfaaff2-c768-46c0-a6b3-f6d9ded17aec	\N	Uy	Uran Premniy	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:28:58.066416+00	2026-04-01 18:28:58.066416+00
d460f180-7dd1-4adb-ae6f-6eeceea6e934	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	e275d9d0-858f-4da6-8bfe-67505b191c34	\N	Uy	Uran otdelkadr ayol	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:28:58.808576+00	2026-04-01 18:28:58.808576+00
8fac51fa-cb94-4395-ba8c-1ebd7a72a865	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	118cee2a-e0e2-4a3b-ac23-e7c633ee663a	\N	Uy	Uran TRANSPORTNIY	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:28:59.366184+00	2026-04-01 18:28:59.366184+00
3109d3d1-074e-4e3b-bad6-d9dff2340854	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	682ed1bf-dcd5-47cd-99a3-4277b4e92d23	\N	Uy	Uran snabjeniya	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:28:59.906055+00	2026-04-01 18:28:59.906055+00
d186e2f7-4175-472f-af32-720b80c055c2	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	ab08da15-4dcf-4c08-bbf9-198e56336c8c	\N	Uy	Uran OIT	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:29:00.650191+00	2026-04-01 18:29:00.650191+00
35f868ed-eff1-4bbb-ae27-43f041c56d05	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	f8d61dc9-1657-42bd-b201-3a3b8c30da67	\N	Uy	Uran Buxgalter Abzal aka	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:29:01.152748+00	2026-04-01 18:29:01.152748+00
33438a53-8193-4858-bfaf-a8ac0ae726e7	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	ebfbc932-e9e4-47d1-88dd-1451c6bce3d9	\N	Uy	Uran Upravleniya	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:29:01.713218+00	2026-04-01 18:29:01.713218+00
d2c88ea0-6d79-4e20-99bc-bec51d33b9cb	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	e52d4d56-1c5c-41c6-ae7a-32ffac53e242	\N	Uy	Uran Kassa	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:29:02.338457+00	2026-04-01 18:29:02.338457+00
129abe20-547b-48c2-8bb3-675fa99a46a2	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	ec9b1c37-1d71-4d4b-a4d3-0b6d3f4af361	\N	Uy	NMZ	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:29:02.870396+00	2026-04-01 18:29:02.870396+00
8fcdab5e-e2d5-4d5f-a827-8be189bd2236	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	f742553a-cb89-4bdf-98b9-9cad8505a793	\N	Uy	NMZ Ins. Sex 1	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:29:03.404114+00	2026-04-01 18:29:03.404114+00
2d569331-b6aa-431d-a3b7-af90f96c3a8c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	b1b8ffba-7252-4829-b7f6-3e7a427166dd	\N	Uy	SMTB KANSELYAR	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:29:03.924753+00	2026-04-01 18:29:03.924753+00
5d9bec3a-235d-4f6a-9e14-be8dc8f14f2b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	6f4e81f1-76ca-4514-b260-4a1ad1f886f9	\N	Uy	SMTB DEKLARATSIYA	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:29:04.429301+00	2026-04-01 18:29:04.429301+00
59ef2e05-1390-4c02-bce7-ec0cdbe6b517	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	8085d575-8c94-431c-8651-7ee64010bd7f	\N	Uy	SMTB YURIST	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:29:04.916977+00	2026-04-01 18:29:04.916977+00
9a758acb-a1c7-47b7-bf11-e023c10a0348	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	0fc6a904-5c6e-4f70-afed-ead95b21a10f	\N	Uy	SMTB NACHALNIK	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:29:05.511405+00	2026-04-01 18:29:05.511405+00
962cb050-62de-4972-9385-b3a4ad7a0dcb	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	03e45cea-329b-4c01-bbb4-19b8bd9bd765	\N	Uy	SMTB	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:29:06.029469+00	2026-04-01 18:29:06.029469+00
e7c41b48-32e7-4b75-b2ad-263f2a9a9cf3	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	5df682e0-30fd-483a-836e-4d94e65c4063	\N	Uy	SMTB	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:29:06.542344+00	2026-04-01 18:29:06.542344+00
6c2aa2d6-3ff1-47d2-b2e1-c5ec26a3e07d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	ed5da426-58a8-4790-86f5-79b4fe1eae2e	\N	Uy	SMTB Zapravka	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:29:07.005667+00	2026-04-01 18:29:07.005667+00
a3637b10-274b-4aa0-8720-04f2059a8a5e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	99c5b9ad-d214-49f8-ba12-0e52a45c991e	\N	Uy	SMTB 5	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:29:07.62313+00	2026-04-01 18:29:07.62313+00
8466f6d2-66ed-421c-b360-ff9c8d7a4cf5	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	a96042c9-2e84-45dc-8e65-a0502ffa5b54	\N	Uy	SMTB 10 SKLAD	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:29:08.158537+00	2026-04-01 18:29:08.158537+00
71c91c0a-a9ce-4753-8e97-040088d1a7a3	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	d12524f3-35cc-4e32-8617-9a903f91d5f9	\N	Uy	SMTB BUXGALTER	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:29:08.667597+00	2026-04-01 18:29:08.667597+00
51cd8b1b-60d4-4a81-9a96-b8f6b3743f8f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	5483647d-7122-49d6-a47e-f41fbac9ba1a	\N	Uy	QizilqumSement	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:29:09.22326+00	2026-04-01 18:29:09.22326+00
5f0de322-afc2-4b82-be79-c792b1f00109	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	48916350-a093-4d2c-abe3-4e72c9282f41	\N	Uy	29 Boĝcha	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:29:09.931446+00	2026-04-01 18:29:09.931446+00
a0f0a316-711c-4ec2-a089-f01fd6c9f16d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	2da977ff-59df-4b14-ab15-19e612eafd10	\N	Uy	30 Boģcha	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:29:10.535766+00	2026-04-01 18:29:10.535766+00
4e6028ff-e0a6-4c45-87ad-31abf8552088	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	e1cbc010-1344-4fd6-8ca0-92a00d1b6268	\N	Uy	1 Maktab	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:29:11.041463+00	2026-04-01 18:29:11.041463+00
c46c2fb9-bc0f-41ae-87ef-1156c2e7459d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	86f60744-4b1c-4d74-a968-86301cf91289	\N	Uy	4 Maktab **	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:29:11.527345+00	2026-04-01 18:29:11.527345+00
18cc02da-2bc9-4139-8f1b-93b066563431	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	00248921-2386-4962-8cfc-3cd8cc62b708	\N	Uy	Fargo Pochta	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:29:12.012417+00	2026-04-01 18:29:12.012417+00
ca351597-d597-47d9-a7cc-1ba786bc347c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	15397afa-b698-4705-8c4c-f9313d700e81	\N	Uy	Prokuratura	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:29:12.596349+00	2026-04-01 18:29:12.596349+00
12789296-3a7e-4c5d-9fc6-21fbbf125764	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	e9842006-c51a-4683-a5f5-1eb76a518232	\N	Uy	Dent Med	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:29:13.114142+00	2026-04-01 18:29:13.114142+00
5aff6922-12a4-4f14-850c-208aab9f0589	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	4f9e9bd8-06cf-401f-8376-c26a0f64f679	\N	Uy	Sushi house	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:29:13.808543+00	2026-04-01 18:29:13.808543+00
0c0b27e1-ccb1-427a-a91e-bf0f79276bec	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	12a6fe1e-2334-41a9-9213-b95c92b1da3a	\N	Uy	Yasin kafe	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:29:14.4274+00	2026-04-01 18:29:14.4274+00
335aa0ca-c008-491b-9b6a-89d1f866f5ac	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	f62d3202-c7db-4d89-937e-1aef4d638ec5	\N	Uy	Parfume	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:29:14.930143+00	2026-04-01 18:29:14.930143+00
70694761-c0f2-485e-8575-557e229f3ec9	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	197eb282-bef7-4b24-99c3-b3cfa68fba53	\N	Uy	Ped oshxona	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:29:15.635724+00	2026-04-01 18:29:15.635724+00
6d6303d6-5130-48f1-9f86-df4e5dde3ea6	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	0432e02a-6a4d-4e99-9b3f-2efe59c59666	\N	Uy	Advokatura	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:29:16.15397+00	2026-04-01 18:29:16.15397+00
df5bc822-b2bc-40ee-a733-2b5397d4d3b4	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	9364705e-67da-414b-99c6-e224217313fb	\N	Uy	Samira med detskiy	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:29:17.052407+00	2026-04-01 18:29:17.052407+00
518c8eb1-12c9-46f4-b740-68e7659e6eb3	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	f8bf4a6b-c791-4254-89a7-5c3cb6e8cff7	\N	Uy	Ko'p Tarmoqli	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:29:17.800612+00	2026-04-01 18:29:17.800612+00
e924aff8-1f35-46b1-929a-ef601a197cdc	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	01ac363a-efdd-4c79-8768-9228989a37c2	\N	Uy	Lazer Med	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:29:18.345206+00	2026-04-01 18:29:18.345206+00
1ac022e4-29ee-4657-9ec4-7fdd27d3288f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	855f582d-1840-41e5-b12b-6db0eda7936a	\N	Uy	obl skori	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:29:18.883627+00	2026-04-01 18:29:18.883627+00
a1cb5fca-f43b-45b8-9d8e-1d083a772a0b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	e6b2e204-9b44-4bf7-95fb-9dc8eac5f0dd	\N	Uy	Skori avtobaza 27.05ga	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:29:19.488357+00	2026-04-01 18:29:19.488357+00
fae7506e-e18e-4fb9-b766-b9c39533752c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	2cfa7854-02dd-455e-a868-dedbf440461c	\N	Uy	14-Bog'cha	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:29:19.958475+00	2026-04-01 18:29:19.958475+00
d5015ff4-a0eb-483f-a1b4-9bc23a6c7f00	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	7ce918d0-4f8e-405d-bfc9-ab05671e5c9b	\N	Uy	Parnik 2	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:29:20.520962+00	2026-04-01 18:29:20.520962+00
5de635c8-bccb-444c-8e39-2fcd959b7b4d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	8528cffb-bb42-4803-aaf4-d8b993b56058	\N	Uy	parnik*** Amaki	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:29:21.106007+00	2026-04-01 18:29:21.106007+00
fe1eaa47-6ba1-4ccd-b1a8-9eee62603342	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	1154ea96-e9c3-4893-8f1a-011ecb517316	\N	Uy	SAG XXL	\N	\N	\N	\N	\N	\N	\N	t	2026-04-01 18:29:21.873736+00	2026-04-01 18:29:21.873736+00
20438723-c2ed-4a34-9d49-73c9dda184d7	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	d53ae11d-54f4-47e6-91dd-e452288c5a79	\N	Asosiy	Lomonosov 1/24	\N	\N	\N	\N	\N	\N	\N	t	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00
e7f03235-7ed9-419a-9fbd-bc601796fa90	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	d3ca3308-46bc-4717-b89d-a93a72d33f0b	\N	Asosiy	M. Ulug'bek 15/19	\N	\N	\N	\N	\N	\N	\N	t	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00
15d80eb6-1d83-441e-950c-6e10a314a9de	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	9e3b23c2-e08a-4a81-9f95-955cb1e05f4d	\N	Asosiy	Tarobiy 77b/61	\N	\N	\N	\N	\N	\N	\N	t	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00
235af637-d78a-4d8f-b3fd-62482b6a2291	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	79401428-e8f6-4f9d-b996-d79486c5ee3e	\N	Asosiy	Karimov 47/71	\N	\N	\N	\N	\N	\N	\N	t	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00
abc27643-5478-48f7-b5b6-b8749d175d20	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	5debfc92-6925-47af-a205-e9a13815f7c7	\N	Asosiy	Karimov 92/33	\N	\N	\N	\N	\N	\N	\N	t	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00
e3029687-9bf8-4b8d-8c67-00c0e2a242da	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	8994ab0f-5d96-4dff-8441-b0921516cb43	\N	Asosiy	Karimov 94/48*	\N	\N	\N	\N	\N	\N	\N	t	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00
99aad3cb-ac5f-430b-8858-87883c69b27f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	2a23c223-436e-4c23-9c4c-9fedb014fde2	\N	Asosiy	Shodlik 5/6	\N	\N	\N	\N	\N	\N	\N	t	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00
696ef495-d287-4739-b873-34e4421763b5	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	cb2046fc-9a40-48c9-9a08-a35e07877c06	\N	Asosiy	Nurafshon 1/25	\N	\N	\N	\N	\N	\N	\N	t	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00
8e969257-5991-416b-a1e5-eef63ee88b30	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	dae66baf-d688-42ad-86c0-d7290b81dabd	\N	Asosiy	Spitamen 5/19	\N	\N	\N	\N	\N	\N	\N	t	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00
06801022-efb1-4bce-aa70-52f98218ee98	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	d3d8dc55-28e4-43de-96fa-e35a350df587	\N	Asosiy	Qurilish 5/13	\N	\N	\N	\N	\N	\N	\N	t	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00
07e56308-4e88-41a9-9fc4-b374204fb61c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	47af2c99-ee8a-4d34-a496-dc894b647b4d	\N	Asosiy	Pushkin 4a/34	\N	\N	\N	\N	\N	\N	\N	t	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00
7ed7c135-656b-4635-97d2-14907c801a81	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	5dd429b8-a125-4ee8-9e33-dbae92b8f1cc	\N	Asosiy	Ibn Sino 43/6	\N	\N	\N	\N	\N	\N	\N	t	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00
7e05c6f2-ec8a-4967-955d-76f8b801353b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	0cdfa3ac-12ee-4948-bc09-70940765ba2f	\N	Asosiy	Tolstoy 21/39	\N	\N	\N	\N	\N	\N	\N	t	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00
0a924df1-2228-4799-b588-3fbdbbfd0c32	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	4cfc5e61-f7e2-4196-bc1f-51b2ab3e2f6c	\N	Asosiy	A.Avloniy 20/29	\N	\N	\N	\N	\N	\N	\N	t	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00
4ad34829-103e-4a89-ba93-bf1bfc72a1b4	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	51328a9a-de4b-4315-9e4f-48f45ab2270b	\N	Asosiy	Galaba 141/3/26	\N	\N	\N	\N	\N	\N	\N	t	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00
ef08a035-2fe2-4610-9fd1-7c67da37324c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	54efd433-c25d-4584-bf35-1ec490569cf0	\N	Asosiy	Galaba 145/23	\N	\N	\N	\N	\N	\N	\N	t	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00
ae439d76-11e9-43f6-b1f8-09458cb7987d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	d3c7ba95-c333-4ecc-b279-d79a5f935e54	\N	Asosiy	Galaba 210/5	\N	\N	\N	\N	\N	\N	\N	t	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00
86b26272-b370-4034-9923-782e98eafb88	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	7be076ee-6acc-4abd-b4e1-7427050d57fc	\N	Asosiy	Polik  kasaba/1, bux/4, kadr/3, nazorat/1, zamdirek/2, kotibala/1, boshhamshir/1	\N	\N	\N	\N	\N	\N	\N	t	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00
84127c1b-ee8e-454b-bfb4-74f80f733708	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	5bc95780-94a3-4c47-a6b2-44afbe19d6c4	\N	Asosiy	A. Buxoriy 181	\N	\N	\N	\N	\N	\N	\N	t	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00
47460089-4ed9-4574-aaa3-360e8c480c6a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	847c501c-dc35-486d-94e3-a6cefa9609ba	\N	Asosiy	Birdamlik 33***	\N	\N	\N	\N	\N	\N	\N	t	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00
10150e78-57ed-4456-8987-36381dd5bd75	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	a72b1635-e87d-43f7-b428-99c5bbefa5b6	\N	Asosiy	E.Sh. Qiyot 232a	\N	\N	\N	\N	\N	\N	\N	t	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00
e0dc664d-d438-4641-9910-712d60e14681	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	569e8c32-64ab-4a06-a789-164d2d9ce1e8	\N	Asosiy	E.Sh. Bahor 32	\N	\N	\N	\N	\N	\N	\N	t	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00
4ce887f1-76a1-43bf-ab0a-09cb9bee3ff8	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	511a8517-be3f-4275-bd09-705e240c5c5d	\N	Asosiy	E.Sh. Uzbekiston 146	\N	\N	\N	\N	\N	\N	\N	t	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00
d35c046a-debc-4bb7-80c7-4d5805d5837c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	e77eec57-552a-4f47-bc70-fbed930d0d14	\N	Asosiy	E.Sh. Mulkobod jalyuzi	\N	\N	\N	\N	\N	\N	\N	t	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00
961439ad-4bdb-4d8f-b337-7aa556e80cd4	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	fdcc48c2-8a89-4e10-b54f-8ead9ce0c19b	\N	Asosiy	E.Sh. Ilĝor 45a/1	\N	\N	\N	\N	\N	\N	\N	t	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00
14a11eb2-0527-430a-bad0-2c4e99abce1f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	a56ef2d0-5a64-48cf-a12b-3502beedb2ba	\N	Asosiy	E. Sh. 5etajka 48	\N	\N	\N	\N	\N	\N	\N	t	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00
1bb46ecf-ffb1-4b76-afe1-aae884b27a4c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	5d282598-7559-4473-84c1-68e0caf8b3bf	\N	Asosiy	E.Sh. Jasorat 31****	\N	\N	\N	\N	\N	\N	\N	t	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00
88f3a87c-26a7-49f0-bd54-3ff52049aa65	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	51e4d056-4f1c-4998-9454-54dbc84c9a0c	\N	Asosiy	Registan***	\N	\N	\N	\N	\N	\N	\N	t	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00
3e6df725-e281-4064-9c17-f7477ce91d5c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	0fbda622-4bfc-4cb2-8cb3-8428bcee700c	\N	Asosiy	AvtoPochta	\N	\N	\N	\N	\N	\N	\N	t	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00
650c4c55-8f7d-4474-aa6c-26b505bc524d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	629d7031-bfaf-468a-94d1-2ab642f57f97	\N	Asosiy	Jalyuzi shox	\N	\N	\N	\N	\N	\N	\N	t	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00
9986eb14-9b39-4bca-a73f-899465479521	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	01b9e48f-f184-4a28-a3fa-5d6e4295b826	\N	Asosiy	Markaziy Bank 1etaj	\N	\N	\N	\N	\N	\N	\N	t	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00
08c49136-e757-478f-a8ea-eb1b3c2aff7d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	d5b53653-3585-4625-8ed9-2a982772b4f0	\N	Asosiy	Qobil Stroy atelye	\N	\N	\N	\N	\N	\N	\N	t	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00
651fdc21-77c9-4735-bdf8-f4e60e99dab7	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	142f6c89-bc8f-4537-a5e0-e17651bf88c2	\N	Asosiy	LaStoria	\N	\N	\N	\N	\N	\N	\N	t	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00
4ca3daf8-5c5b-41f8-a6f0-e3a4f5f5fde7	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	56da6e83-1ef2-4766-b830-dca268414193	\N	Asosiy	Texno zap	\N	\N	\N	\N	\N	\N	\N	t	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00
4b22034e-a1e6-4728-b474-5ccfa0bf306e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	1595a032-a6ea-40b5-ab7c-9c865735520a	\N	Asosiy	AISHA salon	\N	\N	\N	\N	\N	\N	\N	t	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00
7dc43352-44f0-485d-9a9c-7fc1ca4fb292	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	fb8ff5bd-eded-4838-a9e0-87d4e290bcff	\N	Asosiy	Giper 126	\N	\N	\N	\N	\N	\N	\N	t	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00
bc0230b4-ff09-4273-824a-b89210df23d1	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	850b3c47-b669-4a3e-b059-8b68b37eb4d9	\N	Asosiy	Yuridik texnikum	\N	\N	\N	\N	\N	\N	\N	t	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00
dac7b11d-f38f-4607-9785-d7d4bb6addab	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	4a7160de-7462-4862-b70c-7d7fb27e9d7b	\N	Asosiy	Tinchlik tuyxona	\N	\N	\N	\N	\N	\N	\N	t	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00
260b9fea-f8bd-468a-8c8d-b3999aea22df	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	a93608df-3b83-47b7-99d5-c2a021ccea69	\N	Asosiy	Sputnik polik gnikolog	\N	\N	\N	\N	\N	\N	\N	t	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00
1a65cf25-4cec-4352-aaab-f1f5eb5cbb8d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	1d71d1fa-74b9-48de-a027-a3d49e725196	\N	Asosiy	Ijtimoiy Obyektlar Boshqarmasi	\N	\N	\N	\N	\N	\N	\N	t	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00
9cf0f819-edce-4e32-b9b5-f28852b8ed38	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	35cb1e9b-d2b2-44f4-87d2-1e839c44de9a	\N	Asosiy	Gorni kollej	\N	\N	\N	\N	\N	\N	\N	t	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00
b46cae00-37f0-46ce-8c46-250dbf98f072	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	06be5f3a-b257-485e-863d-2fc500a1fd32	\N	Asosiy	NKMK Qurilish *	\N	\N	\N	\N	\N	\N	\N	t	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00
9d0fea2c-da47-4d99-8c18-c02116eb9fda	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	4c259ce9-f7e3-4352-b915-2b2fb5e1f45c	\N	Asosiy	Uran zam kadr	\N	\N	\N	\N	\N	\N	\N	t	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00
bcc4d1c7-11a4-4dd7-b101-5209dd2c335c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	7b2e5b8f-7310-4d8a-b72d-fac45c28e99e	\N	Asosiy	Uran 1/2	\N	\N	\N	\N	\N	\N	\N	t	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00
d9bf1a7e-a9ff-4eb9-90cb-91d579e5d943	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	9469e28d-9ce0-4b7d-8fb5-9bbb51ba13df	\N	Asosiy	Uran Loyiha	\N	\N	\N	\N	\N	\N	\N	t	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00
9f990470-f24d-4395-b008-021375a469c0	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	46c795d9-92d3-4173-a94c-a6914546a063	\N	Asosiy	Uran  UVP	\N	\N	\N	\N	\N	\N	\N	t	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00
b89f5104-091e-477e-8780-f22e3b7a27b4	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	679dca2a-9719-44e5-b4e2-4bfb3a8997f7	\N	Asosiy	2 Polik	\N	\N	\N	\N	\N	\N	\N	t	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00
e4788eb8-33af-4880-8cd9-b9d902358085	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	04d7cc78-2b9a-49f3-b16f-429fc9b5a1d4	\N	Asosiy	OblZdrav	\N	\N	\N	\N	\N	\N	\N	t	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00
72d9f794-ddd7-499e-bc82-8f25e2101c89	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	ad307912-0235-47a7-8d84-3a223bc88b74	\N	Asosiy	Sanatshunos	\N	\N	\N	\N	\N	\N	\N	t	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00
fdfc7a3b-ec3b-40c9-aeca-2ae023f08d51	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	4bfc91d0-eca1-439b-a477-045ec2b56598	\N	Asosiy	Uztelecom	\N	\N	\N	\N	\N	\N	\N	t	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00
cc82b046-89fe-480e-9b02-b2b09cf5b3f8	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	f669c473-ee41-4ec5-ae13-54d1f8ea8a86	\N	Asosiy	27 polik	\N	\N	\N	\N	\N	\N	\N	t	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00
a84981f8-122b-438d-b779-3dcc5cb503e1	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	c55ebcb5-4487-475d-b3f0-14a5f08233e9	\N	Asosiy	Soliha market	\N	\N	\N	\N	\N	\N	\N	t	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00
c0c83651-b5ca-4845-93df-269df58b6ab5	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	221df0f1-a261-473e-8bbe-8d539f600a47	\N	Uy	Tarobiy 117b/4	\N	\N	\N	\N	\N	\N	\N	t	2026-04-02 15:31:48.798468+00	2026-04-02 15:31:48.798468+00
2c27ebae-18d7-4fc6-8af2-36027b229061	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	217e8909-1d64-40b1-bc14-55378f36cb1c	\N	Uy	Nav 46/43	\N	\N	\N	\N	\N	\N	\N	t	2026-04-04 02:03:42.336144+00	2026-04-04 02:03:42.336144+00
96b4eecc-461b-4ec1-9fc9-3f58dbf87744	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	4ad54089-6bce-4516-bb99-e6b2ca3eef37	\N	Uy	44, Багбог улица, Chilonzor-13, Учтепинский район, Toshkent, 100000, Oʻzbekiston					41.2949127	69.1870955	\N	f	2026-04-08 19:06:15.82206+00	2026-04-08 19:06:15.82206+00
feca4960-75ca-42d4-a245-39deb2c95436	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	a3270aa4-5751-439e-b56b-062380420324	\N	Uy	40.12947, 65.37102	\N	\N	\N	\N	40.129466	65.371024	\N	t	2026-04-11 15:16:34.609078+00	2026-04-11 15:16:34.609078+00
\.


--
-- Data for Name: client_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.client_groups (id, tenant_id, name, sort_order, created_at, updated_at) FROM stdin;
a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	Himalay	0	2026-04-01 13:15:46.448477+00	2026-04-01 13:15:46.448477+00
adef3ba0-89e4-4e4e-8fa1-fd78791d9471	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	Ako	0	2026-04-01 13:20:17.703451+00	2026-04-01 15:55:53.858818+00
8b2f3db8-59bc-486a-b852-58e489fd6399	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	Himalay ishxona	1	2026-04-01 18:28:24.55106+00	2026-04-01 18:28:24.55106+00
\.


--
-- Data for Name: clients; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.clients (id, tenant_id, user_id, first_name, last_name, phone, is_active, is_verified, is_blocked, has_contract, container_balance, debt_amount, advance_amount, notes, created_at, updated_at, is_deleted, group_id) FROM stdin;
00032968-fb3f-4cb4-860d-e147b698cb9c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	889f4fbc-04bc-44a9-8b77-125ce7f8960f	Бехруз	Хайриллоев	+998937570731	t	t	f	f	0	0	0	\N	2026-04-01 08:46:12.544418+00	2026-04-01 08:46:12.544418+00	f	\N
431dd689-4275-45e1-b238-bee3f99b0086	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	Akobir	Qodirov	+998900157775	t	f	f	f	0	0	0	\N	2026-04-01 08:59:42.361608+00	2026-04-01 08:59:42.361608+00	f	\N
058ff8bd-7ae9-4463-aa74-66660d6ec1c0	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998770670987	t	f	f	f	4	0	0		2026-04-01 13:20:18.261127+00	2026-04-01 13:20:18.261127+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
740cee76-3027-4baf-8862-d7c37a7a87a8	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998919912310	t	f	f	f	2	0	0		2026-04-01 13:20:18.747015+00	2026-04-01 13:20:18.747015+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
b3975d51-4977-46df-b994-90410657122d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998792245093	t	f	f	f	3	0	0		2026-04-01 13:20:19.266385+00	2026-04-01 13:20:19.266385+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
50a21fd0-7058-47e5-b040-9c03b42d5de3	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998912508889	t	f	f	f	2	0	0		2026-04-01 13:20:19.789156+00	2026-04-01 13:20:19.789156+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
cd8897c1-0b4e-4457-954c-18c10d52a162	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913397777	t	f	f	f	2	0	0		2026-04-01 13:20:20.314156+00	2026-04-01 13:20:20.314156+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
e296833e-9b1c-49b7-b856-5f898785b5fb	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998907393114	t	f	f	f	4	0	0		2026-04-01 13:20:20.760516+00	2026-04-01 13:20:20.760516+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
597f5c6e-3032-4331-a73d-b4962e295636	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998936615606	t	f	f	f	2	0	0		2026-04-01 13:20:21.795266+00	2026-04-01 13:20:21.795266+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
bd5c2811-28e4-46e6-b8af-981b1d7ce9f6	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998905000825	t	f	f	f	2	0	0		2026-04-01 13:15:48.056168+00	2026-04-01 13:15:48.056168+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
89240faf-747c-4ddd-b2b2-f9fb47e3cc0d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998993794799	t	f	f	f	2	0	0		2026-04-01 13:22:46.718173+00	2026-04-01 13:22:46.718173+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
369a4795-3364-4046-ba66-a2bfae4173fe	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998997504400	t	f	f	f	5	0	0		2026-04-01 13:25:25.576192+00	2026-04-01 13:25:25.576192+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
ed45443b-b464-4336-99fd-120b1f484237	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	2	0	0		2026-04-01 17:43:55.532696+00	2026-04-01 17:43:55.532696+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
96259350-df59-478f-9cbb-331bb9212cd3	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	2	0	0		2026-04-01 17:44:21.646393+00	2026-04-01 17:44:21.646393+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
4d96d518-52c2-41bf-b3e8-a133703c6f13	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	2	0	0		2026-04-01 17:44:47.535116+00	2026-04-01 17:44:47.535116+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
d8eb1bb0-739d-4048-a39f-f3e6f5647505	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	2	0	0		2026-04-01 17:45:17.909305+00	2026-04-01 17:45:17.909305+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
e83ab3f4-3d40-4cc7-a25e-45f107334e42	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	5	0	0		2026-04-01 17:45:46.923941+00	2026-04-01 17:45:46.923941+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
4fbd8e1a-c0af-4576-b0ab-4fba15bb2ee7	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	3	0	0		2026-04-01 17:46:01.499523+00	2026-04-01 17:46:01.499523+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
8a25ee5d-ee6f-45e2-ad88-9bd476410e6d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	9c586c10-f2ab-4708-8b71-5a6fc8367a39	Test	\N	+998901111111	f	t	f	f	0	0	0	\N	2026-04-01 08:37:57.081437+00	2026-04-01 17:48:23.395073+00	t	\N
03c4b6b2-a592-447f-8258-fb56cdce6701	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	6	0	0		2026-04-01 18:28:25.141618+00	2026-04-01 18:28:25.141618+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
4226a37b-5abc-4e2e-8d73-59d15e44d4be	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	1	0	0		2026-04-01 18:28:32.89429+00	2026-04-01 18:28:32.89429+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
79a3f7c0-148f-44b5-b0b1-dbf043c2b5f2	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998993378883	t	f	f	f	1	0	0		2026-04-01 18:28:41.012751+00	2026-04-01 18:28:41.012751+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
0b5c573d-9f25-41e7-be5f-f925de3368b7	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998886521111	t	f	f	f	2	0	0		2026-04-01 18:28:48.778531+00	2026-04-01 18:28:48.778531+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
02b80790-13fb-458f-bf92-dc1b13912ef0	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	1	0	0		2026-04-01 18:28:57.31636+00	2026-04-01 18:28:57.31636+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
0fc6a904-5c6e-4f70-afed-ead95b21a10f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	2	0	0		2026-04-01 18:29:05.33696+00	2026-04-01 18:29:05.33696+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
e9842006-c51a-4683-a5f5-1eb76a518232	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998932970802	t	f	f	f	3	0	0		2026-04-01 18:29:12.918606+00	2026-04-01 18:29:12.918606+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
1154ea96-e9c3-4893-8f1a-011ecb517316	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998906199806	t	f	f	f	2	0	0		2026-04-01 18:29:21.70096+00	2026-04-01 18:29:21.70096+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
a72b1635-e87d-43f7-b428-99c5bbefa5b6	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	E.Sh. Qiyot 232a	\N	+000000021	t	f	f	f	3	0	0	Dubli import (qator 630)	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
569e8c32-64ab-4a06-a789-164d2d9ce1e8	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	E.Sh. Bahor 32	\N	+000000022	t	f	f	f	2	0	0	Dubli import (qator 632)	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
511a8517-be3f-4275-bd09-705e240c5c5d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	E.Sh. Uzbekiston 146	\N	+000000023	t	f	f	f	2	0	0	Dubli import (qator 642)	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
e77eec57-552a-4f47-bc70-fbed930d0d14	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	E.Sh. Mulkobod jalyuzi	\N	+000000024	t	f	f	f	4	0	0	Dubli import (qator 650)	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
fdcc48c2-8a89-4e10-b54f-8ead9ce0c19b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	E.Sh. Ilĝor 45a/1	\N	+000000025	t	f	f	f	2	0	0	Dubli import (qator 671)	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
a56ef2d0-5a64-48cf-a12b-3502beedb2ba	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	E. Sh. 5etajka 48	\N	+000000026	t	f	f	f	2	0	0	Dubli import (qator 673)	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
5d282598-7559-4473-84c1-68e0caf8b3bf	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	E.Sh. Jasorat 31****	\N	+000000027	t	f	f	f	5	0	0	Dubli import (qator 693)	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
51e4d056-4f1c-4998-9454-54dbc84c9a0c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	Registan***	\N	+000000028	t	f	f	f	3	0	0	Dubli import (qator 8)	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
0fbda622-4bfc-4cb2-8cb3-8428bcee700c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	AvtoPochta	\N	+000000029	t	f	f	f	2	0	0	Dubli import (qator 9)	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
629d7031-bfaf-468a-94d1-2ab642f57f97	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	Jalyuzi shox	\N	+000000030	t	f	f	f	1	0	0	Dubli import (qator 21)	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
01b9e48f-f184-4a28-a3fa-5d6e4295b826	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	Markaziy Bank 1etaj	\N	+000000031	t	f	f	f	7	0	0	Dubli import (qator 27)	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
d5b53653-3585-4625-8ed9-2a982772b4f0	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	Qobil Stroy atelye	\N	+000000032	t	f	f	f	3	0	0	Dubli import (qator 31)	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
142f6c89-bc8f-4537-a5e0-e17651bf88c2	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	LaStoria	\N	+000000033	t	f	f	f	3	0	0	Dubli import (qator 33)	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
56da6e83-1ef2-4766-b830-dca268414193	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	Texno zap	\N	+000000034	t	f	f	f	2	0	0	Dubli import (qator 35)	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
1595a032-a6ea-40b5-ab7c-9c865735520a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	AISHA salon	\N	+000000035	t	f	f	f	2	0	0	Dubli import (qator 36)	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
fb8ff5bd-eded-4838-a9e0-87d4e290bcff	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	Giper 126	\N	+000000036	t	f	f	f	1	0	0	Dubli import (qator 55)	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
3e0ebe40-7733-4146-af41-a12d82ffebc9	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998950901690	t	f	f	f	0	0	0		2026-04-01 13:15:47.463227+00	2026-04-01 13:15:47.463227+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
850b3c47-b669-4a3e-b059-8b68b37eb4d9	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	Yuridik texnikum	\N	+000000037	t	f	f	f	17	0	0	Dubli import (qator 58)	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
a3f487a9-2bb5-4411-84a7-250ecc2531df	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998934353502	t	f	f	f	0	0	0	Второй номер: +998997555456	2026-04-01 13:15:48.667856+00	2026-04-01 13:15:48.667856+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
b33415e2-8f36-4674-9048-9747f3697356	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998907312924	t	f	f	f	0	0	0	Второй номер: +998779500091	2026-04-01 13:15:49.255674+00	2026-04-01 13:15:49.255674+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
4a7160de-7462-4862-b70c-7d7fb27e9d7b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	Tinchlik tuyxona	\N	+000000038	t	f	f	f	4	0	0	Dubli import (qator 63)	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
a93608df-3b83-47b7-99d5-c2a021ccea69	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	Sputnik polik gnikolog	\N	+000000039	t	f	f	f	1	0	0	Dubli import (qator 72)	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
1d71d1fa-74b9-48de-a027-a3d49e725196	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	Ijtimoiy Obyektlar Boshqarmasi	\N	+000000040	t	f	f	f	4	0	0	Dubli import (qator 73)	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
8986ef33-0d26-46c6-8f5f-9c8e6b2217e2	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998975211503	t	f	f	f	3	0	0		2026-04-01 13:20:25.896451+00	2026-04-01 13:20:25.896451+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
8ccecceb-4ad4-4fb0-a3fb-0f1a86122e69	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998933130818	t	f	f	f	3	0	0		2026-04-01 13:20:40.214859+00	2026-04-01 13:20:40.214859+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
14bb2d04-deaf-4ce2-a446-9dc919d3c0fd	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998934605995	t	f	f	f	2	0	0		2026-04-01 13:20:40.707625+00	2026-04-01 13:20:40.707625+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
b69f929f-63d2-439d-b6e8-6fa4bd3eba41	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913329404	t	f	f	f	2	0	0		2026-04-01 13:20:41.246395+00	2026-04-01 13:20:41.246395+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
8ab6b117-88b1-4d04-a036-016b9830ce27	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998931333534	t	f	f	f	2	0	0		2026-04-01 13:20:41.791219+00	2026-04-01 13:20:41.791219+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
626f0742-3307-4341-a272-0f9f9b8a0ceb	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998918559565	t	f	f	f	2	0	0		2026-04-01 13:22:51.92332+00	2026-04-01 13:22:51.92332+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
89b8e7e7-7383-44db-8b21-17c81b949c03	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998994145147	t	f	f	f	2	0	0		2026-04-01 13:25:30.432122+00	2026-04-01 13:25:30.432122+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
7d34322e-44fe-4d86-850e-e102f3c8c23c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	2	0	0		2026-04-01 17:43:56.674132+00	2026-04-01 17:43:56.674132+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
a811a59e-1868-440b-a0ef-fcfa8e871d16	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	2	0	0		2026-04-01 17:44:23.067032+00	2026-04-01 17:44:23.067032+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
4e5449ba-91dc-489b-878f-4c1178f05cbb	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	4	0	0		2026-04-01 17:44:51.91297+00	2026-04-01 17:44:51.91297+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
35cd48a8-9c82-4fbb-8a4a-97ac809dc730	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	2	0	0		2026-04-01 17:45:19.728597+00	2026-04-01 17:45:19.728597+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
8f0ad807-586c-4533-acfe-faf4256f76ae	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	4	0	0		2026-04-01 17:45:47.838804+00	2026-04-01 17:45:47.838804+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
4d13f79f-9884-4c35-b69f-348697616ef4	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	6	0	0		2026-04-01 17:46:02.174174+00	2026-04-01 17:46:02.174174+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
19f0f9af-e859-455b-9625-31aa17dbba20	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	3	0	0		2026-04-01 18:28:25.649115+00	2026-04-01 18:28:25.649115+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
537ab793-6cd9-4c30-8204-f8f1e48f1382	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998933177442	t	f	f	f	2	0	0	Второй номер: +998880820787	2026-04-01 18:28:33.372797+00	2026-04-01 18:28:33.372797+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
577fbf8b-efd0-4c67-abff-37f1d187e8c2	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998933151873	t	f	f	f	1	0	0		2026-04-01 18:28:41.515427+00	2026-04-01 18:28:41.515427+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
59f57da7-7739-4703-bb8a-43c36795cd5b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998938814846	t	f	f	f	7	0	0		2026-04-01 18:28:49.305938+00	2026-04-01 18:28:49.305938+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
bdfaaff2-c768-46c0-a6b3-f6d9ded17aec	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	2	0	0		2026-04-01 18:28:57.901319+00	2026-04-01 18:28:57.901319+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
03e45cea-329b-4c01-bbb4-19b8bd9bd765	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998792276829	t	f	f	f	2	0	0		2026-04-01 18:29:05.825328+00	2026-04-01 18:29:05.825328+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
4f9e9bd8-06cf-401f-8376-c26a0f64f679	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	6	0	0		2026-04-01 18:29:13.626853+00	2026-04-01 18:29:13.626853+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
35cb1e9b-d2b2-44f4-87d2-1e839c44de9a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	Gorni kollej	\N	+000000041	t	f	f	f	2	0	0	Dubli import (qator 75)	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
06be5f3a-b257-485e-863d-2fc500a1fd32	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	NKMK Qurilish *	\N	+000000042	t	f	f	f	12	0	0	Dubli import (qator 78)	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
4c259ce9-f7e3-4352-b915-2b2fb5e1f45c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	Uran zam kadr	\N	+000000043	t	f	f	f	2	0	0	Dubli import (qator 82)	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
7b2e5b8f-7310-4d8a-b72d-fac45c28e99e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	Uran 1/2	\N	+000000044	t	f	f	f	1	0	0	Dubli import (qator 84)	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
9469e28d-9ce0-4b7d-8fb5-9bbb51ba13df	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	Uran Loyiha	\N	+000000045	t	f	f	f	9	0	0	Dubli import (qator 87)	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
46c795d9-92d3-4173-a94c-a6914546a063	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	Uran  UVP	\N	+000000046	t	f	f	f	2	0	0	Dubli import (qator 91)	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
679dca2a-9719-44e5-b4e2-4bfb3a8997f7	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	2 Polik	\N	+000000047	t	f	f	f	1	0	0	Dubli import (qator 109)	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
04d7cc78-2b9a-49f3-b16f-429fc9b5a1d4	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	OblZdrav	\N	+000000048	t	f	f	f	3	0	0	Dubli import (qator 118)	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
ad307912-0235-47a7-8d84-3a223bc88b74	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	Sanatshunos	\N	+000000049	t	f	f	f	2	0	0	Dubli import (qator 124)	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
4bfc91d0-eca1-439b-a477-045ec2b56598	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	Uztelecom	\N	+000000050	t	f	f	f	3	0	0	Dubli import (qator 125)	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
f669c473-ee41-4ec5-ae13-54d1f8ea8a86	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	27 polik	\N	+000000051	t	f	f	f	3	0	0	Dubli import (qator 127)	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
c55ebcb5-4487-475d-b3f0-14a5f08233e9	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	Soliha market	\N	+000000052	t	f	f	f	2	0	0	Dubli import (qator 137)	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
b0ef380a-65e2-4f13-9fb2-5191630a81ab	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998934954744	t	f	f	f	2	0	0		2026-04-01 13:20:30.578817+00	2026-04-01 13:20:30.578817+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
938c2c4d-495a-4847-893c-d9890c9f88f2	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998905999725	t	f	f	f	2	0	0		2026-04-01 13:21:08.871319+00	2026-04-01 13:21:08.871319+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
86c209c2-5d14-4af8-a337-999f3f1fb1a9	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998503024424	t	f	f	f	4	0	0		2026-04-01 13:21:09.398771+00	2026-04-01 13:21:09.398771+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
aee10b01-2799-4198-b066-d3a3781c0bee	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998910899100	t	f	f	f	2	0	0		2026-04-01 13:21:09.928116+00	2026-04-01 13:21:09.928116+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
fc79bf31-a5fb-4282-ad33-5297aaf448ac	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998933810234	t	f	f	f	1	0	0		2026-04-01 13:21:10.414865+00	2026-04-01 13:21:10.414865+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
9d6af115-1b50-41f9-bdc9-6d29b228955b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998933978680	t	f	f	f	2	0	0		2026-04-01 13:21:11.401004+00	2026-04-01 13:21:11.401004+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
a9358538-ea53-4037-ad97-af19b485c330	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913354970	t	f	f	f	2	0	0		2026-04-01 13:23:15.801229+00	2026-04-01 13:23:15.801229+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
6d3fe089-52a5-4d75-9b26-c375184d2499	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998972280200	t	f	f	f	5	0	0		2026-04-01 13:21:10.885986+00	2026-04-01 13:21:10.885986+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
2576b21a-b0a2-4bc5-8c15-fcd2b7f23919	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	2	0	0		2026-04-01 17:43:40.404352+00	2026-04-01 17:43:40.404352+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
7e4473b3-b9df-4bce-9f6b-b9f3d42e3af9	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	2	0	0		2026-04-01 17:43:57.24448+00	2026-04-01 17:43:57.24448+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
9acdea56-814b-4170-b615-3f9160a450a7	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	2	0	0		2026-04-01 17:44:25.13618+00	2026-04-01 17:44:25.13618+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
84b80046-fa01-4010-949a-c6d2f3fe49bd	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	3	0	0		2026-04-01 17:44:52.706709+00	2026-04-01 17:44:52.706709+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
5de00ad1-ed89-4de6-b476-2ed2bfedd978	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	3	0	0		2026-04-01 17:45:22.344075+00	2026-04-01 17:45:22.344075+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
8247d082-3744-4c41-a22b-95a3d528da06	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	4	0	0		2026-04-01 17:45:48.980601+00	2026-04-01 17:45:48.980601+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
efeffa3a-f465-4f67-8333-0a2e5d3d635d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	3	0	0		2026-04-01 17:46:02.660951+00	2026-04-01 17:46:02.660951+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
3b76ed23-0c4b-4956-844c-839d81071b57	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	8	0	0		2026-04-01 18:28:26.206698+00	2026-04-01 18:28:26.206698+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
63ca8318-1a56-40f4-a54b-009747795ff8	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913310440	t	f	f	f	3	0	0		2026-04-01 18:28:34.038718+00	2026-04-01 18:28:34.038718+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
aafe6824-a41a-48a0-a146-22688d0b4531	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998931264646	t	f	f	f	3	0	0		2026-04-01 18:28:42.009041+00	2026-04-01 18:28:42.009041+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
94070549-c817-4d9b-b20c-e84005f0ffd4	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998933136410	t	f	f	f	4	0	0		2026-04-01 18:28:49.8368+00	2026-04-01 18:28:49.8368+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
e275d9d0-858f-4da6-8bfe-67505b191c34	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	2	0	0		2026-04-01 18:28:58.660816+00	2026-04-01 18:28:58.660816+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
5df682e0-30fd-483a-836e-4d94e65c4063	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998792276801	t	f	f	f	8	0	0		2026-04-01 18:29:06.391603+00	2026-04-01 18:29:06.391603+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
12a6fe1e-2334-41a9-9213-b95c92b1da3a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998973233323	t	f	f	f	5	0	0		2026-04-01 18:29:14.237678+00	2026-04-01 18:29:14.237678+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
a83c6785-b580-4d69-aac5-95419f6d802e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		f	f	f	f	0	0	0		2026-04-01 17:46:27.426966+00	2026-04-02 12:41:36.163912+00	t	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
75b72f20-3fcb-4922-b315-f9caa8bf36b1	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998912510151	t	f	f	f	2	0	0		2026-04-01 13:20:46.818325+00	2026-04-01 13:20:46.818325+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
9ae9556d-2d8e-41db-8a50-0c0403882615	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998939017002	t	f	f	f	2	0	0		2026-04-01 13:21:35.891571+00	2026-04-01 13:21:35.891571+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
111a1c17-a585-4000-9dea-bcd8b099ab21	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913091630	t	f	f	f	4	0	0		2026-04-01 13:21:36.371284+00	2026-04-01 13:21:36.371284+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
e59c6830-5977-4adb-bfdc-bf0c7d61edd6	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998977960112	t	f	f	f	2	0	0		2026-04-01 13:21:36.837706+00	2026-04-01 13:21:36.837706+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
32ed3797-ed06-4e65-bdc3-1b698a0c2263	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998905010008	t	f	f	f	2	0	0		2026-04-01 13:21:37.333688+00	2026-04-01 13:21:37.333688+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
0a62a0d9-de03-4816-b30d-1810d27d89b1	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913364226	t	f	f	f	2	0	0		2026-04-01 13:21:37.844921+00	2026-04-01 13:21:37.844921+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
3e9bc7cb-9e76-478d-9084-e1c58c49e360	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998974567277	t	f	f	f	2	0	0		2026-04-01 13:21:38.903211+00	2026-04-01 13:21:38.903211+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
a396e52d-be9a-47f9-80a2-07e2ddb89ea6	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998908076667	t	f	f	f	2	0	0		2026-04-01 13:21:39.406676+00	2026-04-01 13:21:39.406676+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
b1f6764a-e220-4bbf-a65d-1e87c4a09fd9	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913329922	t	f	f	f	2	0	0		2026-04-01 13:21:40.085818+00	2026-04-01 13:21:40.085818+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
6ab17fa7-37a8-4135-8038-c05e488fee6d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998977883131	t	f	f	f	3	0	0		2026-04-01 13:21:40.606208+00	2026-04-01 13:21:40.606208+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
c43327fe-dfde-4b09-afe0-1a7defe4622c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998936125204	t	f	f	f	2	0	0		2026-04-01 13:23:21.221376+00	2026-04-01 13:23:21.221376+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
1ccb0024-76f4-4f4d-ba9a-92a9cc66259f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	2	0	0		2026-04-01 17:43:40.865348+00	2026-04-01 17:43:40.865348+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
5832ab74-e8b9-4e10-95bf-8bc6e1025029	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	4	0	0		2026-04-01 17:43:57.964528+00	2026-04-01 17:43:57.964528+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
22c6aeab-fa65-4d8a-9b70-c1c96b5293e0	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	2	0	0		2026-04-01 17:44:25.637318+00	2026-04-01 17:44:25.637318+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
b4a52c9d-e881-40e9-be9d-39d5cdc9f392	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	4	0	0		2026-04-01 17:44:54.252773+00	2026-04-01 17:44:54.252773+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
f226190b-7a6b-46e4-be55-b50a3340d54a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	1	0	0		2026-04-01 17:45:23.284283+00	2026-04-01 17:45:23.284283+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
6be012f2-0ba2-4034-a3b9-123f27c4f462	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	2	0	0		2026-04-01 17:45:49.696742+00	2026-04-01 17:45:49.696742+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
bab74d08-9f0b-49ff-a81e-ccbdfba6401d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	3	0	0		2026-04-01 17:46:04.802599+00	2026-04-01 17:46:04.802599+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
48ce15c7-decb-49f0-b5c1-bc9d3b131822	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913090300	t	f	f	f	6	0	0		2026-04-01 18:28:26.705425+00	2026-04-01 18:28:26.705425+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
ce010c20-a9b7-430b-bd31-ce2b712cf4a7	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998981415151	t	f	f	f	1	0	0		2026-04-01 18:28:34.747234+00	2026-04-01 18:28:34.747234+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
d7f561d1-3d78-43d9-8ad6-cf7a1d032489	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998912510313	t	f	f	f	1	0	0		2026-04-01 18:28:42.51787+00	2026-04-01 18:28:42.51787+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
894b028b-a528-4755-9d17-07360f1f5150	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998907172040	t	f	f	f	2	0	0		2026-04-01 18:28:50.394346+00	2026-04-01 18:28:50.394346+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
118cee2a-e0e2-4a3b-ac23-e7c633ee663a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	3	0	0		2026-04-01 18:28:59.214062+00	2026-04-01 18:28:59.214062+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
ed5da426-58a8-4790-86f5-79b4fe1eae2e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998973673626	t	f	f	f	5	0	0	Второй номер: +998939505696	2026-04-01 18:29:06.848001+00	2026-04-01 18:29:06.848001+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
f62d3202-c7db-4d89-937e-1aef4d638ec5	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998972834565	t	f	f	f	1	0	0		2026-04-01 18:29:14.74847+00	2026-04-01 18:29:14.74847+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
221df0f1-a261-473e-8bbe-8d539f600a47	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	Feruz	Eshonqulov	+998993386251	t	f	f	f	0	0	0	\N	2026-04-02 15:31:48.341048+00	2026-04-02 15:31:48.341048+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
d5f90dd9-cf40-438f-b0c8-12619634e9cc	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998933122600	t	f	f	f	2	0	0		2026-04-01 13:20:54.15998+00	2026-04-01 13:20:54.15998+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
159cd0da-d8df-453c-8dab-c1fee374422a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998912541666	t	f	f	f	2	0	0		2026-04-01 13:22:03.671999+00	2026-04-01 13:22:03.671999+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
9b73de30-2c58-4beb-bf67-27f16bf71277	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998883231171	t	f	f	f	1	0	0		2026-04-01 13:22:04.383185+00	2026-04-01 13:22:04.383185+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
d6946742-18bf-414d-8605-b8bfab3ea31c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998997339899	t	f	f	f	2	0	0		2026-04-01 13:22:04.86173+00	2026-04-01 13:22:04.86173+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
131cdbc9-209c-4c25-b851-0587ca1e536a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998931079204	t	f	f	f	2	0	0		2026-04-01 13:23:25.872733+00	2026-04-01 13:23:25.872733+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
9d67c915-05d4-448c-8057-c37a65df9c34	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	4	0	0		2026-04-01 17:43:41.460865+00	2026-04-01 17:43:41.460865+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
2f43b891-7c89-4943-981b-4888063ab0ad	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	2	0	0		2026-04-01 17:43:58.786281+00	2026-04-01 17:43:58.786281+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
b98ccca0-f79b-4a4b-8dca-1f848ab89f63	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	2	0	0		2026-04-01 17:44:28.527196+00	2026-04-01 17:44:28.527196+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
54483acb-42ff-4798-8f62-d75a915a986d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	3	0	0		2026-04-01 17:44:55.0013+00	2026-04-01 17:44:55.0013+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
253c85e6-987b-42aa-82e2-8bf3bebc4529	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	1	0	0		2026-04-01 17:45:23.780327+00	2026-04-01 17:45:23.780327+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
c4db3096-2e52-49f4-a20d-dd89f34fef9c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	0	0	0		2026-04-01 17:45:50.958737+00	2026-04-01 17:45:50.958737+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
a623f68a-8dd3-4e62-bfdb-cb4bf1d6f022	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	2	0	0		2026-04-01 17:46:05.761791+00	2026-04-01 17:46:05.761791+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
732995d0-c108-4b06-b381-e957010c8501	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998973689596	t	f	f	f	3	0	0		2026-04-01 18:28:27.289948+00	2026-04-01 18:28:27.289948+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
8d43be71-dfd5-414d-b8ec-daee2ca12991	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998934308623	t	f	f	f	1	0	0		2026-04-01 18:28:35.21284+00	2026-04-01 18:28:35.21284+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
865a489e-dde3-4c8d-8f68-bf6edba03504	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913340698	t	f	f	f	1	0	0		2026-04-01 18:28:43.034319+00	2026-04-01 18:28:43.034319+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
3d27a502-4265-4959-8285-41eea675c569	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998910019339	t	f	f	f	5	0	0		2026-04-01 18:28:50.863128+00	2026-04-01 18:28:50.863128+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
682ed1bf-dcd5-47cd-99a3-4277b4e92d23	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998933151571	t	f	f	f	3	0	0		2026-04-01 18:28:59.704105+00	2026-04-01 18:28:59.704105+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
99c5b9ad-d214-49f8-ba12-0e52a45c991e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998942232320	t	f	f	f	2	0	0		2026-04-01 18:29:07.397068+00	2026-04-01 18:29:07.397068+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
197eb282-bef7-4b24-99c3-b3cfa68fba53	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998905005725	t	f	f	f	3	0	0		2026-04-01 18:29:15.398554+00	2026-04-01 18:29:15.398554+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
217e8909-1d64-40b1-bc14-55378f36cb1c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	.	.	+998772667007	t	f	f	f	0	0	0	\N	2026-04-04 02:03:42.168611+00	2026-04-04 02:03:42.168611+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
2b201bcd-7989-401b-8c26-8d59820c2ba9	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998907317932	t	f	f	f	2	0	0		2026-04-01 13:21:00.340019+00	2026-04-01 13:21:00.340019+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
e98a8d71-a658-4ba4-b082-dc02e96876d3	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998995552551	t	f	f	f	2	0	0		2026-04-01 13:22:31.740209+00	2026-04-01 13:22:31.740209+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
b1d387b0-0d63-4278-a227-e1bd0d10095a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998907314004	t	f	f	f	2	0	0		2026-04-01 13:22:32.224287+00	2026-04-01 13:22:32.224287+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
ad32d797-5e4c-4bad-a88a-cb71fc82d516	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998936639089	t	f	f	f	2	0	0		2026-04-01 13:22:32.669612+00	2026-04-01 13:22:32.669612+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
01c64783-f6d8-497b-8c93-21f0c6c447c8	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998938839040	t	f	f	f	2	0	0		2026-04-01 13:22:33.141589+00	2026-04-01 13:22:33.141589+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
79065c59-199c-497d-801b-1eb358840833	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998907320174	t	f	f	f	2	0	0		2026-04-01 13:22:33.628388+00	2026-04-01 13:22:33.628388+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
be8d6f5b-c917-4d31-bb23-02033e3de73b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913376644	t	f	f	f	3	0	0		2026-04-01 13:22:34.109113+00	2026-04-01 13:22:34.109113+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
10ebf47f-7ef3-406f-bc53-773d07876991	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998906180306	t	f	f	f	2	0	0		2026-04-01 13:22:34.603972+00	2026-04-01 13:22:34.603972+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
ebbdf4e3-145c-4bdc-bdc4-0938ff30a40f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998933199516	t	f	f	f	2	0	0		2026-04-01 13:23:49.129264+00	2026-04-01 13:23:49.129264+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
ea5bc104-1b53-4154-aeee-911125a5f07f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	5	0	0		2026-04-01 17:43:42.389257+00	2026-04-01 17:43:42.389257+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
db3c3d4e-8999-4264-abad-d60affdae5a5	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	2	0	0		2026-04-01 17:43:59.68071+00	2026-04-01 17:43:59.68071+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
bb42fd0f-dc6e-4882-b62b-e60756ca3d72	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	2	0	0		2026-04-01 17:44:29.991976+00	2026-04-01 17:44:29.991976+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
91cd510f-4a02-40be-beaf-8832a17da49f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	2	0	0		2026-04-01 17:44:58.15769+00	2026-04-01 17:44:58.15769+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
3c9cf004-be83-47df-b94c-1486b2ca8332	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	1	0	0		2026-04-01 17:45:25.059643+00	2026-04-01 17:45:25.059643+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
c98c4ff0-2fe1-4b9c-89df-6f108b3a6982	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	5	0	0		2026-04-01 17:45:52.02685+00	2026-04-01 17:45:52.02685+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
5788538b-17a8-46d9-8222-2e36e0952bb2	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	2	0	0		2026-04-01 17:46:06.609697+00	2026-04-01 17:46:06.609697+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
20e6fde7-d94f-46ff-a6d0-edcc614b4e17	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998914017557	t	f	f	f	4	0	0		2026-04-01 18:28:27.904101+00	2026-04-01 18:28:27.904101+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
79228f67-ab3d-4f0e-a26a-54537a85b028	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998930872020	t	f	f	f	2	0	0		2026-04-01 18:28:35.701431+00	2026-04-01 18:28:35.701431+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
b8c93a21-f760-41e5-bb8e-6a0784e2a9b3	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	1	0	0		2026-04-01 18:28:43.532409+00	2026-04-01 18:28:43.532409+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
3ee5948e-e29a-4f93-bf67-834a6dfcdcee	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	1	0	0		2026-04-01 18:28:51.495835+00	2026-04-01 18:28:51.495835+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
ab08da15-4dcf-4c08-bbf9-198e56336c8c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998934309373	t	f	f	f	2	0	0		2026-04-01 18:29:00.494075+00	2026-04-01 18:29:00.494075+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
a96042c9-2e84-45dc-8e65-a0502ffa5b54	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998994171601	t	f	f	f	2	0	0		2026-04-01 18:29:07.965776+00	2026-04-01 18:29:07.965776+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
0432e02a-6a4d-4e99-9b3f-2efe59c59666	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998942597787	t	f	f	f	2	0	0		2026-04-01 18:29:15.967988+00	2026-04-01 18:29:15.967988+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
a3270aa4-5751-439e-b56b-062380420324	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	93afb7df-adc4-452b-8f3b-f4ea0b52bec6	Alisher	Abduahatov	+998997555516	t	t	f	f	0	0	0	\N	2026-04-11 15:16:34.609078+00	2026-04-11 15:16:34.609078+00	f	\N
23a5e11f-bf5d-4d2b-a9ae-957dd1677135	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998906209583	t	f	f	f	4	0	0		2026-04-01 13:21:04.494206+00	2026-04-01 13:21:04.494206+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
6ae0c596-32a7-4665-a254-f148bab037fd	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998792277412	t	f	f	f	2	0	0		2026-04-01 13:23:00.044733+00	2026-04-01 13:23:00.044733+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
764a8eda-8b72-4942-b588-59f0f053ccb9	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998975592627	t	f	f	f	2	0	0		2026-04-01 13:23:00.710009+00	2026-04-01 13:23:00.710009+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
305add72-1d0b-4260-95d6-e92d0ad0a4b1	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998936640531	t	f	f	f	4	0	0		2026-04-01 13:23:01.216071+00	2026-04-01 13:23:01.216071+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
9510b260-b97b-49e6-8665-e5ca025703db	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998907178047	t	f	f	f	2	0	0		2026-04-01 13:23:01.652307+00	2026-04-01 13:23:01.652307+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
11a5a3dd-bb7b-4c95-bb77-bdc8cdf597db	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998990152839	t	f	f	f	2	0	0		2026-04-01 13:23:54.188789+00	2026-04-01 13:23:54.188789+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
9ff5ebf5-d8c2-4343-84ec-00f2147bf17f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	2	0	0		2026-04-01 17:43:42.964432+00	2026-04-01 17:43:42.964432+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
2efe2b86-ce51-47d3-b17a-5c8f78fb30b4	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	2	0	0		2026-04-01 17:44:02.198633+00	2026-04-01 17:44:02.198633+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
f66f3fb1-65c0-4217-a842-dff0ed47f721	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	5	0	0		2026-04-01 17:44:30.677605+00	2026-04-01 17:44:30.677605+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
c52c1ea7-8dcd-438b-a360-0bad42373ff9	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	2	0	0		2026-04-01 17:45:01.124252+00	2026-04-01 17:45:01.124252+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
c1df720a-6642-4922-9c86-fc91fa7c1ccb	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	3	0	0		2026-04-01 17:45:28.583218+00	2026-04-01 17:45:28.583218+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
9187db33-aa29-421d-b6fd-e788a2921534	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	0	0	0		2026-04-01 17:45:52.736329+00	2026-04-01 17:45:52.736329+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
2e469a62-fdb3-4d2e-a21c-fe74a4ce2a4e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	4	0	0		2026-04-01 17:46:10.20827+00	2026-04-01 17:46:10.20827+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
3f751ddb-c690-4791-a704-ce6fa9b028ed	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998985713700	t	f	f	f	3	0	0		2026-04-01 18:28:28.698454+00	2026-04-01 18:28:28.698454+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
f794d673-f4f5-493d-92b0-3ef6ce270ca6	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913374143	t	f	f	f	1	0	0		2026-04-01 18:28:36.367085+00	2026-04-01 18:28:36.367085+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
a7e89539-82f4-48be-8ae2-a70a8c184c7c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998972282812	t	f	f	f	1	0	0		2026-04-01 18:28:43.992566+00	2026-04-01 18:28:43.992566+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
f9d02251-98b6-423d-a65d-561e498f82e1	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998994581205	t	f	f	f	1	0	0		2026-04-01 18:28:51.968754+00	2026-04-01 18:28:51.968754+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
f8d61dc9-1657-42bd-b201-3a3b8c30da67	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998936189922	t	f	f	f	9	0	0		2026-04-01 18:29:00.974465+00	2026-04-01 18:29:00.974465+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
d12524f3-35cc-4e32-8617-9a903f91d5f9	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998906198304	t	f	f	f	1	0	0		2026-04-01 18:29:08.478559+00	2026-04-01 18:29:08.478559+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
9364705e-67da-414b-99c6-e224217313fb	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998942510200	t	f	f	f	3	0	0		2026-04-01 18:29:16.858509+00	2026-04-01 18:29:16.858509+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
9b56ec33-efa1-484a-ae8d-e192776832da	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998990030902	t	f	f	f	1	0	0		2026-04-01 13:21:28.045965+00	2026-04-01 13:21:28.045965+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
bf35e1a6-5230-4165-a891-796bcd19eebc	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998906652231	t	f	f	f	5	0	0		2026-04-01 13:23:27.871742+00	2026-04-01 13:23:27.871742+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
a1dae8ac-bd49-4a1e-a0a6-28e998cb4f30	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998934308180	t	f	f	f	3	0	0		2026-04-01 13:23:28.369048+00	2026-04-01 13:23:28.369048+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
5a06e635-7b5d-484e-bf7f-09625b9f02b0	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998907178787	t	f	f	f	2	0	0		2026-04-01 13:23:28.871085+00	2026-04-01 13:23:28.871085+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
a8ced727-ffde-43ff-ac27-73a2016c2ef1	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998906461114	t	f	f	f	3	0	0		2026-04-01 13:23:29.826659+00	2026-04-01 13:23:29.826659+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
111a8d21-4be8-4261-8d3e-43ac79a78249	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913340986	t	f	f	f	1	0	0		2026-04-01 13:23:30.363179+00	2026-04-01 13:23:30.363179+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
d3811557-86b3-460f-a1c9-3460b20e057e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998900857702	t	f	f	f	2	0	0		2026-04-01 13:24:00.095119+00	2026-04-01 13:24:00.095119+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
9ea09128-c3e7-460e-b1f3-6cf0c3b49b6b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	3	0	0		2026-04-01 17:43:44.268049+00	2026-04-01 17:43:44.268049+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
b053e2c1-0bf7-4310-858e-42cc3947e495	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	2	0	0		2026-04-01 17:44:03.134648+00	2026-04-01 17:44:03.134648+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
172fb0ba-a080-4ae6-85dd-d59495f966b1	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	2	0	0		2026-04-01 17:44:32.734709+00	2026-04-01 17:44:32.734709+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
49576e4e-162a-4c3b-bc88-b5387f7d121c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	3	0	0		2026-04-01 17:45:04.031215+00	2026-04-01 17:45:04.031215+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
bf3b552e-74d8-471d-9b73-1c5d8f8c73f6	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	2	0	0		2026-04-01 17:45:34.316745+00	2026-04-01 17:45:34.316745+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
1f61ca20-a029-4b95-ad0c-8364e3557214	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	4	0	0		2026-04-01 17:45:53.64067+00	2026-04-01 17:45:53.64067+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
7e7744c0-bce7-482e-ba48-cf757635bfef	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	2	0	0		2026-04-01 17:46:14.485956+00	2026-04-01 17:46:14.485956+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
6ee3d6f7-8e9d-48c0-a37f-b218f3790396	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998939562696	t	f	f	f	2	0	0		2026-04-01 18:28:29.243351+00	2026-04-01 18:28:29.243351+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
7c2c4a17-b8c1-4d95-9fa7-f37ca207711a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998792260402	t	f	f	f	1	0	0		2026-04-01 18:28:37.03258+00	2026-04-01 18:28:37.03258+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
6e810270-02e6-4351-ac47-b285637c404c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	1	0	0		2026-04-01 18:28:44.590109+00	2026-04-01 18:28:44.590109+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
912c5eb2-d94e-4227-a857-f9eaeea1c2f2	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998977974779	t	f	f	f	2	0	0		2026-04-01 18:28:52.759855+00	2026-04-01 18:28:52.759855+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
ebfbc932-e9e4-47d1-88dd-1451c6bce3d9	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	4	0	0		2026-04-01 18:29:01.538461+00	2026-04-01 18:29:01.538461+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
5483647d-7122-49d6-a47e-f41fbac9ba1a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913345445	t	f	f	f	14	0	0	Второй номер: +998905016070	2026-04-01 18:29:09.05975+00	2026-04-01 18:29:09.05975+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
f8bf4a6b-c791-4254-89a7-5c3cb6e8cff7	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998973200441	t	f	f	f	3	0	0		2026-04-01 18:29:17.630052+00	2026-04-01 18:29:17.630052+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
8c4e4001-cb12-4e69-8ffe-1eaedfa6a367	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998996228807	t	f	f	f	1	0	0		2026-04-01 13:21:33.950674+00	2026-04-01 13:21:33.950674+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
fca8a80c-67a3-4f35-bc85-ba15cd39aa40	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998902377730	t	f	f	f	3	0	0		2026-04-01 13:23:55.264051+00	2026-04-01 13:23:55.264051+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
75e7aec7-141c-49fd-a6b8-85c4b2129baa	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998919863034	t	f	f	f	2	0	0		2026-04-01 13:23:55.743619+00	2026-04-01 13:23:55.743619+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
2d894c91-3685-4ed9-af96-47724bac7cd7	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998958971221	t	f	f	f	2	0	0		2026-04-01 13:23:56.291716+00	2026-04-01 13:23:56.291716+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
8a7a20a5-5706-4871-82e0-edf6bb97bd24	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998990929146	t	f	f	f	2	0	0		2026-04-01 13:23:56.764772+00	2026-04-01 13:23:56.764772+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
dad338b6-dd95-4cf1-b41a-200b3980a4e3	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998934380730	t	f	f	f	3	0	0		2026-04-01 13:24:21.260581+00	2026-04-01 13:24:21.260581+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
2a52b6db-f7d5-47a1-ba55-c8258e751905	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	2	0	0		2026-04-01 17:43:44.895611+00	2026-04-01 17:43:44.895611+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
8b597269-391b-4983-91a7-1fad4cfdbb14	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	2	0	0		2026-04-01 17:44:04.191236+00	2026-04-01 17:44:04.191236+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
07d469f6-712b-4663-9004-589d66d9aae3	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	2	0	0		2026-04-01 17:44:33.406803+00	2026-04-01 17:44:33.406803+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
b41954f6-4ce0-4942-9a5a-8760e4f1b3a3	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	4	0	0		2026-04-01 17:45:07.877839+00	2026-04-01 17:45:07.877839+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
65aecf3a-2206-488d-b825-bd2bf5171e81	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	4	0	0		2026-04-01 17:45:36.141049+00	2026-04-01 17:45:36.141049+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
4c8a94c0-ecf6-4e1c-9a3f-81068a460b29	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	3	0	0		2026-04-01 17:45:54.135965+00	2026-04-01 17:45:54.135965+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
b779333f-beb0-4dd7-9c74-07fc4acc90d5	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	3	0	0		2026-04-01 17:46:15.318512+00	2026-04-01 17:46:15.318512+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
624ee260-9cbe-457d-a6dd-aced3bffdf40	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913322211	t	f	f	f	19	0	0		2026-04-01 18:28:29.734842+00	2026-04-01 18:28:29.734842+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
efd6da47-e380-4f2d-affc-5325ce9e6c85	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998889555524	t	f	f	f	2	0	0		2026-04-01 18:28:37.957854+00	2026-04-01 18:28:37.957854+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
b19d7c14-2b15-4eb9-a302-e57f8f869eb3	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998936646735	t	f	f	f	1	0	0		2026-04-01 18:28:45.190688+00	2026-04-01 18:28:45.190688+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
addd5e2d-e902-44d7-b068-ade7b2ff2d80	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998792277465	t	f	f	f	4	0	0	Второй номер: +998935217750	2026-04-01 18:28:53.620364+00	2026-04-01 18:28:53.620364+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
e52d4d56-1c5c-41c6-ae7a-32ffac53e242	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998795070087	t	f	f	f	1	0	0		2026-04-01 18:29:02.155212+00	2026-04-01 18:29:02.155212+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
48916350-a093-4d2c-abe3-4e72c9282f41	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998942237270	t	f	f	f	4	0	0	Второй номер: +998973210109	2026-04-01 18:29:09.785965+00	2026-04-01 18:29:09.785965+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
01ac363a-efdd-4c79-8768-9228989a37c2	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913353324	t	f	f	f	7	0	0		2026-04-01 18:29:18.168372+00	2026-04-01 18:29:18.168372+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
7cace199-c291-4d81-ad5f-8d1c8f8b2f93	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998907437884	t	f	f	f	2	0	0		2026-04-01 13:21:44.156216+00	2026-04-01 13:21:44.156216+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
b602bc68-920c-496c-a868-0616a69d8463	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998946281510	t	f	f	f	2	0	0		2026-04-01 13:24:23.172212+00	2026-04-01 13:24:23.172212+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
d91368ec-3b7f-49df-a7ae-ab4ba7452d4b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998935222753	t	f	f	f	4	0	0		2026-04-01 13:24:23.594361+00	2026-04-01 13:24:23.594361+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
32b3aaad-a9f6-4938-8f00-2b16e696a519	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998931467447	t	f	f	f	4	0	0		2026-04-01 13:24:24.212938+00	2026-04-01 13:24:24.212938+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
ed5f173e-5eff-4d01-8613-70456a1792f7	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998936391965	t	f	f	f	5	0	0		2026-04-01 13:24:24.66684+00	2026-04-01 13:24:24.66684+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
a3628222-1eb0-41be-9544-8aff59b38caf	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998942260075	t	f	f	f	5	0	0		2026-04-01 13:24:27.899546+00	2026-04-01 13:24:27.899546+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
5789c989-5b21-4cc6-8e19-f0037f573dd4	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	2	0	0		2026-04-01 17:43:46.333551+00	2026-04-01 17:43:46.333551+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
a4737ddb-833e-46f5-9e9f-e78e0ee1ea41	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	2	0	0		2026-04-01 17:44:07.492158+00	2026-04-01 17:44:07.492158+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
44428ef2-b48a-49fa-b8d6-d9a6d522b2b3	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	2	0	0		2026-04-01 17:44:35.266861+00	2026-04-01 17:44:35.266861+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
95951353-bd43-4505-b285-24efa5a7047c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	1	0	0		2026-04-01 17:45:11.052187+00	2026-04-01 17:45:11.052187+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
11d5905b-6f21-4074-baf8-d1a3b4988423	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	0	0	0		2026-04-01 17:45:39.380926+00	2026-04-01 17:45:39.380926+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
c0321e4f-69cc-4a0f-b18b-8c10fcf9a218	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	2	0	0		2026-04-01 17:45:54.64244+00	2026-04-01 17:45:54.64244+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
3f1c9476-49ab-41d9-a857-38d54a21a53b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	4	0	0		2026-04-01 17:46:20.425935+00	2026-04-01 17:46:20.425935+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
3949025b-76f0-4c06-b4ce-42f51d6f89aa	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998942270171	t	f	f	f	1	0	0		2026-04-01 18:28:30.287336+00	2026-04-01 18:28:30.287336+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
4f47b697-d8d6-4ac0-9388-f5e627a596a5	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998933131802	t	f	f	f	1	0	0		2026-04-01 18:28:38.448599+00	2026-04-01 18:28:38.448599+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
78424c22-2668-4234-82bd-baa9364ac513	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	50	0	0		2026-04-01 18:28:45.875676+00	2026-04-01 18:28:45.875676+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
6fb2b287-cb89-4cd8-9385-c4d35483d2f9	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998931011545	t	f	f	f	8	0	0	Второй номер: +998935210074	2026-04-01 18:28:54.084494+00	2026-04-01 18:28:54.084494+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
ec9b1c37-1d71-4d4b-a4d3-0b6d3f4af361	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998940231712	t	f	f	f	6	0	0		2026-04-01 18:29:02.689656+00	2026-04-01 18:29:02.689656+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
2da977ff-59df-4b14-ab15-19e612eafd10	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913345575	t	f	f	f	3	0	0		2026-04-01 18:29:10.348016+00	2026-04-01 18:29:10.348016+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
855f582d-1840-41e5-b12b-6db0eda7936a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998907171889	t	f	f	f	2	0	0		2026-04-01 18:29:18.725155+00	2026-04-01 18:29:18.725155+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
25cc1b36-517f-47c3-9b21-3aa82d27deb6	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998934374464	t	f	f	f	2	0	0		2026-04-01 13:22:07.852977+00	2026-04-01 13:22:07.852977+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
9d1e9c08-1317-4163-928f-5b780fb4d16a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998973208320	t	f	f	f	4	0	0		2026-04-01 13:24:32.798185+00	2026-04-01 13:24:32.798185+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
7fa1be37-b546-4d16-afd5-9942f66b6c26	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998991498414	t	f	f	f	3	0	0		2026-04-01 13:24:51.035441+00	2026-04-01 13:24:51.035441+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
5454a179-6c63-42fd-bd2f-b53da8731f66	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	4	0	0		2026-04-01 17:43:47.039557+00	2026-04-01 17:43:47.039557+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
c5eb2e30-d0bb-4cfe-9a08-7daa1a64658e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	2	0	0		2026-04-01 17:44:11.572558+00	2026-04-01 17:44:11.572558+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
c4a18744-8a5b-4410-9264-9e5902d01e39	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	2	0	0		2026-04-01 17:44:37.189369+00	2026-04-01 17:44:37.189369+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
f60a9cbd-ad1a-4b35-a4a8-176a4b835d79	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	2	0	0		2026-04-01 17:45:12.62982+00	2026-04-01 17:45:12.62982+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
c1b405ea-ae55-4f34-9440-d089fc7ccd47	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	2	0	0		2026-04-01 17:45:40.394531+00	2026-04-01 17:45:40.394531+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
c0108b0e-4a53-4a41-a4bf-47f096291cb0	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	0	0	0		2026-04-01 17:45:56.080014+00	2026-04-01 17:45:56.080014+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
cdb2da54-227e-479e-88d6-836ba3317fe2	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	3	0	0		2026-04-01 17:46:23.535698+00	2026-04-01 17:46:23.535698+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
5937e9b6-042e-40c6-86b7-9d4432364118	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	2	0	0		2026-04-01 18:28:30.790249+00	2026-04-01 18:28:30.790249+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
10d94320-df8e-47e4-b5e3-d0d84463ec57	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998906464966	t	f	f	f	1	0	0		2026-04-01 18:28:38.922604+00	2026-04-01 18:28:38.922604+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
9d9f2539-ceb1-4a75-9725-b2440300cf4a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998972972506	t	f	f	f	2	0	0	Второй номер: +998912541008	2026-04-01 18:28:46.551601+00	2026-04-01 18:28:46.551601+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
a364fb60-7060-4332-9b2d-cd2a9ca9b2db	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998792278135	t	f	f	f	10	0	0	Второй номер: +998973224200	2026-04-01 18:28:54.802043+00	2026-04-01 18:28:54.802043+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
f742553a-cb89-4bdf-98b9-9cad8505a793	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998907173067	t	f	f	f	21	0	0	Второй номер: +998979005554	2026-04-01 18:29:03.249738+00	2026-04-01 18:29:03.249738+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
e1cbc010-1344-4fd6-8ca0-92a00d1b6268	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998907306556	t	f	f	f	3	0	0	Второй номер: +998939525151	2026-04-01 18:29:10.831059+00	2026-04-01 18:29:10.831059+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
e6b2e204-9b44-4bf7-95fb-9dc8eac5f0dd	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998933190102	t	f	f	f	2	0	0		2026-04-01 18:29:19.319267+00	2026-04-01 18:29:19.319267+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
e0f7cd8a-7d4f-4ba9-9778-b3083a3b8c7a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998942212328	t	f	f	f	2	0	0		2026-04-01 13:22:12.831078+00	2026-04-01 13:22:12.831078+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
9575391e-4334-4798-a4c7-77bf0a36d7e0	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998907307354	t	f	f	f	2	0	0		2026-04-01 13:24:53.484041+00	2026-04-01 13:24:53.484041+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
f62f4699-9571-410a-a003-87bb0a8f6002	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913316920	t	f	f	f	2	0	0		2026-04-01 13:25:19.126911+00	2026-04-01 13:25:19.126911+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
55c4ba2e-ac87-4dd0-95a8-b801706fe09c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998905016269	t	f	f	f	3	0	0		2026-04-01 13:25:19.625538+00	2026-04-01 13:25:19.625538+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
9e8d70d0-a74f-447a-a404-1a4346b0f090	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998907394746	t	f	f	f	3	0	0		2026-04-01 13:25:20.210383+00	2026-04-01 13:25:20.210383+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
f6a47482-8433-49eb-933a-3013319c46bc	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998906207270	t	f	f	f	3	0	0		2026-04-01 13:25:20.78494+00	2026-04-01 13:25:20.78494+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
4a3ebeef-9619-41b9-bb95-8d2552f10daf	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998930857042	t	f	f	f	2	0	0		2026-04-01 13:25:21.388249+00	2026-04-01 13:25:21.388249+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
750175ab-d48a-44bc-9a60-ba576a4f1f07	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	2	0	0		2026-04-01 17:43:47.612937+00	2026-04-01 17:43:47.612937+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
f245d534-1146-486b-bb2f-7a2cb6c4beaa	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	2	0	0		2026-04-01 17:44:13.795843+00	2026-04-01 17:44:13.795843+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
0bd6673b-8c97-4c9c-bb4a-45697cd24c34	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	2	0	0		2026-04-01 17:44:38.993835+00	2026-04-01 17:44:38.993835+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
d7a9a16a-cc6c-42d7-8e6a-7dfa0efe2266	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	2	0	0		2026-04-01 17:45:15.544113+00	2026-04-01 17:45:15.544113+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
aeab8a6e-8258-4f8a-8e15-6f7e8d697937	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	1	0	0		2026-04-01 17:45:41.273278+00	2026-04-01 17:45:41.273278+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
1bd49053-a2e1-4d50-abb8-ef24f984a0ed	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	3	0	0		2026-04-01 17:45:56.569621+00	2026-04-01 17:45:56.569621+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
8da8a133-022f-4e85-9e4b-c8d70b3b6df9	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	3	0	0		2026-04-01 17:46:24.443814+00	2026-04-01 17:46:24.443814+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
107ba811-3dcf-45af-8b76-740b2e5f7976	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998933150272	t	f	f	f	2	0	0		2026-04-01 18:28:31.303244+00	2026-04-01 18:28:31.303244+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
16258b36-b30b-41d8-91db-445ba4748e07	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	1	0	0		2026-04-01 18:28:39.477988+00	2026-04-01 18:28:39.477988+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
bbe1b2d2-5849-4b28-b8d1-4dcebc9dce6d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998906659902	t	f	f	f	5	0	0		2026-04-01 18:28:47.020513+00	2026-04-01 18:28:47.020513+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
097b99cc-71f1-45f7-b42f-b975d62ba9e1	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913383945	t	f	f	f	8	0	0		2026-04-01 18:28:55.415425+00	2026-04-01 18:28:55.415425+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
b1b8ffba-7252-4829-b7f6-3e7a427166dd	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	1	0	0		2026-04-01 18:29:03.781444+00	2026-04-01 18:29:03.781444+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
86f60744-4b1c-4d74-a968-86301cf91289	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998912492626	t	f	f	f	8	0	0	Второй номер: +998940099600	2026-04-01 18:29:11.35828+00	2026-04-01 18:29:11.35828+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
2cfa7854-02dd-455e-a868-dedbf440461c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998906655040	t	f	f	f	1	0	0		2026-04-01 18:29:19.802629+00	2026-04-01 18:29:19.802629+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
4ad54089-6bce-4516-bb99-e6b2ca3eef37	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	7a4fed15-43ec-4671-99df-adc96efb7c98	Akobir	Qodirov	+998913373937	t	t	f	f	0	0	0	\N	2026-04-01 14:09:44.451031+00	2026-04-01 14:09:44.451031+00	f	\N
411257e0-bd3c-49f0-aed7-cd2e34e912b6	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998902369292	t	f	f	f	2	0	0		2026-04-01 13:20:21.323703+00	2026-04-01 13:20:21.323703+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
62d7667a-c240-4fdc-92d4-f3c412060801	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998998674844	t	f	f	f	3	0	0		2026-04-01 13:20:22.754968+00	2026-04-01 13:20:22.754968+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
ebcb2036-9659-4baf-9972-53675405c5cb	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998906470211	t	f	f	f	2	0	0		2026-04-01 13:20:23.326244+00	2026-04-01 13:20:23.326244+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
5b1bc33d-b13b-47ee-98a5-982cbead4be9	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998905000711	t	f	f	f	3	0	0		2026-04-01 13:20:23.817134+00	2026-04-01 13:20:23.817134+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
728baaf8-634b-4d27-8396-5ab952871069	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998936125545	t	f	f	f	2	0	0		2026-04-01 13:20:24.315604+00	2026-04-01 13:20:24.315604+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
1e0defc7-bae1-4774-aee5-5d01be3f0960	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998979103936	t	f	f	f	3	0	0		2026-04-01 13:20:24.855281+00	2026-04-01 13:20:24.855281+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
23579dfb-ce92-4f39-8ac1-dba98bb6af61	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998907316291	t	f	f	f	2	0	0		2026-04-01 13:21:38.395287+00	2026-04-01 13:21:38.395287+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
786ea369-b6ff-422d-835d-ab0a6da06337	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998997330501	t	f	f	f	2	0	0		2026-04-01 13:21:41.130368+00	2026-04-01 13:21:41.130368+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
995ca24f-8a3d-4271-a418-69b21875f2ce	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998914393377	t	f	f	f	2	0	0		2026-04-01 13:21:43.102103+00	2026-04-01 13:21:43.102103+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
327fd4b3-a172-4c7d-b80d-7bb40e30fb93	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998906195155	t	f	f	f	3	0	0		2026-04-01 13:22:17.303258+00	2026-04-01 13:22:17.303258+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
c6fa8718-acee-4eef-ae43-ae217a563d89	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998930475105	t	f	f	f	2	0	0		2026-04-01 13:24:59.48746+00	2026-04-01 13:24:59.48746+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
dd72382a-ea5d-42d2-af55-10a802c5e848	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	4	0	0		2026-04-01 17:43:49.138918+00	2026-04-01 17:43:49.138918+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
8805867c-160e-4fbd-8326-b1fce9cefdb1	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	2	0	0		2026-04-01 17:44:17.325639+00	2026-04-01 17:44:17.325639+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
e73da619-943a-44eb-a5d5-4cb789198397	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	3	0	0		2026-04-01 17:44:39.572396+00	2026-04-01 17:44:39.572396+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
2f072d90-ea37-4f3b-a364-e80efe69dc73	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	2	0	0		2026-04-01 17:45:16.13256+00	2026-04-01 17:45:16.13256+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
5d690bed-491e-4525-9f2a-0100e094b498	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	0	0	0		2026-04-01 17:45:42.47619+00	2026-04-01 17:45:42.47619+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
876cde96-df35-4bfa-a16c-6f9f8e83f244	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	5	0	0		2026-04-01 17:45:58.651515+00	2026-04-01 17:45:58.651515+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
300d200d-a8ef-46c2-a6a2-8851e52e54b8	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	9	0	0		2026-04-01 18:28:31.763923+00	2026-04-01 18:28:31.763923+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
7ab93631-1167-460f-a3a6-e2724caf63f5	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998906197040	t	f	f	f	2	0	0		2026-04-01 18:28:39.975451+00	2026-04-01 18:28:39.975451+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
24776c81-d7b7-4829-a9ea-c9efa6e4a1e6	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	2	0	0		2026-04-01 18:28:47.586666+00	2026-04-01 18:28:47.586666+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
298ff33f-bf0f-4828-acfa-7001245fe7c9	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998935222942	t	f	f	f	4	0	0		2026-04-01 18:28:55.90444+00	2026-04-01 18:28:55.90444+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
6f4e81f1-76ca-4514-b260-4a1ad1f886f9	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998934300264	t	f	f	f	1	0	0		2026-04-01 18:29:04.24556+00	2026-04-01 18:29:04.24556+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
00248921-2386-4962-8cfc-3cd8cc62b708	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998946606099	t	f	f	f	3	0	0		2026-04-01 18:29:11.83896+00	2026-04-01 18:29:11.83896+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
7ce918d0-4f8e-405d-bfc9-ab05671e5c9b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998942551000	t	f	f	f	3	0	0		2026-04-01 18:29:20.324965+00	2026-04-01 18:29:20.324965+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
f8988854-92ae-417a-b5c8-9918f4936720	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		f	f	f	f	0	0	0		2026-04-01 17:46:26.856247+00	2026-04-02 12:41:39.305267+00	t	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
7719bb2a-30e2-4dd3-906b-559d34c9c217	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	9acbe1e9-7daa-40cc-b128-70dcc1bf6793	Xasan	Zaripov	+998900880282	t	t	f	f	0	0	0	\N	2026-04-01 15:33:15.324194+00	2026-04-01 15:33:15.324194+00	f	\N
518f40fd-4dc9-4442-9aa0-515b9331e211	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998912522252	t	f	f	f	2	0	0		2026-04-01 13:20:26.53055+00	2026-04-01 13:20:26.53055+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
f470bb63-e36c-4ac2-a19b-0c335cc22ad6	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998973239505	t	f	f	f	2	0	0		2026-04-01 13:20:27.020238+00	2026-04-01 13:20:27.020238+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
9fef4825-4551-4806-b8e0-7842b74d4c8c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913339434	t	f	f	f	2	0	0		2026-04-01 13:20:27.501974+00	2026-04-01 13:20:27.501974+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
88793a34-f091-4bd4-baee-2b65763f1f46	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998933162052	t	f	f	f	3	0	0		2026-04-01 13:20:28.093641+00	2026-04-01 13:20:28.093641+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
982a35f9-6f15-4f86-9417-94b1c1a73618	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998991020966	t	f	f	f	2	0	0		2026-04-01 13:20:29.026403+00	2026-04-01 13:20:29.026403+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
0764972e-0604-4069-867e-a6c013883d6e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998975597172	t	f	f	f	1	0	0		2026-04-01 13:20:29.545689+00	2026-04-01 13:20:29.545689+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
25823438-446e-4153-b996-1d84b86a19f3	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998914205777	t	f	f	f	4	0	0		2026-04-01 13:20:30.031565+00	2026-04-01 13:20:30.031565+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
c0a4a6fd-e107-4a7d-9ec4-9197041bf888	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998930642965	t	f	f	f	2	0	0		2026-04-01 13:20:31.119678+00	2026-04-01 13:20:31.119678+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
87654fdd-a0f5-4a64-b78c-fc6507bf614a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913309466	t	f	f	f	2	0	0		2026-04-01 13:20:31.652424+00	2026-04-01 13:20:31.652424+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
f6d7fd38-a84c-46fc-b9f3-f5c207cee877	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998901098800	t	f	f	f	2	0	0		2026-04-01 13:20:32.584845+00	2026-04-01 13:20:32.584845+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
f560e07a-8bf9-42e5-8b22-091ea150aad9	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913330069	t	f	f	f	2	0	0		2026-04-01 13:20:33.110822+00	2026-04-01 13:20:33.110822+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
24aeab6d-5106-4a0e-b2a1-f8c6bcda6f81	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998936287227	t	f	f	f	2	0	0		2026-04-01 13:20:34.097608+00	2026-04-01 13:20:34.097608+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
69c9e7d6-9c28-4b06-9630-546bc251a72e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998943751980	t	f	f	f	2	0	0		2026-04-01 13:20:34.56851+00	2026-04-01 13:20:34.56851+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
83d6ff88-88b7-4159-9c2b-c1414b862e04	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998931300999	t	f	f	f	3	0	0		2026-04-01 13:20:35.071441+00	2026-04-01 13:20:35.071441+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
dddd0db2-bd56-48d3-a615-672bcd1dd407	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998993368222	t	f	f	f	2	0	0		2026-04-01 13:20:35.573139+00	2026-04-01 13:20:35.573139+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
ef475737-6f1e-4b6a-ba26-d42f77489310	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998972832222	t	f	f	f	2	0	0		2026-04-01 13:20:36.091726+00	2026-04-01 13:20:36.091726+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
3ae1fcee-f18a-4eac-b1d3-24eb59b67acf	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913095136	t	f	f	f	1	0	0		2026-04-01 13:20:36.651813+00	2026-04-01 13:20:36.651813+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
50ac1951-f340-4fe3-91e8-aa5ba518084e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998936120719	t	f	f	f	2	0	0		2026-04-01 13:20:37.187423+00	2026-04-01 13:20:37.187423+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
0c7ae2a7-a1ca-4b9c-b74a-26b479cf33aa	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998942174447	t	f	f	f	3	0	0		2026-04-01 13:20:37.66821+00	2026-04-01 13:20:37.66821+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
46902e34-a767-46cb-832c-8f7cb701599c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998973674080	t	f	f	f	2	0	0		2026-04-01 13:20:51.110397+00	2026-04-01 13:20:51.110397+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
8912fe08-de80-4c64-9b0b-27def817dfbb	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998912545191	t	f	f	f	2	0	0		2026-04-01 13:20:39.192793+00	2026-04-01 13:20:39.192793+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
f7fd9fb1-52c7-484b-9b6a-aa5e2c150c09	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998980011098	t	f	f	f	1	0	0		2026-04-01 13:20:39.722658+00	2026-04-01 13:20:39.722658+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
856ec875-6b4e-4f8c-8f13-22ec192f817d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998505761103	t	f	f	f	4	0	0		2026-04-01 13:20:42.750632+00	2026-04-01 13:20:42.750632+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
c39e99fc-5391-4bb2-8687-b26ab3b40146	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998900855888	t	f	f	f	5	0	0		2026-04-01 13:20:43.259356+00	2026-04-01 13:20:43.259356+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
51ba792f-b1b1-4c7e-890e-28a7979fd206	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998905002556	t	f	f	f	3	0	0		2026-04-01 13:20:43.859337+00	2026-04-01 13:20:43.859337+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
fb73c94a-e21d-4b79-bd52-e8259a315ae3	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913345075	t	f	f	f	2	0	0		2026-04-01 13:20:44.309269+00	2026-04-01 13:20:44.309269+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
a66ac0b2-8a31-40f4-8247-cf96ca3f5907	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998985710441	t	f	f	f	5	0	0		2026-04-01 13:20:44.802118+00	2026-04-01 13:20:44.802118+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
bf732197-c807-402b-a228-f6061b4f7610	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998991942908	t	f	f	f	2	0	0		2026-04-01 13:20:45.32853+00	2026-04-01 13:20:45.32853+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
ebdb12f4-51c9-47ad-8660-97bdb9be8ef7	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913378445	t	f	f	f	2	0	0		2026-04-01 13:20:45.783065+00	2026-04-01 13:20:45.783065+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
f0a57bf5-e14c-49e3-90fa-5a2ee5d8dc8d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998944809933	t	f	f	f	2	0	0		2026-04-01 13:20:46.275454+00	2026-04-01 13:20:46.275454+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
23e88675-9a67-4275-a319-d566acd58f87	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998977978604	t	f	f	f	2	0	0		2026-04-01 13:20:47.313622+00	2026-04-01 13:20:47.313622+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
6c9ee279-a8c9-4eec-a7e2-949ddb162ff8	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998994126699	t	f	f	f	1	0	0		2026-04-01 13:20:47.789751+00	2026-04-01 13:20:47.789751+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
7c2d0e3a-1354-4196-a844-44d7d5f7883a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998935221212	t	f	f	f	3	0	0		2026-04-01 13:20:48.294298+00	2026-04-01 13:20:48.294298+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
cfa0ffac-d860-420f-9a83-75c33a81d652	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998994177475	t	f	f	f	2	0	0		2026-04-01 13:20:49.398128+00	2026-04-01 13:20:49.398128+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
8c804cf6-8261-4475-b7b1-25a2ab6f0bdb	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998792248514	t	f	f	f	3	0	0		2026-04-01 13:20:49.877812+00	2026-04-01 13:20:49.877812+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
6ff1f745-af21-4d77-8d73-7ba2576244b4	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998990706585	t	f	f	f	2	0	0		2026-04-01 13:20:50.399848+00	2026-04-01 13:20:50.399848+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
70e4380a-c487-4555-ac61-4f2c307bd422	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998972289384	t	f	f	f	2	0	0		2026-04-01 13:20:38.186242+00	2026-04-01 13:20:38.186242+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
6f26e321-0f96-4eb9-8258-8f1bc9f0bb36	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998907175552	t	f	f	f	3	0	0		2026-04-01 13:20:51.584876+00	2026-04-01 13:20:51.584876+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
ab20e2da-c3ed-49be-a6b8-89e863e67cf4	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998907176448	t	f	f	f	2	0	0		2026-04-01 13:20:52.161113+00	2026-04-01 13:20:52.161113+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
e318bdc7-90b4-46fe-9f02-c78653667174	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998936694845	t	f	f	f	2	0	0		2026-04-01 13:20:52.62115+00	2026-04-01 13:20:52.62115+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
48d4c5bc-7fb9-46a3-b083-5ccb18a90871	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998942563575	t	f	f	f	2	0	0		2026-04-01 13:20:53.108685+00	2026-04-01 13:20:53.108685+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
65d384ad-ec25-4956-989b-1debd6848a37	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998880937100	t	f	f	f	2	0	0		2026-04-01 13:20:53.676451+00	2026-04-01 13:20:53.676451+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
e0c9a6ed-be25-4406-8dcf-dbd2560ccb40	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998972289088	t	f	f	f	2	0	0		2026-04-01 13:20:54.662065+00	2026-04-01 13:20:54.662065+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
6f486f21-cb91-44c3-ac84-6ae90aaccb44	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998943327170	t	f	f	f	4	0	0		2026-04-01 13:20:55.187987+00	2026-04-01 13:20:55.187987+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
45e1cbf5-99a4-43a2-9c4b-c8f8e87fa42c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998907393373	t	f	f	f	2	0	0		2026-04-01 13:20:55.704109+00	2026-04-01 13:20:55.704109+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
e5ba9770-aebd-4b6d-b367-34598576dbb4	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998919912091	t	f	f	f	2	0	0		2026-04-01 13:20:56.180153+00	2026-04-01 13:20:56.180153+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
39fb09f9-d3a2-4c71-9f54-7564a2d5ccfc	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998887950020	t	f	f	f	2	0	0		2026-04-01 13:20:56.642326+00	2026-04-01 13:20:56.642326+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
5ab10ced-c04e-406b-a627-20d54032f2df	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998944881021	t	f	f	f	2	0	0		2026-04-01 13:20:48.815515+00	2026-04-01 13:20:48.815515+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
64c9beb9-9d88-4c1b-b0cb-d5daba497dca	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998919866065	t	f	f	f	4	0	0		2026-04-01 13:20:58.188463+00	2026-04-01 13:20:58.188463+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
adfead08-76e5-4e86-82ba-c3dd9460295c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998942239449	t	f	f	f	2	0	0		2026-04-01 13:20:58.671213+00	2026-04-01 13:20:58.671213+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
07d6aef6-7ac0-43b9-bce7-990c07f2da56	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998941645666	t	f	f	f	2	0	0		2026-04-01 13:20:59.234372+00	2026-04-01 13:20:59.234372+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
1aa7c743-312a-4d96-85a4-9c50dfb0bf8a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998973681466	t	f	f	f	4	0	0		2026-04-01 13:20:57.684929+00	2026-04-01 13:20:57.684929+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
e5b9efdf-3b96-4416-b547-27dd19b87c72	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998905003003	t	f	f	f	2	0	0		2026-04-01 13:21:00.804182+00	2026-04-01 13:21:00.804182+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
7d180fc5-63d1-415d-b77a-d9432187ffc9	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998906652912	t	f	f	f	2	0	0		2026-04-01 13:21:01.349547+00	2026-04-01 13:21:01.349547+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
38d7d6a2-6199-4e74-be81-5085a697a3ab	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998907302090	t	f	f	f	2	0	0		2026-04-01 13:21:01.853375+00	2026-04-01 13:21:01.853375+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
88c6a59d-2cdd-42d6-84c3-5bcfd4b9d360	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998977971420	t	f	f	f	2	0	0		2026-04-01 13:21:02.482911+00	2026-04-01 13:21:02.482911+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
be263a1e-7965-4cd8-855f-43d0178c3271	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998977957505	t	f	f	f	2	0	0		2026-04-01 13:21:02.948933+00	2026-04-01 13:21:02.948933+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
8d4fb535-ca09-4225-9771-c776f4ae4467	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998977968894	t	f	f	f	2	0	0		2026-04-01 13:21:03.418162+00	2026-04-01 13:21:03.418162+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
37619a3e-0c1f-4ecf-a369-0953678a9760	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998972287054	t	f	f	f	2	0	0		2026-04-01 13:21:03.984668+00	2026-04-01 13:21:03.984668+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
f53c15b3-5bc6-4417-b6fd-c37e8c0a62ba	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998906469786	t	f	f	f	4	0	0		2026-04-01 13:21:04.932922+00	2026-04-01 13:21:04.932922+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
165943d5-71ca-4948-a24c-ebd6b0f1b993	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913313077	t	f	f	f	2	0	0		2026-04-01 13:21:05.408816+00	2026-04-01 13:21:05.408816+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
e2a33e24-7cc1-4b69-bea4-830bd8fabd2d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998944840002	t	f	f	f	2	0	0		2026-04-01 13:21:05.901304+00	2026-04-01 13:21:05.901304+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
ffa3a089-7d91-4fca-8176-71e1bd193311	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913366631	t	f	f	f	3	0	0		2026-04-01 13:21:06.383303+00	2026-04-01 13:21:06.383303+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
1706ba1d-a7ad-4708-8f53-65c2fbe153a2	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998999585056	t	f	f	f	2	0	0		2026-04-01 13:21:06.981407+00	2026-04-01 13:21:06.981407+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
513001b3-97df-43de-9889-e74b9be17ce0	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998977954242	t	f	f	f	4	0	0		2026-04-01 13:21:07.496766+00	2026-04-01 13:21:07.496766+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
144c279a-fbcd-4152-ae1c-ef5e1c155b11	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913320262	t	f	f	f	2	0	0		2026-04-01 13:21:07.951147+00	2026-04-01 13:21:07.951147+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
debed304-4c80-421e-9d9d-818369dcf7d0	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998990755008	t	f	f	f	2	0	0		2026-04-01 13:21:11.883625+00	2026-04-01 13:21:11.883625+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
9a8dc426-b5cc-4897-bebb-9db5dda205ce	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998942570084	t	f	f	f	1	0	0		2026-04-01 13:21:12.928256+00	2026-04-01 13:21:12.928256+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
ee18ffee-13cb-43fe-983d-b9f2aa89cf13	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998975599889	t	f	f	f	3	0	0		2026-04-01 13:21:13.423534+00	2026-04-01 13:21:13.423534+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
10779a85-a5a0-4dd8-902f-13bff031e823	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913310363	t	f	f	f	2	0	0		2026-04-01 13:21:13.911678+00	2026-04-01 13:21:13.911678+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
7e12ed7b-53e8-4d20-88d6-913bb9c42186	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998501234671	t	f	f	f	2	0	0		2026-04-01 13:21:14.536158+00	2026-04-01 13:21:14.536158+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
196dde6a-fd12-45de-a079-02320c081a74	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998992230040	t	f	f	f	4	0	0		2026-04-01 13:21:15.034076+00	2026-04-01 13:21:15.034076+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
03f54fe3-c7e1-4c56-8afe-e37c6f5f2ab2	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998934372564	t	f	f	f	2	0	0		2026-04-01 13:21:15.979059+00	2026-04-01 13:21:15.979059+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
33738fee-c2f5-4d1b-9f56-9a1c443ce1f2	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998973782200	t	f	f	f	1	0	0		2026-04-01 13:21:16.465947+00	2026-04-01 13:21:16.465947+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
904334f2-bf09-4d1a-8fc7-27a74f2a34b1	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998945672700	t	f	f	f	2	0	0		2026-04-01 13:21:16.90634+00	2026-04-01 13:21:16.90634+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
21cbfec8-34b4-4b18-a538-24c8936619c6	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998977961221	t	f	f	f	2	0	0		2026-04-01 13:21:17.428254+00	2026-04-01 13:21:17.428254+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
c28cd3a8-307e-4482-a70d-ab6cf81bf5db	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913349004	t	f	f	f	2	0	0		2026-04-01 13:21:20.10023+00	2026-04-01 13:21:20.10023+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
d2ef428f-4ad1-45b6-95f0-c2c3f0e0d681	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998972281717	t	f	f	f	3	0	0		2026-04-01 13:21:18.441354+00	2026-04-01 13:21:18.441354+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
67336717-61de-40b3-af37-5c5fa6927b0d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998934359027	t	f	f	f	2	0	0		2026-04-01 13:21:18.918684+00	2026-04-01 13:21:18.918684+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
4c2b553d-6e3f-462c-80b8-745ea1b72c1d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998938353131	t	f	f	f	2	0	0		2026-04-01 13:21:19.441519+00	2026-04-01 13:21:19.441519+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
0f7bd388-c696-4707-8c56-1dbf2cdcb3fa	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998902357007	t	f	f	f	4	0	0		2026-04-01 13:21:17.929652+00	2026-04-01 13:21:17.929652+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
eb64dfdf-d7b7-4a01-be3f-e17fd24bc982	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998933122833	t	f	f	f	2	0	0		2026-04-01 13:21:20.580266+00	2026-04-01 13:21:20.580266+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
118f2fae-6326-470b-b881-efaf14b26e22	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998939526371	t	f	f	f	2	0	0		2026-04-01 13:21:21.530099+00	2026-04-01 13:21:21.530099+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
447a6a7a-ee72-4d95-ab7e-e5b783aae080	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998973217557	t	f	f	f	2	0	0		2026-04-01 13:21:22.058951+00	2026-04-01 13:21:22.058951+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
b92a912e-22c7-4891-b234-8dac2827ecd9	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998970101424	t	f	f	f	2	0	0		2026-04-01 13:21:22.541264+00	2026-04-01 13:21:22.541264+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
de90df2d-9ef8-4bca-8131-7cfaa6f6caba	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998991368971	t	f	f	f	2	0	0		2026-04-01 13:21:23.115056+00	2026-04-01 13:21:23.115056+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
21f19bd1-bca0-45db-a155-75d765af2786	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998995884058	t	f	f	f	4	0	0		2026-04-01 13:21:24.059804+00	2026-04-01 13:21:24.059804+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
44b1704c-b878-46c1-83f8-8937889db55e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998943790717	t	f	f	f	2	0	0		2026-04-01 13:21:24.639684+00	2026-04-01 13:21:24.639684+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
65b7c2b8-a311-47b1-8c4d-8d7d869d1a21	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998991854186	t	f	f	f	2	0	0		2026-04-01 13:21:25.164008+00	2026-04-01 13:21:25.164008+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
d154bb0c-26a9-4e4a-9a40-971a68e13173	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998933130990	t	f	f	f	4	0	0		2026-04-01 13:21:25.653297+00	2026-04-01 13:21:25.653297+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
55ca171a-b9b8-420a-8f4a-19b5306c409d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998906657871	t	f	f	f	2	0	0		2026-04-01 13:21:26.135776+00	2026-04-01 13:21:26.135776+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
ac4623b9-ad79-4087-8e92-63ded56976e3	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998914389274	t	f	f	f	3	0	0		2026-04-01 13:21:26.625764+00	2026-04-01 13:21:26.625764+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
8a8d1269-8d62-4078-92a0-d0ac19fb5d4e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998883690111	t	f	f	f	2	0	0		2026-04-01 13:21:27.077813+00	2026-04-01 13:21:27.077813+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
112513da-e1af-4c2f-95cf-1f6a68dd6425	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998933113152	t	f	f	f	2	0	0		2026-04-01 13:21:27.534513+00	2026-04-01 13:21:27.534513+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
9cf6d0ed-fb4f-4b52-9dc4-25da86b56199	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998995715700	t	f	f	f	2	0	0		2026-04-01 13:21:28.498191+00	2026-04-01 13:21:28.498191+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
28325cd6-06de-4841-ae7d-287464f942b4	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998508506844	t	f	f	f	2	0	0		2026-04-01 13:21:15.535409+00	2026-04-01 13:21:15.535409+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
079d669d-9b0f-4aba-afe5-380327c971b5	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913359403	t	f	f	f	2	0	0		2026-04-01 13:21:29.435765+00	2026-04-01 13:21:29.435765+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
1b972fb8-fa53-4a64-969c-8678fa5feb2e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913317557	t	f	f	f	1	0	0		2026-04-01 13:21:29.961814+00	2026-04-01 13:21:29.961814+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
6f183e75-2176-43fc-800e-b2da8a2c3638	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998950467878	t	f	f	f	2	0	0		2026-04-01 13:21:31.001934+00	2026-04-01 13:21:31.001934+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
942aacc3-4169-45bb-ba0c-c22eb2def4fb	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998936543236	t	f	f	f	2	0	0		2026-04-01 13:21:31.491496+00	2026-04-01 13:21:31.491496+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
55b6eaa0-50cb-4512-848c-5978f185627b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998993373137	t	f	f	f	2	0	0		2026-04-01 13:21:32.4577+00	2026-04-01 13:21:32.4577+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
15f6fa84-f26d-4182-9777-2c752fb0f246	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998996643432	t	f	f	f	2	0	0		2026-04-01 13:21:32.938521+00	2026-04-01 13:21:32.938521+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
eeaa80c6-a19c-4221-ad36-b8f8b06a5468	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998931560062	t	f	f	f	3	0	0		2026-04-01 13:21:33.483345+00	2026-04-01 13:21:33.483345+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
0196a9d5-edce-44b4-817c-f10ce2de8578	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998902350086	t	f	f	f	2	0	0		2026-04-01 13:21:28.961528+00	2026-04-01 13:21:28.961528+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
0fa6090e-f94f-480e-a531-f3a07cfef9c7	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913365010	t	f	f	f	2	0	0		2026-04-01 13:21:34.442271+00	2026-04-01 13:21:34.442271+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
9e4bffa7-784f-4851-b67b-e481d097938e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998976688585	t	f	f	f	2	0	0		2026-04-01 13:21:34.95469+00	2026-04-01 13:21:34.95469+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
0c4c1a62-27eb-461b-aafc-81632a56ff9b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998906655903	t	f	f	f	2	0	0		2026-04-01 13:21:35.436484+00	2026-04-01 13:21:35.436484+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
d731f460-65a4-49e6-b0cc-0014ea7e3209	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998999640401	t	f	f	f	1	0	0		2026-04-01 13:21:41.644827+00	2026-04-01 13:21:41.644827+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
e14dd724-9279-4919-b4cd-79a68027b446	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998944884448	t	f	f	f	2	0	0		2026-04-01 13:21:42.125796+00	2026-04-01 13:21:42.125796+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
fe921da0-ca5e-4e72-81b9-8aded65931ec	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998999439314	t	f	f	f	2	0	0		2026-04-01 13:21:42.629362+00	2026-04-01 13:21:42.629362+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
2d0446f1-c6ec-49ed-a13b-cc0ce4049546	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913388288	t	f	f	f	2	0	0		2026-04-01 13:21:43.642075+00	2026-04-01 13:21:43.642075+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
d2bad280-9f5b-4bed-ab71-7025c7afd48d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998942206868	t	f	f	f	2	0	0		2026-04-01 13:21:45.130133+00	2026-04-01 13:21:45.130133+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
f2cea031-fc1a-4d5c-a3fe-df5f19037c11	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998883669955	t	f	f	f	2	0	0		2026-04-01 13:21:45.586163+00	2026-04-01 13:21:45.586163+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
116d350a-1539-4741-afdb-b8ddf40c663f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998906475454	t	f	f	f	2	0	0		2026-04-01 13:21:46.03955+00	2026-04-01 13:21:46.03955+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
c60c0ac9-976d-495e-b9b9-758fdbef2b54	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913325664	t	f	f	f	2	0	0		2026-04-01 13:21:46.975987+00	2026-04-01 13:21:46.975987+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
73536d83-6fad-49f2-a5b7-d00ce05c6dfe	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998997522733	t	f	f	f	2	0	0		2026-04-01 13:21:47.425216+00	2026-04-01 13:21:47.425216+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
57f6ef56-813d-42d2-9cee-de7a2a4faaa1	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998934329315	t	f	f	f	3	0	0		2026-04-01 13:21:47.872785+00	2026-04-01 13:21:47.872785+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
ef8e194d-2237-452a-8b34-0c08d66be80a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998933166752	t	f	f	f	3	0	0		2026-04-01 13:21:48.350592+00	2026-04-01 13:21:48.350592+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
370712f0-47ec-4e2d-bb80-2529d067763b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913381103	t	f	f	f	2	0	0		2026-04-01 13:21:48.811709+00	2026-04-01 13:21:48.811709+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
1eadd5b4-4690-4fb6-a6dd-97c061e30bb3	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998906466886	t	f	f	f	2	0	0		2026-04-01 13:21:49.278182+00	2026-04-01 13:21:49.278182+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
eaaec47f-bf8a-4e12-829d-d2a555d7581b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998999431468	t	f	f	f	2	0	0		2026-04-01 13:21:49.715061+00	2026-04-01 13:21:49.715061+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
f38f3dc1-1998-495a-be02-b4061434813f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913352328	t	f	f	f	2	0	0		2026-04-01 13:21:50.235196+00	2026-04-01 13:21:50.235196+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
c6da8349-4efb-459d-adf5-f17eb524284e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998939530676	t	f	f	f	2	0	0		2026-04-01 13:21:51.673394+00	2026-04-01 13:21:51.673394+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
26df62c0-a73f-4eff-a713-06ececfe9534	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998973777577	t	f	f	f	2	0	0		2026-04-01 13:21:52.173508+00	2026-04-01 13:21:52.173508+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
96ab8ef8-45e2-47b0-93b8-98aeb9388312	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998942540508	t	f	f	f	2	0	0		2026-04-01 13:21:53.183855+00	2026-04-01 13:21:53.183855+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
b353e0a9-bcda-4a30-8577-027e25a33436	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998930819912	t	f	f	f	2	0	0		2026-04-01 13:21:53.754063+00	2026-04-01 13:21:53.754063+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
f7e14876-6244-4ba7-a5a3-208ff72abf05	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998997418307	t	f	f	f	2	0	0		2026-04-01 13:21:54.683176+00	2026-04-01 13:21:54.683176+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
8c31180f-f6ed-4686-ba87-eb3cbed41501	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998933126795	t	f	f	f	2	0	0		2026-04-01 13:21:55.717579+00	2026-04-01 13:21:55.717579+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
76f96b25-ca53-4502-8b90-3d6414f9565a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998942297700	t	f	f	f	2	0	0		2026-04-01 13:21:56.221001+00	2026-04-01 13:21:56.221001+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
6aab9cfb-23de-4416-9c59-af3dfb7023a5	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998934319199	t	f	f	f	2	0	0		2026-04-01 13:21:56.848763+00	2026-04-01 13:21:56.848763+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
629c8afa-e1c3-4c64-8343-e56fda1baefe	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913331120	t	f	f	f	2	0	0		2026-04-01 13:21:57.340699+00	2026-04-01 13:21:57.340699+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
dad173a5-e674-4b37-a437-318732d781d0	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998912511811	t	f	f	f	3	0	0		2026-04-01 13:21:57.814993+00	2026-04-01 13:21:57.814993+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
6d972a50-9b74-47bd-ad64-f7ed1e4bac54	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998792235045	t	f	f	f	2	0	0		2026-04-01 13:22:03.170936+00	2026-04-01 13:22:03.170936+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
401d7919-4442-4a7f-8fb4-2ddcbb865ca4	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998792251319	t	f	f	f	2	0	0		2026-04-01 13:21:58.858108+00	2026-04-01 13:21:58.858108+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
b67dda6f-20ff-432b-b66b-1ca13cbcd79c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913091620	t	f	f	f	1	0	0		2026-04-01 13:21:59.351777+00	2026-04-01 13:21:59.351777+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
0023dc32-3463-4fa3-bba0-d304996dd52c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998905009000	t	f	f	f	1	0	0		2026-04-01 13:21:59.830545+00	2026-04-01 13:21:59.830545+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
c36d897b-6cb6-40dd-a91f-29483b126bce	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998938007555	t	f	f	f	4	0	0		2026-04-01 13:22:00.491003+00	2026-04-01 13:22:00.491003+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
2194520d-48bd-4b54-8d44-ed8524a2ea03	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998972833535	t	f	f	f	2	0	0		2026-04-01 13:22:01.013214+00	2026-04-01 13:22:01.013214+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
13a40732-4e81-402d-adc4-e42b07e60bd5	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998906651530	t	f	f	f	5	0	0		2026-04-01 13:22:01.545942+00	2026-04-01 13:22:01.545942+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
88017df6-bcec-4e4f-8546-508f7d5f6ac6	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913354845	t	f	f	f	4	0	0		2026-04-01 13:22:02.531621+00	2026-04-01 13:22:02.531621+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
89e6fe3e-a124-46a3-aa8a-270ae266a467	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998973228817	t	f	f	f	5	0	0		2026-04-01 13:21:58.286627+00	2026-04-01 13:21:58.286627+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
655aa5f4-747b-4dd6-bd3a-b1ff881a8510	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998882976767	t	f	f	f	2	0	0		2026-04-01 13:22:05.370817+00	2026-04-01 13:22:05.370817+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
12e9fb7b-84d6-4981-86d4-9fb34d251813	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998977967740	t	f	f	f	1	0	0		2026-04-01 13:22:05.881918+00	2026-04-01 13:22:05.881918+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
70fb25d1-49d5-43af-9e9f-1dfd902c58e7	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998882288771	t	f	f	f	3	0	0		2026-04-01 13:22:06.36765+00	2026-04-01 13:22:06.36765+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
b3e4f637-e658-4f41-aa1a-cef3ee16553a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998905019739	t	f	f	f	3	0	0		2026-04-01 13:22:06.83313+00	2026-04-01 13:22:06.83313+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
29b01617-9bd0-4f56-b04d-67408a6070cd	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998912500906	t	f	f	f	2	0	0		2026-04-01 13:22:07.373287+00	2026-04-01 13:22:07.373287+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
5909a90b-e2dd-44ca-aa95-c19627bbe129	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998934343672	t	f	f	f	2	0	0		2026-04-01 13:22:08.302347+00	2026-04-01 13:22:08.302347+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
828c0885-e02c-4176-a7a2-f8c8c12a4b32	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913397947	t	f	f	f	2	0	0		2026-04-01 13:22:08.728059+00	2026-04-01 13:22:08.728059+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
09a672d5-719d-45e7-a0a1-cbee6412eb73	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998906463029	t	f	f	f	2	0	0		2026-04-01 13:22:09.276054+00	2026-04-01 13:22:09.276054+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
669ac255-7553-482e-bcd8-86104b1f6fe5	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998936092764	t	f	f	f	2	0	0		2026-04-01 13:22:09.919491+00	2026-04-01 13:22:09.919491+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
eefdfa8a-5885-49fd-92fa-3f6884c75280	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998907310109	t	f	f	f	2	0	0		2026-04-01 13:22:10.431165+00	2026-04-01 13:22:10.431165+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
6f2b4a32-65cf-4266-b9fa-f114b563c5ee	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998993475775	t	f	f	f	3	0	0		2026-04-01 13:22:10.923497+00	2026-04-01 13:22:10.923497+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
6288540e-82f1-46b6-beea-7f7b06cfd8fb	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998973789100	t	f	f	f	2	0	0		2026-04-01 13:21:52.67299+00	2026-04-01 13:21:52.67299+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
7005f02a-3e53-480c-96e3-dd4c4c9e7576	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998884430801	t	f	f	f	2	0	0		2026-04-01 13:22:11.847341+00	2026-04-01 13:22:11.847341+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
0693be1f-52c7-45bf-9e10-c1debca6f4f4	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998882978888	t	f	f	f	3	0	0		2026-04-01 13:22:12.30905+00	2026-04-01 13:22:12.30905+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
3ef746c0-7d84-4ae4-b96f-8075712cc289	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913383940	t	f	f	f	2	0	0		2026-04-01 13:22:11.39093+00	2026-04-01 13:22:11.39093+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
0e50c0e6-2286-495a-af54-bfb87cecd206	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913372001	t	f	f	f	2	0	0		2026-04-01 13:22:13.32398+00	2026-04-01 13:22:13.32398+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
8014db7c-2e1b-47d4-b157-133d087d8d04	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998973681405	t	f	f	f	4	0	0		2026-04-01 13:22:13.752372+00	2026-04-01 13:22:13.752372+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
054a05c8-8f3b-4310-96bc-c22e4a4320db	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998907301817	t	f	f	f	4	0	0		2026-04-01 13:22:14.709628+00	2026-04-01 13:22:14.709628+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
4864a9a0-6e78-4830-9110-a87d05c4f76c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998970860012	t	f	f	f	2	0	0		2026-04-01 13:22:15.265304+00	2026-04-01 13:22:15.265304+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
4856aa55-635b-4629-b9be-8416fe8b55b4	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998994360429	t	f	f	f	2	0	0		2026-04-01 13:22:15.745745+00	2026-04-01 13:22:15.745745+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
28baade2-0677-4325-a8a4-855f755c97a1	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913360463	t	f	f	f	3	0	0		2026-04-01 13:22:16.327985+00	2026-04-01 13:22:16.327985+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
36ad7e9d-14b8-4256-af6b-2bc5cb6dbcf4	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913085683	t	f	f	f	2	0	0		2026-04-01 13:22:16.809064+00	2026-04-01 13:22:16.809064+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
aacace3e-bf1c-45d0-bcff-ac072e954d54	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998936128180	t	f	f	f	1	0	0		2026-04-01 13:22:17.839391+00	2026-04-01 13:22:17.839391+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
b5c64dfd-469c-48f4-aa76-c816e510b808	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998772003003	t	f	f	f	2	0	0		2026-04-01 13:22:18.356389+00	2026-04-01 13:22:18.356389+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
c6a521a8-6ead-43cf-b818-a188944ea116	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998918512099	t	f	f	f	2	0	0		2026-04-01 13:22:18.818053+00	2026-04-01 13:22:18.818053+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
0a2a7b0e-df6c-4500-81b4-c968e4008c00	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998906659102	t	f	f	f	2	0	0		2026-04-01 13:22:19.883043+00	2026-04-01 13:22:19.883043+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
bc048a73-43fc-4eb7-bc5d-bde264914012	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998975787068	t	f	f	f	2	0	0		2026-04-01 13:22:20.485966+00	2026-04-01 13:22:20.485966+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
d13d6ef1-e4b5-4c59-96a6-656ad9a15e13	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998900868818	t	f	f	f	3	0	0		2026-04-01 13:22:21.023599+00	2026-04-01 13:22:21.023599+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
01624890-732d-456d-8ef4-a4c82dada7bc	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998919247650	t	f	f	f	1	0	0		2026-04-01 13:22:21.543959+00	2026-04-01 13:22:21.543959+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
fa5a27f3-6337-4eed-9700-2940307f317d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998930851949	t	f	f	f	2	0	0		2026-04-01 13:22:22.562218+00	2026-04-01 13:22:22.562218+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
90cb9a80-2fa4-44df-bc2e-c1e4ec5ab6f8	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998975581698	t	f	f	f	2	0	0		2026-04-01 13:22:23.041081+00	2026-04-01 13:22:23.041081+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
538c31d0-c7b9-41aa-a341-565f65b3c34d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998792242113	t	f	f	f	2	0	0		2026-04-01 13:22:23.546732+00	2026-04-01 13:22:23.546732+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
3073bc1f-2160-49ac-bb5b-3674c2366113	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913341000	t	f	f	f	3	0	0		2026-04-01 13:22:24.0072+00	2026-04-01 13:22:24.0072+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
215b3e7d-3398-42c1-a416-7591a435105c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998937732516	t	f	f	f	2	0	0		2026-04-01 13:22:24.526589+00	2026-04-01 13:22:24.526589+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
6ee3bfbf-6540-4e5b-8263-b965e01aea3c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998994150170	t	f	f	f	3	0	0		2026-04-01 13:22:25.026556+00	2026-04-01 13:22:25.026556+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
2656a520-f666-4a3b-8464-730c3924f694	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998919866766	t	f	f	f	2	0	0		2026-04-01 13:22:25.514797+00	2026-04-01 13:22:25.514797+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
7566520f-0917-4bac-826f-538e7c603a66	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998907173726	t	f	f	f	4	0	0		2026-04-01 13:22:26.102678+00	2026-04-01 13:22:26.102678+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
8eea2a8a-92eb-491e-a558-04f7eac78cb4	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998932219122	t	f	f	f	2	0	0		2026-04-01 13:22:26.57901+00	2026-04-01 13:22:26.57901+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
4dbf9dda-9608-45b2-80bc-b89caf3cbc22	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913345759	t	f	f	f	2	0	0		2026-04-01 13:22:27.052446+00	2026-04-01 13:22:27.052446+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
0f1e04cf-a859-4fe4-b793-af2f3b92e624	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998930851284	t	f	f	f	2	0	0		2026-04-01 13:22:27.543063+00	2026-04-01 13:22:27.543063+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
5b9da1ff-d4ed-4deb-93c8-73e718ea6262	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998936128529	t	f	f	f	4	0	0		2026-04-01 13:22:28.063913+00	2026-04-01 13:22:28.063913+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
f929df47-afba-4b72-9a62-5a372a8c04ca	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998972227532	t	f	f	f	1	0	0		2026-04-01 13:22:29.083347+00	2026-04-01 13:22:29.083347+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
474fd354-a6e8-49a7-9bc3-699f4695b155	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998906121114	t	f	f	f	3	0	0		2026-04-01 13:22:29.678477+00	2026-04-01 13:22:29.678477+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
bbb9e653-efa2-483e-ba3a-2e75cc022489	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998907394800	t	f	f	f	2	0	0		2026-04-01 13:22:30.163367+00	2026-04-01 13:22:30.163367+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
916eb90b-c545-47b1-8dd6-3667a87ca5be	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913345520	t	f	f	f	2	0	0		2026-04-01 13:22:30.633933+00	2026-04-01 13:22:30.633933+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
471eead6-b1c4-4e68-b68e-2e1fb5fd3b76	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998955458989	t	f	f	f	2	0	0		2026-04-01 13:22:31.243339+00	2026-04-01 13:22:31.243339+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
fab46f07-d860-4c70-a32d-b84e9f6ed13c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998902357201	t	f	f	f	2	0	0		2026-04-01 13:22:35.093191+00	2026-04-01 13:22:35.093191+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
3288fa37-9f75-4d43-92d8-7c7eff5736de	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998997772828	t	f	f	f	3	0	0		2026-04-01 13:22:35.539302+00	2026-04-01 13:22:35.539302+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
3ee471ba-4889-4d51-8987-161961bb8500	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998907314359	t	f	f	f	2	0	0		2026-04-01 13:22:35.982459+00	2026-04-01 13:22:35.982459+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
53d8f0f8-4225-4821-97f6-34865f03105c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998907307377	t	f	f	f	3	0	0		2026-04-01 13:22:36.489329+00	2026-04-01 13:22:36.489329+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
b19eef0b-8b34-4fd1-af37-848b15305173	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998933111113	t	f	f	f	5	0	0		2026-04-01 13:22:36.989671+00	2026-04-01 13:22:36.989671+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
31edeb90-48e3-4515-ae86-809c9bd444ee	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998934383833	t	f	f	f	1	0	0		2026-04-01 13:22:37.465177+00	2026-04-01 13:22:37.465177+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
d5ec1631-daeb-47c1-b87c-7b72529bf1b4	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998934393733	t	f	f	f	2	0	0		2026-04-01 13:22:37.93578+00	2026-04-01 13:22:37.93578+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
244ae957-1182-4f6f-964d-d9080bad2ebd	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913350743	t	f	f	f	2	0	0		2026-04-01 13:22:38.410859+00	2026-04-01 13:22:38.410859+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
e61c8caf-1391-4864-a880-e6b667c58709	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998792239768	t	f	f	f	3	0	0		2026-04-01 13:22:39.401199+00	2026-04-01 13:22:39.401199+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
02438bb5-4312-49af-bb9a-786e87bd5378	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998940850552	t	f	f	f	2	0	0		2026-04-01 13:22:39.980238+00	2026-04-01 13:22:39.980238+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
037cb998-e247-44fb-bf8c-a3b5401731a3	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998936626664	t	f	f	f	3	0	0		2026-04-01 13:22:43.350399+00	2026-04-01 13:22:43.350399+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
7c9adbad-d6e2-445a-bfe1-a62e5f684298	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998507670923	t	f	f	f	2	0	0		2026-04-01 13:22:41.776632+00	2026-04-01 13:22:41.776632+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
9cf55705-d56b-48a4-8b52-def37c42e258	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998906653480	t	f	f	f	2	0	0		2026-04-01 13:22:42.779831+00	2026-04-01 13:22:42.779831+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
c3179273-2f26-4942-9f83-d49fe722b777	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998994159897	t	f	f	f	2	0	0		2026-04-01 13:22:28.574514+00	2026-04-01 13:22:28.574514+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
994cc689-85c4-48c7-b3ec-7570fa843c4d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998906460259	t	f	f	f	2	0	0		2026-04-01 13:22:43.781981+00	2026-04-01 13:22:43.781981+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
6cd013b8-9fb3-46bf-828c-e3e124ab98b5	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998973778338	t	f	f	f	5	0	0		2026-04-01 13:22:44.286542+00	2026-04-01 13:22:44.286542+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
c9802412-7dc3-4bea-8414-66e4a90a3501	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998936606829	t	f	f	f	3	0	0		2026-04-01 13:22:44.824734+00	2026-04-01 13:22:44.824734+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
856e43ae-9ab1-43ec-bbfd-dc3af8a3cd07	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998907326268	t	f	f	f	2	0	0		2026-04-01 13:22:45.356784+00	2026-04-01 13:22:45.356784+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
d633304c-b412-4405-82b6-c7d9dd255051	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998906200966	t	f	f	f	2	0	0		2026-04-01 13:22:45.782305+00	2026-04-01 13:22:45.782305+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
b1a56ecf-ae1e-407f-ab9a-7c1eb4ccacaf	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998904659095	t	f	f	f	2	0	0		2026-04-01 13:22:46.231976+00	2026-04-01 13:22:46.231976+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
5196e352-6adc-4d67-a874-a4841e190fb2	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913391600	t	f	f	f	2	0	0		2026-04-01 13:22:40.587214+00	2026-04-01 13:22:40.587214+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
0d732736-5ed5-41e3-8ecd-0fe12ba1c332	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998936641103	t	f	f	f	3	0	0		2026-04-01 13:22:47.831538+00	2026-04-01 13:22:47.831538+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
d50dc5f6-e580-4770-a6da-64c71884b47b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913340450	t	f	f	f	2	0	0		2026-04-01 13:22:57.891334+00	2026-04-01 13:22:57.891334+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
2b9b72fe-42db-47c7-9f99-5789111d7bb4	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998906650935	t	f	f	f	2	0	0		2026-04-01 13:22:48.883758+00	2026-04-01 13:22:48.883758+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
462ad9a1-741c-4611-863c-e0f40c1ddb55	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998880687575	t	f	f	f	5	0	0		2026-04-01 13:22:49.381803+00	2026-04-01 13:22:49.381803+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
c9f74a2b-35c1-4e4f-aea0-7a193172b9e2	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913306424	t	f	f	f	2	0	0		2026-04-01 13:22:49.853807+00	2026-04-01 13:22:49.853807+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
11691e0d-9d7d-4ef6-aca7-bd7428707cdd	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998990742096	t	f	f	f	2	0	0		2026-04-01 13:22:50.424977+00	2026-04-01 13:22:50.424977+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
f2d3dfc0-2d80-4c5d-b0a6-4a6edb7d8709	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998500108353	t	f	f	f	2	0	0		2026-04-01 13:22:50.894025+00	2026-04-01 13:22:50.894025+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
e4ae1513-c3e2-46ea-a7d2-df582481c061	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998909769922	t	f	f	f	2	0	0		2026-04-01 13:22:52.433027+00	2026-04-01 13:22:52.433027+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
ad0381e1-72af-4d92-b1dc-f6cf4edbd436	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998972288028	t	f	f	f	2	0	0		2026-04-01 13:22:52.888676+00	2026-04-01 13:22:52.888676+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
48d76ef0-494a-42a0-8218-2511ca80d223	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998910850807	t	f	f	f	2	0	0		2026-04-01 13:22:53.911845+00	2026-04-01 13:22:53.911845+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
3343ee4d-a8f0-406b-8238-65b46f78d194	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913083090	t	f	f	f	2	0	0		2026-04-01 13:22:54.404543+00	2026-04-01 13:22:54.404543+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
61be5be5-f2f0-4499-b77a-225865150ea1	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998770228365	t	f	f	f	4	0	0		2026-04-01 13:22:55.070691+00	2026-04-01 13:22:55.070691+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
d9c2ea5d-2866-44d3-97be-2fc633758138	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998939960299	t	f	f	f	2	0	0		2026-04-01 13:22:55.612444+00	2026-04-01 13:22:55.612444+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
95cbab60-8481-459c-bb7c-cb98d0130878	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998977966005	t	f	f	f	2	0	0		2026-04-01 13:22:56.125964+00	2026-04-01 13:22:56.125964+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
4ad71fa0-463f-4d08-bca9-43dbaedebf41	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998933121108	t	f	f	f	2	0	0		2026-04-01 13:22:56.620458+00	2026-04-01 13:22:56.620458+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
db9565ea-a1d3-45d3-a932-f2eab274aff7	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998945497292	t	f	f	f	4	0	0		2026-04-01 13:22:48.308266+00	2026-04-01 13:22:48.308266+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
f2c77a94-d7ca-465e-a773-89d901e5849b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998906474330	t	f	f	f	3	0	0		2026-04-01 13:22:58.990994+00	2026-04-01 13:22:58.990994+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
8ab10e51-5916-4461-b6a1-8d2b3f1ed89c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998930537043	t	f	f	f	3	0	0		2026-04-01 13:22:59.505277+00	2026-04-01 13:22:59.505277+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
6c83e5ef-423e-4248-b9d5-ab49af47ef40	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913308586	t	f	f	f	2	0	0		2026-04-01 13:23:02.201045+00	2026-04-01 13:23:02.201045+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
89837f6e-c92e-49c6-a4b7-744a8916ada8	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998900856885	t	f	f	f	3	0	0		2026-04-01 13:23:02.633621+00	2026-04-01 13:23:02.633621+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
f6b12263-ef39-43d2-9233-745caf77e2c0	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998934606989	t	f	f	f	2	0	0		2026-04-01 13:23:03.61124+00	2026-04-01 13:23:03.61124+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
f958cdba-80f5-49f1-a33a-5110bafaf2d2	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998907313833	t	f	f	f	2	0	0		2026-04-01 13:23:04.070304+00	2026-04-01 13:23:04.070304+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
920fd145-bfe8-4608-b9da-fd8be86c513b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998907315915	t	f	f	f	2	0	0		2026-04-01 13:23:04.992076+00	2026-04-01 13:23:04.992076+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
075e3a76-1e42-4dc2-8bc3-4fed2f86aef3	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998973681440	t	f	f	f	2	0	0		2026-04-01 13:23:05.604221+00	2026-04-01 13:23:05.604221+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
606eb0d3-0727-4219-b232-7bf37ec31aad	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913378881	t	f	f	f	1	0	0		2026-04-01 13:23:06.669264+00	2026-04-01 13:23:06.669264+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
eac385b6-b8cc-4baf-97af-0098e5a88a9c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998934646867	t	f	f	f	2	0	0		2026-04-01 13:23:07.227994+00	2026-04-01 13:23:07.227994+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
e3b613ab-fb0e-4c78-9098-c658a93d8821	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998973662226	t	f	f	f	1	0	0		2026-04-01 13:23:07.740655+00	2026-04-01 13:23:07.740655+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
7dcd8087-b88c-4a98-a7c8-ebd16eda0ce5	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998973212722	t	f	f	f	2	0	0		2026-04-01 13:23:08.276325+00	2026-04-01 13:23:08.276325+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
d7b3e917-a68f-40cd-8b97-cafbc267b4d3	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998919919100	t	f	f	f	2	0	0		2026-04-01 13:23:11.110382+00	2026-04-01 13:23:11.110382+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
e2840844-e4f9-4788-bd6c-14fc015f8af8	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998996629433	t	f	f	f	2	0	0		2026-04-01 13:23:09.279471+00	2026-04-01 13:23:09.279471+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
e44fb511-a1a5-487d-9ffa-1dc68c5e79dd	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998907300102	t	f	f	f	5	0	0		2026-04-01 13:23:09.802257+00	2026-04-01 13:23:09.802257+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
d5da9baa-4f4d-4b0d-8a88-bb71c915008f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998973229019	t	f	f	f	4	0	0		2026-04-01 13:23:10.279015+00	2026-04-01 13:23:10.279015+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
f84c46b6-4773-4613-9bb0-9baab4b0b67d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998977972424	t	f	f	f	2	0	0		2026-04-01 13:23:08.755209+00	2026-04-01 13:23:08.755209+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
6cd0a008-4cd8-4a27-9284-b21d624380a8	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998934386833	t	f	f	f	2	0	0		2026-04-01 13:23:11.575112+00	2026-04-01 13:23:11.575112+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
420cb719-fe40-4f70-9396-48b875c0b323	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998973670308	t	f	f	f	2	0	0		2026-04-01 13:23:12.036744+00	2026-04-01 13:23:12.036744+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
73ed9b63-6212-4d33-86b3-7f3cad4b8857	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998973209163	t	f	f	f	3	0	0		2026-04-01 13:23:12.546712+00	2026-04-01 13:23:12.546712+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
66549d8b-6809-4a31-b0c4-d2a5fd47fcc1	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998941461929	t	f	f	f	2	0	0		2026-04-01 13:23:13.031069+00	2026-04-01 13:23:13.031069+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
37aa4d28-0cec-4f62-a7fe-1095f5b0ef2e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998933190502	t	f	f	f	2	0	0		2026-04-01 13:23:13.477846+00	2026-04-01 13:23:13.477846+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
fd8dbcdf-4933-45dc-b7b3-cc60329e65c8	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998907310083	t	f	f	f	2	0	0		2026-04-01 13:23:13.932556+00	2026-04-01 13:23:13.932556+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
b6d3d7bb-fbfa-4676-8e3b-30f7a4019e2a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998973201380	t	f	f	f	2	0	0		2026-04-01 13:23:14.391095+00	2026-04-01 13:23:14.391095+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
24b589d3-f9ff-42b4-80e3-bd366fa1659b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998907399379	t	f	f	f	2	0	0		2026-04-01 13:23:14.852293+00	2026-04-01 13:23:14.852293+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
df3d153e-3d76-40fb-8eca-81fab0b3ce37	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998994121096	t	f	f	f	3	0	0		2026-04-01 13:23:15.342761+00	2026-04-01 13:23:15.342761+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
210ef789-7b1d-4f56-a9a5-1f7932103fda	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998906190290	t	f	f	f	2	0	0		2026-04-01 13:23:17.385144+00	2026-04-01 13:23:17.385144+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
e988bc4d-48f9-44cb-ad6a-ea46c12317ff	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998941561090	t	f	f	f	2	0	0		2026-04-01 13:23:16.305342+00	2026-04-01 13:23:16.305342+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
064b7ed9-a807-47f1-b1c1-42ed5a362a60	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998930640630	t	f	f	f	2	0	0		2026-04-01 13:23:17.812805+00	2026-04-01 13:23:17.812805+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
b9d4db45-8429-4683-ba3d-9e2a9cdfc6ac	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998936613986	t	f	f	f	2	0	0		2026-04-01 13:23:18.256065+00	2026-04-01 13:23:18.256065+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
a35e5df0-5b60-4231-a316-618e071f2858	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998978525006	t	f	f	f	2	0	0		2026-04-01 13:23:18.724939+00	2026-04-01 13:23:18.724939+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
6f227f12-b472-41ae-be21-686e9903e785	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998973681873	t	f	f	f	2	0	0		2026-04-01 13:23:19.238273+00	2026-04-01 13:23:19.238273+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
8dbd2b4e-0fea-4fc9-9d9a-646f50cc68a2	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998900865888	t	f	f	f	3	0	0		2026-04-01 13:23:19.742991+00	2026-04-01 13:23:19.742991+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
9484423c-94e4-44cf-9e0a-089055166311	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913378680	t	f	f	f	3	0	0		2026-04-01 13:23:20.22893+00	2026-04-01 13:23:20.22893+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
2b92548c-4535-46b8-86a2-355696800f04	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913346046	t	f	f	f	2	0	0		2026-04-01 13:23:20.683478+00	2026-04-01 13:23:20.683478+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
ad31e76a-60ce-4f41-8948-9ea84941c62a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998906191978	t	f	f	f	1	0	0		2026-04-01 13:23:03.125357+00	2026-04-01 13:23:03.125357+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
f98fcdc0-4882-41b6-bbdb-a5ea99aeb035	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998997491793	t	f	f	f	2	0	0		2026-04-01 13:23:21.682113+00	2026-04-01 13:23:21.682113+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
436f3dfb-e72f-46ee-876f-bebc8bf11e24	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998997555456	t	f	f	f	2	0	0		2026-04-01 13:23:22.31626+00	2026-04-01 13:23:22.31626+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
ec532b90-2517-4259-81f6-cdb31b38fafb	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998975581100	t	f	f	f	3	0	0		2026-04-01 13:23:23.344656+00	2026-04-01 13:23:23.344656+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
39ba6d40-eaf6-486c-b7a2-a5e2468d738b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998770008477	t	f	f	f	3	0	0		2026-04-01 13:23:23.859961+00	2026-04-01 13:23:23.859961+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
4a97f34b-ed04-4574-8a2b-0c21ed34b92e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998972285658	t	f	f	f	3	0	0		2026-04-01 13:23:24.374368+00	2026-04-01 13:23:24.374368+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
d1565c8d-22e6-4769-adb5-3d4dd3df969f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998914380088	t	f	f	f	3	0	0		2026-04-01 13:23:25.420176+00	2026-04-01 13:23:25.420176+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
fbb5915f-92e5-470b-8076-08825a8a12d6	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998943678778	t	f	f	f	3	0	0		2026-04-01 13:23:26.379982+00	2026-04-01 13:23:26.379982+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
08e72f13-0e55-409d-947e-c81d0d0f2449	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998934612800	t	f	f	f	3	0	0		2026-04-01 13:23:26.814479+00	2026-04-01 13:23:26.814479+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
f55c58e7-ca39-4caa-98fd-3a18d7b41ad0	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998900063066	t	f	f	f	2	0	0		2026-04-01 13:23:27.304631+00	2026-04-01 13:23:27.304631+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
c23d2a8f-8307-4bdc-a875-04fa03665516	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913375613	t	f	f	f	2	0	0		2026-04-01 13:23:30.856591+00	2026-04-01 13:23:30.856591+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
edc79e78-357e-4aa6-b75d-cc751f125e15	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998934365860	t	f	f	f	2	0	0		2026-04-01 13:23:31.407138+00	2026-04-01 13:23:31.407138+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
dbe46c91-5482-457d-a82c-2f5fa970096e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913399499	t	f	f	f	6	0	0		2026-04-01 13:23:31.870124+00	2026-04-01 13:23:31.870124+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
66e116f9-9a9e-4295-bf86-31dadd6dadd6	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998993315430	t	f	f	f	5	0	0		2026-04-01 13:23:32.362973+00	2026-04-01 13:23:32.362973+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
072efbab-73a9-49b7-a1d3-b1160e32ce1f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998934635775	t	f	f	f	1	0	0		2026-04-01 13:23:32.89138+00	2026-04-01 13:23:32.89138+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
e1b7f1f9-ab03-4d82-8a02-9fa66d98da49	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998934354848	t	f	f	f	2	0	0		2026-04-01 13:23:33.386961+00	2026-04-01 13:23:33.386961+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
eab5efa6-9e7f-411c-b577-bf0253f9d7a5	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998936630510	t	f	f	f	2	0	0		2026-04-01 13:23:33.827084+00	2026-04-01 13:23:33.827084+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
bbe2fa89-9888-4597-a17f-500c02c7ca2e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998952128668	t	f	f	f	3	0	0		2026-04-01 13:23:34.270056+00	2026-04-01 13:23:34.270056+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
106c0098-ea6f-4b5a-adbb-666b77cd8ecc	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998939506670	t	f	f	f	2	0	0		2026-04-01 13:23:34.759758+00	2026-04-01 13:23:34.759758+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
2e1d0c49-8ce0-4a3e-8430-da6c7136655f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998973223151	t	f	f	f	2	0	0		2026-04-01 13:23:35.282232+00	2026-04-01 13:23:35.282232+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
499527a8-60ac-4ff3-b32d-383fcbe32c37	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998934370770	t	f	f	f	2	0	0		2026-04-01 13:23:35.740335+00	2026-04-01 13:23:35.740335+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
df2d183b-e661-4f5c-8e90-0ad0115b2a8c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998936648180	t	f	f	f	2	0	0		2026-04-01 13:23:36.223509+00	2026-04-01 13:23:36.223509+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
f5ab7458-4c32-47a2-8812-b13c9ee5347d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998977978122	t	f	f	f	3	0	0		2026-04-01 13:23:36.909098+00	2026-04-01 13:23:36.909098+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
cb8f365b-c1f3-48a8-a1cc-6da09d7af357	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913340616	t	f	f	f	1	0	0		2026-04-01 13:23:37.383137+00	2026-04-01 13:23:37.383137+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
3569b818-5989-49da-bc06-acb7d3a05b93	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998502525583	t	f	f	f	3	0	0		2026-04-01 13:23:37.899117+00	2026-04-01 13:23:37.899117+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
55661e0d-4686-4af0-8092-78803fb66646	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913097719	t	f	f	f	2	0	0		2026-04-01 13:23:38.369452+00	2026-04-01 13:23:38.369452+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
c99e232a-f998-4da1-9a2e-cc3912f74375	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998997587707	t	f	f	f	2	0	0		2026-04-01 13:23:38.816242+00	2026-04-01 13:23:38.816242+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
06fb3c2b-382b-4ef5-84f6-137e43ccf2a8	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913094275	t	f	f	f	5	0	0		2026-04-01 13:23:39.318923+00	2026-04-01 13:23:39.318923+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
0250f1d0-04dd-4c97-9f58-0d4d7d58eb22	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998973783331	t	f	f	f	2	0	0		2026-04-01 13:23:39.866658+00	2026-04-01 13:23:39.866658+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
53861b78-13c1-4f29-8fc0-2e243c38976c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913336961	t	f	f	f	5	0	0		2026-04-01 13:23:40.347444+00	2026-04-01 13:23:40.347444+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
3871ee1c-1e8d-4288-a7a6-c15462a21057	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998977973300	t	f	f	f	3	0	0		2026-04-01 13:23:40.791626+00	2026-04-01 13:23:40.791626+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
72b4157d-29c8-480a-a057-9ff3aef65c33	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998903373353	t	f	f	f	2	0	0		2026-04-01 13:23:41.365196+00	2026-04-01 13:23:41.365196+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
3b273c06-b5a3-4bdd-8c96-9c42c717cad8	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998933108781	t	f	f	f	2	0	0		2026-04-01 13:23:41.877505+00	2026-04-01 13:23:41.877505+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
b73afcfe-156a-4fe2-93d8-d88c3cae7dbb	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998992388421	t	f	f	f	3	0	0		2026-04-01 13:23:42.837039+00	2026-04-01 13:23:42.837039+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
e04f45a1-ac80-484e-8388-6101c2f47822	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998930850882	t	f	f	f	2	0	0		2026-04-01 13:23:43.378564+00	2026-04-01 13:23:43.378564+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
e4ec6ecf-0e00-41fe-abba-efad1364382c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998919864565	t	f	f	f	1	0	0		2026-04-01 13:23:44.31456+00	2026-04-01 13:23:44.31456+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
61579bf4-beb4-418d-b45c-307ee6561067	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998973776062	t	f	f	f	2	0	0		2026-04-01 13:23:44.806161+00	2026-04-01 13:23:44.806161+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
aee67132-c499-4e26-ba27-00d9dec1a6e6	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998905001557	t	f	f	f	2	0	0		2026-04-01 13:23:45.807007+00	2026-04-01 13:23:45.807007+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
444069bd-e6f0-4984-9e5d-05444bb22424	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998930889400	t	f	f	f	2	0	0		2026-04-01 13:23:46.293762+00	2026-04-01 13:23:46.293762+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
8149fbcb-f47f-43d3-af4d-b5a3e4c3aaee	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998942271101	t	f	f	f	2	0	0		2026-04-01 13:23:46.795078+00	2026-04-01 13:23:46.795078+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
f15a6fd0-95fc-4dbc-9e10-979a72807259	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998934648151	t	f	f	f	2	0	0		2026-04-01 13:23:47.274615+00	2026-04-01 13:23:47.274615+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
f72897a2-d084-458c-88eb-d7506ffab2ef	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998936593438	t	f	f	f	2	0	0		2026-04-01 13:23:48.224901+00	2026-04-01 13:23:48.224901+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
7f6d242c-ee4a-4630-bbdf-3345a3c49453	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998907322550	t	f	f	f	3	0	0		2026-04-01 13:23:48.658186+00	2026-04-01 13:23:48.658186+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
63ac14b0-5479-493e-ba55-6fbbc1812783	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913362133	t	f	f	f	2	0	0		2026-04-01 13:23:49.601718+00	2026-04-01 13:23:49.601718+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
23fd2107-93aa-4f58-b67d-2be09d07699b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998993959910	t	f	f	f	2	0	0		2026-04-01 13:23:50.130078+00	2026-04-01 13:23:50.130078+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
cd103036-321e-4f79-9b1c-da0486312e17	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998973798700	t	f	f	f	2	0	0		2026-04-01 13:23:50.634779+00	2026-04-01 13:23:50.634779+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
b3afc62a-5e6a-4756-9f95-4970ecfc8455	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998933388880	t	f	f	f	3	0	0		2026-04-01 13:23:51.151533+00	2026-04-01 13:23:51.151533+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
a5f6a0de-f886-438d-9644-0edb63a3a62c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998936626447	t	f	f	f	2	0	0		2026-04-01 13:23:51.617997+00	2026-04-01 13:23:51.617997+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
898578c3-7965-4fc3-af5e-fa53c0354e82	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913377331	t	f	f	f	4	0	0		2026-04-01 13:23:52.147865+00	2026-04-01 13:23:52.147865+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
e3d53f9c-4972-4dc7-be99-e1eed6175b63	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998977957776	t	f	f	f	3	0	0		2026-04-01 13:23:52.630779+00	2026-04-01 13:23:52.630779+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
54a5e554-1a95-46cf-99db-96a96e6f55a7	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998907395188	t	f	f	f	3	0	0		2026-04-01 13:23:53.16237+00	2026-04-01 13:23:53.16237+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
debf7984-3143-4531-959a-988ed16ff245	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998973682927	t	f	f	f	4	0	0		2026-04-01 13:23:53.678796+00	2026-04-01 13:23:53.678796+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
9c992e40-103e-4f42-90a5-ea9b29007b61	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998939506162	t	f	f	f	14	0	0		2026-04-01 13:23:22.847587+00	2026-04-01 13:23:22.847587+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
5d00144e-227f-42be-9cda-5a2d3e957912	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998942575957	t	f	f	f	2	0	0		2026-04-01 13:23:54.676735+00	2026-04-01 13:23:54.676735+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
1a85b3f4-61ca-43c1-8ea1-d5b1bed2de04	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998792239818	t	f	f	f	2	0	0		2026-04-01 13:23:57.353839+00	2026-04-01 13:23:57.353839+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
a9dbcf31-12dd-499e-881b-c3b5854f56ba	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998934396226	t	f	f	f	2	0	0		2026-04-01 13:23:57.793662+00	2026-04-01 13:23:57.793662+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
261b3526-f134-47d7-8616-81e353fc5a6f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998934346268	t	f	f	f	2	0	0		2026-04-01 13:23:58.298895+00	2026-04-01 13:23:58.298895+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
d20b38a3-fa4f-43f9-b1e6-b238e242352c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998900850406	t	f	f	f	2	0	0		2026-04-01 13:23:58.782183+00	2026-04-01 13:23:58.782183+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
ad0815af-f3ae-4455-8088-078246b4ab7b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913327800	t	f	f	f	2	0	0		2026-04-01 13:23:59.215612+00	2026-04-01 13:23:59.215612+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
93d5734f-f91d-40bb-a845-80960edee28f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913099458	t	f	f	f	2	0	0		2026-04-01 13:23:59.646936+00	2026-04-01 13:23:59.646936+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
99e3b206-f7f4-4c1f-a57b-9e2cfd9f9daf	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998906181811	t	f	f	f	2	0	0		2026-04-01 13:24:00.642723+00	2026-04-01 13:24:00.642723+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
d9f78b84-d676-42fc-b06f-d4d6c718f427	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998991633361	t	f	f	f	2	0	0		2026-04-01 13:24:01.191389+00	2026-04-01 13:24:01.191389+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
edcce916-4eb7-4244-b293-6854fa7d7ac5	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998998625077	t	f	f	f	2	0	0		2026-04-01 13:24:02.498191+00	2026-04-01 13:24:02.498191+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
b26b3dbe-5199-4d52-9750-851be763e3e7	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998902330009	t	f	f	f	2	0	0		2026-04-01 13:24:01.822004+00	2026-04-01 13:24:01.822004+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
b9d1d0a2-3b34-4489-9061-dbeec668917d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998906468695	t	f	f	f	2	0	0		2026-04-01 13:24:02.960945+00	2026-04-01 13:24:02.960945+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
7f261050-e655-4667-b06a-fd01f64dfcd3	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998933182707	t	f	f	f	2	0	0		2026-04-01 13:24:03.960306+00	2026-04-01 13:24:03.960306+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
91f773c7-98a2-4d8f-b838-95ef7ca79566	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998912513739	t	f	f	f	2	0	0		2026-04-01 13:24:04.428935+00	2026-04-01 13:24:04.428935+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
301812aa-f04d-4862-bfb5-8c9a596f4ba2	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998933113373	t	f	f	f	6	0	0		2026-04-01 13:24:04.892801+00	2026-04-01 13:24:04.892801+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
a3ea5b21-4772-4fb9-bff7-f14e0956d4f3	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998971678484	t	f	f	f	5	0	0		2026-04-01 13:24:05.36327+00	2026-04-01 13:24:05.36327+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
03b998c3-6769-4a9b-8236-1fb0a8948653	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998900859755	t	f	f	f	4	0	0		2026-04-01 13:24:05.801977+00	2026-04-01 13:24:05.801977+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
c4875fa6-7606-4a4d-b4fa-35a20c3338ec	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998997507708	t	f	f	f	3	0	0		2026-04-01 13:24:06.272918+00	2026-04-01 13:24:06.272918+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
3ef9fe7c-13c0-4738-8767-d412f82d6070	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998912508818	t	f	f	f	5	0	0		2026-04-01 13:24:06.713034+00	2026-04-01 13:24:06.713034+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
aa7c942a-5ea7-4220-a794-464ff98165b5	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998902340061	t	f	f	f	2	0	0		2026-04-01 13:24:07.222819+00	2026-04-01 13:24:07.222819+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
bac3d156-22a6-49e6-bd0f-73fbef06fbe3	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998934680006	t	f	f	f	2	0	0		2026-04-01 13:24:07.726062+00	2026-04-01 13:24:07.726062+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
4a13cbcd-98df-4c88-bbf9-900443b45149	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998997565571	t	f	f	f	2	0	0		2026-04-01 13:24:08.286612+00	2026-04-01 13:24:08.286612+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
2ac26eb9-db0f-47fa-971f-6421418e4697	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998973201316	t	f	f	f	2	0	0		2026-04-01 13:24:08.857468+00	2026-04-01 13:24:08.857468+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
4a233dde-0e31-4086-8549-dbcd2890f34d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998507116622	t	f	f	f	2	0	0		2026-04-01 13:24:09.389841+00	2026-04-01 13:24:09.389841+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
79fd5b33-33b4-458f-9555-e8fc8121b649	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998972283139	t	f	f	f	2	0	0		2026-04-01 13:24:09.97042+00	2026-04-01 13:24:09.97042+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
44556f24-f520-447b-9668-ca65ed851cdd	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998977967799	t	f	f	f	2	0	0		2026-04-01 13:24:10.461912+00	2026-04-01 13:24:10.461912+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
12c8c269-4002-416d-814c-b9ff748bb68c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998994169276	t	f	f	f	2	0	0		2026-04-01 13:24:11.530469+00	2026-04-01 13:24:11.530469+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
a841f652-72be-413c-88fc-e8dc7327ad79	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998906651626	t	f	f	f	2	0	0		2026-04-01 13:24:12.221558+00	2026-04-01 13:24:12.221558+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
3ed89eb6-3754-438c-b75f-f455a042facb	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998931631637	t	f	f	f	3	0	0		2026-04-01 13:24:12.734342+00	2026-04-01 13:24:12.734342+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
a29253e4-a94d-4347-bfee-c1e9b105aac0	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998995828412	t	f	f	f	2	0	0		2026-04-01 13:24:13.680778+00	2026-04-01 13:24:13.680778+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
4fb6d6f3-a459-47a2-9fbf-74d1ed8e28cb	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998943747922	t	f	f	f	2	0	0		2026-04-01 13:24:14.232703+00	2026-04-01 13:24:14.232703+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
003cc1f1-ad96-4426-b4a9-ea38241740cb	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998939245853	t	f	f	f	2	0	0		2026-04-01 13:24:14.701164+00	2026-04-01 13:24:14.701164+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
f9a7fb04-0196-4c92-b095-6e7392430210	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998939504045	t	f	f	f	3	0	0		2026-04-01 13:24:15.233616+00	2026-04-01 13:24:15.233616+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
1e202b44-c623-4b5f-9c6d-6c6ad53c381a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998940084980	t	f	f	f	2	0	0		2026-04-01 13:24:15.700945+00	2026-04-01 13:24:15.700945+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
209926fe-8695-47e0-9994-be764d4f4dad	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998992403060	t	f	f	f	2	0	0		2026-04-01 13:24:16.262099+00	2026-04-01 13:24:16.262099+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
544923ab-3af5-41fa-9477-28acdd5fc9fd	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998997174066	t	f	f	f	2	0	0		2026-04-01 13:24:16.750947+00	2026-04-01 13:24:16.750947+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
f897790b-3e06-4ea4-b8dd-d16035b4d8eb	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998936699275	t	f	f	f	2	0	0		2026-04-01 13:24:17.214704+00	2026-04-01 13:24:17.214704+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
6efe7f33-ec96-42b1-90ba-8aecfe06d9d4	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913335453	t	f	f	f	21	0	0		2026-04-01 13:24:17.870403+00	2026-04-01 13:24:17.870403+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
b501e78a-4044-4be3-87b3-941af8fcd82d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998940433303	t	f	f	f	3	0	0		2026-04-01 13:24:18.291863+00	2026-04-01 13:24:18.291863+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
b415f473-adc1-4d4c-ac74-17f8d0594873	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998902358066	t	f	f	f	3	0	0		2026-04-01 13:24:19.311925+00	2026-04-01 13:24:19.311925+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
7a8b9715-c10b-4aff-afac-550ccae2a9a5	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913399235	t	f	f	f	5	0	0		2026-04-01 13:24:20.279876+00	2026-04-01 13:24:20.279876+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
4b42e6f8-de09-450c-b13d-5a30907bc2e3	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998905005219	t	f	f	f	5	0	0		2026-04-01 13:24:20.735664+00	2026-04-01 13:24:20.735664+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
a9ac3aba-3099-4166-9a45-e8f5ee619aee	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913362609	t	f	f	f	6	0	0		2026-04-01 13:24:21.711095+00	2026-04-01 13:24:21.711095+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
6022233f-5295-4e75-a2b8-a40ab1e31c8d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998907390268	t	f	f	f	2	0	0		2026-04-01 13:24:22.184019+00	2026-04-01 13:24:22.184019+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
7bb79e53-4e60-4bce-9d41-7fa887e5e760	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998939505030	t	f	f	f	3	0	0		2026-04-01 13:24:22.660519+00	2026-04-01 13:24:22.660519+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
bc9a4815-3777-4959-a6e7-1f393463bf07	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998919881615	t	f	f	f	2	0	0		2026-04-01 13:24:25.20408+00	2026-04-01 13:24:25.20408+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
04bde6c0-5018-4d97-a636-5d7671f4f736	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998932120298	t	f	f	f	3	0	0		2026-04-01 13:24:25.660313+00	2026-04-01 13:24:25.660313+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
45183256-1265-490d-8ec9-094db721d0dc	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998993999903	t	f	f	f	6	0	0		2026-04-01 13:24:26.114126+00	2026-04-01 13:24:26.114126+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
f8f3f5db-9d6c-4cc3-932d-6c7f74dc4c2f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998792207000	t	f	f	f	3	0	0		2026-04-01 13:24:26.542143+00	2026-04-01 13:24:26.542143+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
6fc404fc-81bd-4fbb-bd05-afa36d2a7229	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913373514	t	f	f	f	3	0	0		2026-04-01 13:24:26.96825+00	2026-04-01 13:24:26.96825+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
f50ee6a9-b1a7-4980-bb45-79dc00fa6bf9	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998906652026	t	f	f	f	3	0	0		2026-04-01 13:24:27.427463+00	2026-04-01 13:24:27.427463+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
8561c9d5-576b-4ce8-9f0d-b24091c8a953	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998905014888	t	f	f	f	4	0	0		2026-04-01 13:24:03.45935+00	2026-04-01 13:24:03.45935+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
3ec2c733-fcae-4212-94d9-c0f3971c50ad	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998905012828	t	f	f	f	2	0	0		2026-04-01 13:24:28.373262+00	2026-04-01 13:24:28.373262+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
2290367a-1612-486c-9c89-12695914b909	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998972880083	t	f	f	f	2	0	0		2026-04-01 13:24:28.818118+00	2026-04-01 13:24:28.818118+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
2a34aafa-aaa5-4ebf-b331-a2c438607a4c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998944850123	t	f	f	f	3	0	0		2026-04-01 13:24:29.344446+00	2026-04-01 13:24:29.344446+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
d486645a-67dd-4300-964e-b0b031ad3a19	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998934383332	t	f	f	f	2	0	0		2026-04-01 13:24:30.361941+00	2026-04-01 13:24:30.361941+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
2b704768-d7f9-4eda-9ec1-7a4f261e7d93	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998933119082	t	f	f	f	4	0	0		2026-04-01 13:24:31.35298+00	2026-04-01 13:24:31.35298+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
3f4fea26-ae3a-4554-99f4-071e55124f2e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998977972028	t	f	f	f	2	0	0		2026-04-01 13:24:31.796583+00	2026-04-01 13:24:31.796583+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
477ac103-024b-40ce-826c-b81777aabbd3	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998943760555	t	f	f	f	6	0	0		2026-04-01 13:24:32.297216+00	2026-04-01 13:24:32.297216+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
b2fdf877-50b4-4c2e-854c-0ec0880c49ab	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998770743300	t	f	f	f	5	0	0		2026-04-01 13:24:33.300711+00	2026-04-01 13:24:33.300711+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
6340f5d9-c977-4ab1-9885-4f3f0a3fbb7c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998936616636	t	f	f	f	3	0	0		2026-04-01 13:24:34.194119+00	2026-04-01 13:24:34.194119+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
4a766f0f-29f3-40f5-b37e-62b728c203c5	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998933158953	t	f	f	f	2	0	0		2026-04-01 13:24:34.668428+00	2026-04-01 13:24:34.668428+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
92f61f46-b859-415b-baa9-4bec87a3f21d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998936648760	t	f	f	f	4	0	0		2026-04-01 13:24:35.139976+00	2026-04-01 13:24:35.139976+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
8f1fab06-3273-40a0-8301-18887f770f12	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998990107909	t	f	f	f	5	0	0		2026-04-01 13:24:35.610973+00	2026-04-01 13:24:35.610973+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
fa5d4ea3-63ec-4dee-af23-d9425bc5e449	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998933153918	t	f	f	f	2	0	0		2026-04-01 13:24:36.066768+00	2026-04-01 13:24:36.066768+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
147e0489-1efc-4c98-a9ee-20633cefe5cb	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998906657876	t	f	f	f	4	0	0		2026-04-01 13:24:36.52393+00	2026-04-01 13:24:36.52393+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
661ff2ec-2b79-4620-8853-9cd9055d7af7	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998971971009	t	f	f	f	3	0	0		2026-04-01 13:24:36.985701+00	2026-04-01 13:24:36.985701+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
1081f144-218f-41e6-a28e-4b7686e429e4	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913370057	t	f	f	f	2	0	0		2026-04-01 13:24:37.565666+00	2026-04-01 13:24:37.565666+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
41e2e791-e6bf-4df7-8be4-61f9a4c44e60	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998939508828	t	f	f	f	2	0	0		2026-04-01 13:24:38.045198+00	2026-04-01 13:24:38.045198+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
0ccecc9c-3e23-4ef3-a897-861d289f62c9	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998942291777	t	f	f	f	5	0	0		2026-04-01 13:24:38.543211+00	2026-04-01 13:24:38.543211+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
19a4ee72-6578-4e49-8e65-b1fbd5c1835f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998947567000	t	f	f	f	4	0	0		2026-04-01 13:24:38.981075+00	2026-04-01 13:24:38.981075+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
d9ff1b3d-0093-46a6-8921-ed4dfc250a00	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998973203500	t	f	f	f	4	0	0		2026-04-01 13:24:40.09701+00	2026-04-01 13:24:40.09701+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
30acff12-02aa-4d13-bc2f-845c3375a68e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998994457317	t	f	f	f	4	0	0		2026-04-01 13:24:40.593091+00	2026-04-01 13:24:40.593091+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
d3aa5020-704a-432a-83ed-f8ff92a088bc	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998934355823	t	f	f	f	5	0	0		2026-04-01 13:24:41.101834+00	2026-04-01 13:24:41.101834+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
4965bb0d-1b64-4f68-a0ba-622dc3625816	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998907178919	t	f	f	f	2	0	0		2026-04-01 13:24:41.661057+00	2026-04-01 13:24:41.661057+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
24851f68-c232-48a4-bac8-16480f740b04	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998905004346	t	f	f	f	2	0	0		2026-04-01 13:24:42.839134+00	2026-04-01 13:24:42.839134+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
fb739ef5-6857-405e-803b-be80de7a5ceb	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913350086	t	f	f	f	3	0	0		2026-04-01 13:24:42.168963+00	2026-04-01 13:24:42.168963+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
d74010e7-e71b-477c-a34d-c31fa046dc84	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913387076	t	f	f	f	2	0	0		2026-04-01 13:24:43.552859+00	2026-04-01 13:24:43.552859+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
15faeee7-7963-4081-92d7-ecc4bfd0b7a8	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998331690493	t	f	f	f	3	0	0		2026-04-01 13:24:44.035234+00	2026-04-01 13:24:44.035234+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
9e769539-1f71-4d65-9ce9-c2d9128c3ff5	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998993303638	t	f	f	f	2	0	0		2026-04-01 13:24:46.799115+00	2026-04-01 13:24:46.799115+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
5ae5bcb5-1998-4489-a804-32205d3522d4	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913359753	t	f	f	f	3	0	0		2026-04-01 13:24:45.094064+00	2026-04-01 13:24:45.094064+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
1ed50ffd-d3bd-4082-a831-77f5402adde4	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998930540944	t	f	f	f	2	0	0		2026-04-01 13:24:45.610178+00	2026-04-01 13:24:45.610178+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
91ccd181-dd45-444e-94d3-baea58e6ab8e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998914390111	t	f	f	f	5	0	0		2026-04-01 13:24:46.107249+00	2026-04-01 13:24:46.107249+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
1ceb4b86-a900-4227-bedd-bd09fff066c0	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998906658385	t	f	f	f	2	0	0		2026-04-01 13:24:44.55436+00	2026-04-01 13:24:44.55436+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
a700bef1-b65b-4c50-b909-f56c81c49d1a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913396361	t	f	f	f	3	0	0		2026-04-01 13:24:47.334241+00	2026-04-01 13:24:47.334241+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
ea04dc5c-a088-4c9e-8d79-21625fe59dc8	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913377157	t	f	f	f	2	0	0		2026-04-01 13:24:47.796484+00	2026-04-01 13:24:47.796484+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
d09f4527-4938-4c36-b543-85f13208d56a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998905000787	t	f	f	f	4	0	0		2026-04-01 13:24:48.302792+00	2026-04-01 13:24:48.302792+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
13ab0ccf-d75a-43de-aa11-4ea627ddc52e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998907393200	t	f	f	f	2	0	0		2026-04-01 13:24:48.793448+00	2026-04-01 13:24:48.793448+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
b5ae0c60-4b00-4ea1-96e0-356175b7b7e9	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913340611	t	f	f	f	2	0	0		2026-04-01 13:24:49.350731+00	2026-04-01 13:24:49.350731+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
95920c3b-7a97-4c5d-9554-18803bb585f8	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998935473100	t	f	f	f	4	0	0		2026-04-01 13:24:50.050464+00	2026-04-01 13:24:50.050464+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
54720f4b-248a-4093-a71e-37dbbfde4f6f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998946321775	t	f	f	f	1	0	0		2026-04-01 13:24:50.541078+00	2026-04-01 13:24:50.541078+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
2bc3c5d4-b742-4bb3-9158-d19b73c7acf3	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998997513038	t	f	f	f	2	0	0		2026-04-01 13:24:51.571417+00	2026-04-01 13:24:51.571417+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
181d868f-f755-4410-b306-6464d45122b4	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913350412	t	f	f	f	4	0	0		2026-04-01 13:24:52.068612+00	2026-04-01 13:24:52.068612+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
ad91bc56-95e2-42a0-93af-e73d009762c3	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998906659326	t	f	f	f	4	0	0		2026-04-01 13:24:52.520126+00	2026-04-01 13:24:52.520126+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
0f2c1388-e768-480b-8273-605e3d941e23	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913302222	t	f	f	f	3	0	0		2026-04-01 13:24:52.965459+00	2026-04-01 13:24:52.965459+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
f9244e5d-0aea-4b1f-a885-a5c5ebd2fce9	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998933177488	t	f	f	f	3	0	0		2026-04-01 13:24:54.006981+00	2026-04-01 13:24:54.006981+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
a51e6fd9-c501-46ef-84cb-1d0116e701cc	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998500088202	t	f	f	f	1	0	0		2026-04-01 13:24:54.496387+00	2026-04-01 13:24:54.496387+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
596ebc0e-f791-4f02-b832-e6803572d40d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998973686100	t	f	f	f	4	0	0		2026-04-01 13:24:55.205099+00	2026-04-01 13:24:55.205099+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
a3115180-2fac-43a2-8f9a-1af1f7197ee2	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998991857173	t	f	f	f	2	0	0		2026-04-01 13:24:55.693439+00	2026-04-01 13:24:55.693439+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
21617674-8198-4d2d-83a1-d1be3e4d2bdd	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998990614226	t	f	f	f	5	0	0		2026-04-01 13:24:56.235407+00	2026-04-01 13:24:56.235407+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
a2f66d78-1d31-49ce-b523-e4560e8c0f37	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998973221343	t	f	f	f	2	0	0		2026-04-01 13:24:56.744807+00	2026-04-01 13:24:56.744807+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
8e8bf47d-99c1-4010-8c0d-50e6ce584497	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998907174555	t	f	f	f	4	0	0		2026-04-01 13:24:57.704588+00	2026-04-01 13:24:57.704588+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
7e3cec7f-36ae-4aa7-8bdf-fd0d9a394c96	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998912488757	t	f	f	f	4	0	0		2026-04-01 13:24:58.156713+00	2026-04-01 13:24:58.156713+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
8d54ad74-36ce-43da-97ef-8472d2e24779	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998901500276	t	f	f	f	2	0	0		2026-04-01 13:24:58.698183+00	2026-04-01 13:24:58.698183+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
d1ce2f03-0679-4177-b431-b2df0a131bae	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998936623839	t	f	f	f	1	0	0		2026-04-01 13:24:59.962507+00	2026-04-01 13:24:59.962507+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
3dd1ae5e-7ec5-45f2-9195-861732d82329	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998907305840	t	f	f	f	2	0	0		2026-04-01 13:25:00.507315+00	2026-04-01 13:25:00.507315+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
a6702838-8531-49d1-9319-44b0b36d801d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998770850322	t	f	f	f	2	0	0		2026-04-01 13:25:01.001179+00	2026-04-01 13:25:01.001179+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
2c2b2d91-1dbf-4e95-9c9a-2c1df30ae396	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998944884010	t	f	f	f	2	0	0		2026-04-01 13:25:01.541869+00	2026-04-01 13:25:01.541869+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
6aa785b3-e1ea-47b0-94bc-0f1b83d1c736	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998940190045	t	f	f	f	2	0	0		2026-04-01 13:25:02.047075+00	2026-04-01 13:25:02.047075+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
53370087-9c36-4f2e-8208-1a541f547cb5	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998999604742	t	f	f	f	2	0	0		2026-04-01 13:25:02.506659+00	2026-04-01 13:25:02.506659+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
83cad9c4-1abe-417b-88c3-fbbeae03a500	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913391407	t	f	f	f	2	0	0		2026-04-01 13:25:02.979156+00	2026-04-01 13:25:02.979156+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
6d44d8d7-8b2e-4b47-9759-29bd28bdbe99	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913340820	t	f	f	f	3	0	0		2026-04-01 13:25:03.990142+00	2026-04-01 13:25:03.990142+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
3d7a8d38-1dec-4972-9969-da4a0c1e06f5	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998937730041	t	f	f	f	3	0	0		2026-04-01 13:25:04.476864+00	2026-04-01 13:25:04.476864+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
b9698bb9-df94-401d-b8fe-ae781cab118a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913345504	t	f	f	f	2	0	0		2026-04-01 13:25:04.944164+00	2026-04-01 13:25:04.944164+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
aa46a08e-dd6c-4a6d-8d13-ef72c2f10db2	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998905009298	t	f	f	f	2	0	0		2026-04-01 13:25:05.473966+00	2026-04-01 13:25:05.473966+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
82be5dd2-6baa-4fa4-a081-f73d160419cd	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998972288205	t	f	f	f	5	0	0		2026-04-01 13:25:05.930377+00	2026-04-01 13:25:05.930377+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
4bf25a7c-2c42-404c-9b86-437081001cd7	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998935229800	t	f	f	f	2	0	0		2026-04-01 13:25:06.381836+00	2026-04-01 13:25:06.381836+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
ea14e67e-7b90-474d-9816-7341d4c5ad57	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998906462181	t	f	f	f	2	0	0		2026-04-01 13:25:06.849674+00	2026-04-01 13:25:06.849674+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
87b13e1d-079a-4f5b-b84e-3f04369e4edd	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998935225758	t	f	f	f	2	0	0		2026-04-01 13:25:09.076001+00	2026-04-01 13:25:09.076001+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
955bbd70-6f96-4ecd-b581-f40ffd92c0d0	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998940821111	t	f	f	f	5	0	0		2026-04-01 13:25:07.867002+00	2026-04-01 13:25:07.867002+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
96089e5c-4ef2-4a34-9a36-6c5f16a61348	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998939530373	t	f	f	f	2	0	0		2026-04-01 13:25:08.35625+00	2026-04-01 13:25:08.35625+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
9760942a-0be5-455c-8e28-391a31e78078	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998933171930	t	f	f	f	5	0	0		2026-04-01 13:25:07.366657+00	2026-04-01 13:25:07.366657+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
77e42a02-ffda-49a8-a477-66eb41ac7464	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998905004828	t	f	f	f	2	0	0		2026-04-01 13:25:09.586253+00	2026-04-01 13:25:09.586253+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
180302dc-2922-4d38-ab55-d9413b50b305	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998951480003	t	f	f	f	4	0	0		2026-04-01 13:25:10.200598+00	2026-04-01 13:25:10.200598+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
8b2fad8d-877f-4da7-b78c-ce03239b766b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998942234555	t	f	f	f	7	0	0		2026-04-01 13:25:10.776662+00	2026-04-01 13:25:10.776662+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
c6abd21b-a1f5-4839-b001-36ea56ceba94	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998995840800	t	f	f	f	2	0	0		2026-04-01 13:25:11.358116+00	2026-04-01 13:25:11.358116+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
b67d45cc-903f-4fa2-a881-c3fb22c5c984	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998936129791	t	f	f	f	2	0	0		2026-04-01 13:25:11.855525+00	2026-04-01 13:25:11.855525+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
7444462e-085c-4137-87af-5a34f41f813b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998905015882	t	f	f	f	2	0	0		2026-04-01 13:25:12.410856+00	2026-04-01 13:25:12.410856+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
43842f42-5ec2-444f-a268-32c8f40ac4c5	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998930099980	t	f	f	f	1	0	0		2026-04-01 13:25:12.893122+00	2026-04-01 13:25:12.893122+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
1b737d3b-8740-4a57-b326-359dcf82f7db	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998933181441	t	f	f	f	2	0	0		2026-04-01 13:25:13.414982+00	2026-04-01 13:25:13.414982+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
5d6d0567-966f-426f-88c6-def59b2fd3bb	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998990310200	t	f	f	f	2	0	0		2026-04-01 13:25:13.887139+00	2026-04-01 13:25:13.887139+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
df5aac24-d8df-4127-a063-57d3e087ea38	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998997588135	t	f	f	f	3	0	0		2026-04-01 13:25:14.400153+00	2026-04-01 13:25:14.400153+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
9579eb94-c005-4c9a-8dec-951ff9c68ee2	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913353744	t	f	f	f	3	0	0		2026-04-01 13:25:14.860614+00	2026-04-01 13:25:14.860614+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
7560ce80-df95-4121-9d7f-091ebffd667a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998912504616	t	f	f	f	2	0	0		2026-04-01 13:25:15.369118+00	2026-04-01 13:25:15.369118+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
1f2d82fa-ab24-45b1-9044-9959f3eca6a5	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998940618886	t	f	f	f	2	0	0		2026-04-01 13:25:15.845837+00	2026-04-01 13:25:15.845837+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
cf695924-2fd1-4fb9-9189-522cf03b2477	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998976846633	t	f	f	f	5	0	0		2026-04-01 13:25:16.310676+00	2026-04-01 13:25:16.310676+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
ff0e6363-5dcc-4582-a1dc-79e6d11d77d2	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998936733931	t	f	f	f	4	0	0		2026-04-01 13:25:16.788628+00	2026-04-01 13:25:16.788628+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
50f377a2-0731-4230-b352-24a7b5ae18c1	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998941997773	t	f	f	f	2	0	0		2026-04-01 13:25:17.22713+00	2026-04-01 13:25:17.22713+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
9a8250f6-c56e-4817-9032-aad5c3f2d1ec	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913099966	t	f	f	f	3	0	0		2026-04-01 13:25:17.706284+00	2026-04-01 13:25:17.706284+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
7b2e88e7-951b-4913-9ad5-de95c406125f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998994571765	t	f	f	f	1	0	0		2026-04-01 13:25:18.173951+00	2026-04-01 13:25:18.173951+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
c8d5da56-efef-40fa-89c5-141b910e521c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913380705	t	f	f	f	6	0	0		2026-04-01 13:25:18.636087+00	2026-04-01 13:25:18.636087+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
9fa1c040-5bbd-4fee-9b7b-7c3767836c92	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998994124305	t	f	f	f	3	0	0		2026-04-01 13:25:21.86003+00	2026-04-01 13:25:21.86003+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
e7acbeab-2843-4861-8181-839ee95c2bea	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998909656658	t	f	f	f	2	0	0		2026-04-01 13:25:22.367375+00	2026-04-01 13:25:22.367375+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
cc43da7d-ab6f-4ac2-bec3-e75d23e14d6a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913392117	t	f	f	f	2	0	0		2026-04-01 13:25:23.379947+00	2026-04-01 13:25:23.379947+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
5e72fa52-d8af-4302-9a75-932dd359b6bd	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998934364344	t	f	f	f	4	0	0		2026-04-01 13:25:23.863376+00	2026-04-01 13:25:23.863376+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
b8572e44-1b58-4d65-a149-ea2ff82aaf47	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913099235	t	f	f	f	4	0	0		2026-04-01 13:25:24.454248+00	2026-04-01 13:25:24.454248+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
7555c4bb-71ca-4d3a-8af4-1bdb5a262992	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998500056878	t	f	f	f	1	0	0		2026-04-01 13:25:25.067203+00	2026-04-01 13:25:25.067203+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
877330b2-42f2-4ffa-8773-a0e4591eca35	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998991147650	t	f	f	f	1	0	0		2026-04-01 13:25:26.121351+00	2026-04-01 13:25:26.121351+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
8037ab97-00fc-425d-8c96-533649f2beb1	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998905004848	t	f	f	f	5	0	0		2026-04-01 13:25:26.584069+00	2026-04-01 13:25:26.584069+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
23242ca0-b4ef-46c6-8b14-881ee878f8a0	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913088767	t	f	f	f	4	0	0		2026-04-01 13:25:27.026363+00	2026-04-01 13:25:27.026363+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
974df00f-832e-48d6-9b75-b2994e91119d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998972987879	t	f	f	f	3	0	0		2026-04-01 13:25:27.479995+00	2026-04-01 13:25:27.479995+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
afa03d10-c27e-41f4-ac85-465f3eccb0c0	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998882877772	t	f	f	f	2	0	0		2026-04-01 13:25:27.926937+00	2026-04-01 13:25:27.926937+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
a991e8da-d648-4adb-922d-1db8a78bb458	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998907309090	t	f	f	f	3	0	0		2026-04-01 13:25:28.432474+00	2026-04-01 13:25:28.432474+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
b666fec3-b580-4726-a2e2-05c2e6cf708e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998936618322	t	f	f	f	2	0	0		2026-04-01 13:25:28.883708+00	2026-04-01 13:25:28.883708+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
35542ff9-fd55-4e1b-b1cd-82d044a9604e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998900882629	t	f	f	f	2	0	0		2026-04-01 13:25:29.476808+00	2026-04-01 13:25:29.476808+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
fc3d666b-7c17-4fc5-9764-1a15b350f849	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998942554747	t	f	f	f	3	0	0		2026-04-01 13:25:29.936789+00	2026-04-01 13:25:29.936789+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
c0aec8f0-97f5-4330-940d-0b0f0b7de149	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998906462771	t	f	f	f	4	0	0		2026-04-01 13:20:22.24556+00	2026-04-01 13:20:22.24556+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
0f190025-5cc3-49b5-af18-440aef8820e8	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998931570007	t	f	f	f	3	0	0		2026-04-01 13:20:25.381578+00	2026-04-01 13:20:25.381578+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
5d15d23f-6331-4b81-9c64-6f979afc377b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998997780318	t	f	f	f	4	0	0		2026-04-01 13:20:28.556598+00	2026-04-01 13:20:28.556598+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
0c2743f0-d0fd-457b-ad77-91b3f4d73822	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998977822404	t	f	f	f	2	0	0		2026-04-01 13:20:32.116092+00	2026-04-01 13:20:32.116092+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
2b570b8b-5138-40ed-885d-4cf2b12129e3	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998973780298	t	f	f	f	2	0	0		2026-04-01 13:20:33.625542+00	2026-04-01 13:20:33.625542+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
2b6a30cf-cdb7-4d72-a1a4-714d2edcc195	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998937720073	t	f	f	f	2	0	0		2026-04-01 13:20:38.685361+00	2026-04-01 13:20:38.685361+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
676e8654-63ba-42f0-9b4d-919787e6b455	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913318804	t	f	f	f	2	0	0		2026-04-01 13:20:42.280787+00	2026-04-01 13:20:42.280787+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
39546a3e-9d21-4452-8f12-26d653baa73a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998936605546	t	f	f	f	2	0	0		2026-04-01 13:20:57.193284+00	2026-04-01 13:20:57.193284+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
2dcad786-b075-4a20-b5fd-ad4ff9762775	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998995404809	t	f	f	f	4	0	0		2026-04-01 13:20:59.76675+00	2026-04-01 13:20:59.76675+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
d5054f11-a456-44b3-a5b6-97400fd59506	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998977972727	t	f	f	f	3	0	0		2026-04-01 13:21:08.400635+00	2026-04-01 13:21:08.400635+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
578e99e1-671f-4be0-9430-ba724ad36191	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998906188108	t	f	f	f	2	0	0		2026-04-01 13:21:12.39775+00	2026-04-01 13:21:12.39775+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
1adce889-24ea-42aa-b602-0e2a9ec2cd52	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998934365520	t	f	f	f	2	0	0		2026-04-01 13:21:21.035176+00	2026-04-01 13:21:21.035176+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
515cf726-3590-4981-917f-2f126d9af686	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998883230704	t	f	f	f	4	0	0		2026-04-01 13:21:23.617591+00	2026-04-01 13:21:23.617591+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
448b590a-6167-4a57-b8d6-03d7fa12c7d8	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998944853322	t	f	f	f	3	0	0		2026-04-01 13:21:30.539478+00	2026-04-01 13:21:30.539478+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
f3609d9b-0a89-473c-bfa1-d2c706cde993	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998930350738	t	f	f	f	2	0	0		2026-04-01 13:21:31.964028+00	2026-04-01 13:21:31.964028+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
582dc9d6-7fc4-460c-8141-d142d9e270de	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913310331	t	f	f	f	6	0	0		2026-04-01 13:21:44.621977+00	2026-04-01 13:21:44.621977+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
43ca17de-72fb-43c0-8e28-7c12388d078c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913386858	t	f	f	f	4	0	0		2026-04-01 13:21:46.51417+00	2026-04-01 13:21:46.51417+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
6140df26-668b-4527-a6f5-5a0ce6d968c0	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998972980093	t	f	f	f	3	0	0		2026-04-01 13:21:50.704958+00	2026-04-01 13:21:50.704958+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
fc9bc7a0-32ee-4acf-ba6b-6ef442ddca60	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998995481703	t	f	f	f	3	0	0		2026-04-01 13:21:51.17433+00	2026-04-01 13:21:51.17433+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
188288fa-615e-4616-98f2-024a6a44b81b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998900580698	t	f	f	f	2	0	0		2026-04-01 13:21:54.220005+00	2026-04-01 13:21:54.220005+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
9042e8f4-1a60-4a47-b5cc-761e7c6c6f1d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998919900680	t	f	f	f	3	0	0		2026-04-01 13:21:55.232244+00	2026-04-01 13:21:55.232244+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
fac711c4-d52a-48bb-ba20-556472b348f4	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998973675507	t	f	f	f	2	0	0		2026-04-01 13:22:02.047535+00	2026-04-01 13:22:02.047535+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
c6fece6b-d6d5-4875-9bc1-a1d4d2f64bed	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913351141	t	f	f	f	2	0	0		2026-04-01 13:22:14.247807+00	2026-04-01 13:22:14.247807+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
96bc5cf1-2527-4828-8466-844199fc6729	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998907304916	t	f	f	f	4	0	0		2026-04-01 13:22:19.353043+00	2026-04-01 13:22:19.353043+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
12315e4e-f7a1-48bc-9e9c-ceec5a0cc53f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998942285005	t	f	f	f	3	0	0		2026-04-01 13:22:22.057315+00	2026-04-01 13:22:22.057315+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
d5844533-626d-455f-9b2e-26f740822f1e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913300501	t	f	f	f	2	0	0		2026-04-01 13:22:38.831066+00	2026-04-01 13:22:38.831066+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
e08669ea-3f84-40b0-bb46-b3eb839324d1	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998980000281	t	f	f	f	3	0	0		2026-04-01 13:22:42.308323+00	2026-04-01 13:22:42.308323+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
d7d96b97-6c20-4acd-a3bd-49f7411e0c41	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998997527752	t	f	f	f	3	0	0		2026-04-01 13:22:47.344776+00	2026-04-01 13:22:47.344776+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
5bd09ba0-c2f5-4bf4-be32-1662ce724e02	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998997065777	t	f	f	f	3	0	0		2026-04-01 13:22:51.419289+00	2026-04-01 13:22:51.419289+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
4cc93c72-4bc3-41ee-96aa-522a4f2141db	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998978629111	t	f	f	f	2	0	0		2026-04-01 13:22:53.413129+00	2026-04-01 13:22:53.413129+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
234daee3-a587-465f-b961-bdc9260a300f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998992337999	t	f	f	f	2	0	0		2026-04-01 13:22:57.335639+00	2026-04-01 13:22:57.335639+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
84a5a246-17d6-4f2b-901f-96f76ba034bd	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998905017788	t	f	f	f	2	0	0		2026-04-01 13:22:58.44772+00	2026-04-01 13:22:58.44772+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
8cf3411c-dbb7-4704-90c1-88f2e937b648	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998977174228	t	f	f	f	2	0	0		2026-04-01 13:23:04.546973+00	2026-04-01 13:23:04.546973+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
d690c3e2-fde2-49bd-8a1c-c94709c7194f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998991697089	t	f	f	f	2	0	0		2026-04-01 13:23:06.144294+00	2026-04-01 13:23:06.144294+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
48e60118-7f9b-4226-be9e-6ffa93e81ea7	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998902348455	t	f	f	f	2	0	0		2026-04-01 13:23:16.767229+00	2026-04-01 13:23:16.767229+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
29f8ba53-233a-4eb7-a140-c44651b267f7	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998936607676	t	f	f	f	2	0	0		2026-04-01 13:23:24.924146+00	2026-04-01 13:23:24.924146+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
b5f93600-4a1a-4f9e-b3fa-a5a772a0239b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913343443	t	f	f	f	3	0	0		2026-04-01 13:23:29.367994+00	2026-04-01 13:23:29.367994+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
dd5a9ed0-bc8e-4be0-a3eb-a42b68ac9fb7	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998906197779	t	f	f	f	4	0	0		2026-04-01 13:23:42.375641+00	2026-04-01 13:23:42.375641+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
dc333dd2-b63a-4836-8722-378635bdf61a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998934364001	t	f	f	f	2	0	0		2026-04-01 13:23:43.834579+00	2026-04-01 13:23:43.834579+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
e5ba8d94-8740-4569-b7cd-889419a4f4c5	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998945586564	t	f	f	f	2	0	0		2026-04-01 13:23:45.312703+00	2026-04-01 13:23:45.312703+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
c39075a8-e115-4bef-a286-7347b01e0909	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913321620	t	f	f	f	5	0	0		2026-04-01 13:23:47.715417+00	2026-04-01 13:23:47.715417+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
4243e5b2-b553-42e4-b9fa-fee9b85ab5cd	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998931100844	t	f	f	f	3	0	0		2026-04-01 13:24:10.924469+00	2026-04-01 13:24:10.924469+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
3e9b3c1b-a1d3-4fb0-b2ba-7a09fb6123b2	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998884609800	t	f	f	f	3	0	0		2026-04-01 13:24:13.231292+00	2026-04-01 13:24:13.231292+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
d0bbf5af-9813-494b-9c11-0f1ae496bbcb	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998997430013	t	f	f	f	5	0	0		2026-04-01 13:25:30.938427+00	2026-04-01 13:25:30.938427+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
afeecf5d-ab45-4660-b762-fbe0fb291706	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998944830095	t	f	f	f	2	0	0		2026-04-01 13:25:31.453968+00	2026-04-01 13:25:31.453968+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
014fceb0-3aaa-4fa4-a94c-957afa784de5	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913097071	t	f	f	f	3	0	0		2026-04-01 13:25:31.87244+00	2026-04-01 13:25:31.87244+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
1ea97899-6d3a-483e-944b-00226e4a7a72	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913363837	t	f	f	f	6	0	0		2026-04-01 13:25:32.382753+00	2026-04-01 13:25:32.382753+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
650dd524-71f2-498d-bcfb-14cac4e20c25	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998936129094	t	f	f	f	3	0	0		2026-04-01 13:25:33.548441+00	2026-04-01 13:25:33.548441+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
75dc85df-f3be-4b1a-8d13-52282523651e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998934332202	t	f	f	f	3	0	0		2026-04-01 13:25:33.989954+00	2026-04-01 13:25:33.989954+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
09bddfbf-afab-4db1-84b1-66ecdafe7d7e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998933174558	t	f	f	f	4	0	0		2026-04-01 13:25:34.500547+00	2026-04-01 13:25:34.500547+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
663ac071-22af-4473-9d77-72fe476c1297	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998931486768	t	f	f	f	4	0	0		2026-04-01 13:25:34.987232+00	2026-04-01 13:25:34.987232+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
7be5fa1d-cddb-43bd-a6e1-1767bf41ad4b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998942262121	t	f	f	f	2	0	0		2026-04-01 13:25:35.483316+00	2026-04-01 13:25:35.483316+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
498ba42d-93a5-422f-a3bb-38584ccda1ba	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	Xusan	Zaripov	+998937727478	t	f	f	f	0	10000	0	\N	2026-04-01 16:09:06.828188+00	2026-04-01 16:20:45.251335+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
ea8b1a4f-4119-4984-abd4-b46a402f9790	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998931107076	t	f	f	f	5	0	0		2026-04-01 13:24:18.803938+00	2026-04-01 13:24:18.803938+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
02066572-aca7-4389-8a06-963cf9569a8b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913087989	t	f	f	f	5	0	0		2026-04-01 13:24:19.79706+00	2026-04-01 13:24:19.79706+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
f787a2ea-e303-4b7c-9128-dffc4c8f0aa7	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913311000	t	f	f	f	4	0	0		2026-04-01 13:24:29.838036+00	2026-04-01 13:24:29.838036+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
079082d0-582a-47e0-a833-1b1d54801357	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913353824	t	f	f	f	5	0	0		2026-04-01 13:24:30.82352+00	2026-04-01 13:24:30.82352+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
4a0c92ad-9f5b-4c53-801e-20c9ebcf1047	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998912520204	t	f	f	f	5	0	0		2026-04-01 13:24:33.729469+00	2026-04-01 13:24:33.729469+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
5c5c49d9-ba2f-41ae-a370-26b675e1b90c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998973681477	t	f	f	f	4	0	0		2026-04-01 13:24:39.577831+00	2026-04-01 13:24:39.577831+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
18f14b24-4f17-4e47-887f-cf79eac106c0	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998942277222	t	f	f	f	3	0	0		2026-04-01 13:24:57.230361+00	2026-04-01 13:24:57.230361+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
ce7325fc-096a-4d25-b592-f7cc58105b4b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998913345700	t	f	f	f	2	0	0		2026-04-01 13:22:41.187439+00	2026-04-01 13:22:41.187439+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
d07142d9-3ef1-4ce8-b481-75a791a78e3c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998906460892	t	f	f	f	3	0	0		2026-04-01 13:25:03.47541+00	2026-04-01 13:25:03.47541+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
ffb7f9f6-7d03-44aa-8338-4ef7066134f2	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998995764645	t	f	f	f	5	0	0		2026-04-01 13:25:22.838388+00	2026-04-01 13:25:22.838388+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
4792d0f3-9947-4de0-853b-ba1a00df7651	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998931284822	t	f	f	f	3	0	0		2026-04-01 13:25:33.025287+00	2026-04-01 13:25:33.025287+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
9da9e8ce-e37f-45f9-816e-03088a1d4cbe	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998934343618	t	f	f	f	4	0	0		2026-04-01 13:25:35.998516+00	2026-04-01 13:25:35.998516+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
87ccf651-8739-4590-bf50-0fc0dcd1805b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998991578784	t	f	f	f	2	0	0		2026-04-01 13:25:36.494776+00	2026-04-01 13:25:36.494776+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
5ed02d60-6e0b-4661-bdc7-a9ab63c95ceb	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998993303128	t	f	f	f	2	0	0		2026-04-01 13:25:36.93387+00	2026-04-01 13:25:36.93387+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
efec2a34-76d7-465f-9dee-93256478e664	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998939502122	t	f	f	f	5	0	0		2026-04-01 13:25:37.420792+00	2026-04-01 13:25:37.420792+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
ef4ba25e-fc17-41a4-877f-fa427c3f0c4f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	2	0	0		2026-04-01 17:43:55.027233+00	2026-04-01 17:43:55.027233+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
c0321a33-6996-40dd-96d5-5fa81bad2b66	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	4	0	0		2026-04-01 17:44:18.699604+00	2026-04-01 17:44:18.699604+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
42d42d5c-bcad-4007-aa91-eb904ccfdae6	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	2	0	0		2026-04-01 17:44:46.139194+00	2026-04-01 17:44:46.139194+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
901f04b8-318c-450d-b694-5f1c7fd5ab07	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	2	0	0		2026-04-01 17:45:16.659931+00	2026-04-01 17:45:16.659931+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
e48a50d0-a3a9-4265-ad9e-c2ca01d3cf10	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	0	0	0		2026-04-01 17:45:45.255375+00	2026-04-01 17:45:45.255375+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
1b916815-9712-4651-acfb-e1eb01024208	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	0	0	0		2026-04-01 17:45:59.864901+00	2026-04-01 17:45:59.864901+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
dbcac118-81e6-49e9-b5ff-ada87dbacfd5	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	2	0	0		2026-04-01 18:28:32.25562+00	2026-04-01 18:28:32.25562+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
af44cf36-cc80-4ede-8dee-101a616c847e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N		t	f	f	f	1	0	0		2026-04-01 18:28:40.527811+00	2026-04-01 18:28:40.527811+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
6938eef9-b4d5-4763-8c6d-dc0b6a71d59d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998972287784	t	f	f	f	6	0	0	Второй номер: +998906353636	2026-04-01 18:28:48.14266+00	2026-04-01 18:28:48.14266+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
3142f475-c045-44d6-8ada-355fa67fec64	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998795070097	t	f	f	f	3	0	0		2026-04-01 18:28:56.614853+00	2026-04-01 18:28:56.614853+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
8085d575-8c94-431c-8651-7ee64010bd7f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998984442484	t	f	f	f	3	0	0		2026-04-01 18:29:04.744779+00	2026-04-01 18:29:04.744779+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
15397afa-b698-4705-8c4c-f9313d700e81	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998792249271	t	f	f	f	1	0	0	Второй номер: +998918478285	2026-04-01 18:29:12.402458+00	2026-04-01 18:29:12.402458+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
8528cffb-bb42-4803-aaf4-d8b993b56058	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	-	\N	+998934314008	t	f	f	f	8	0	0		2026-04-01 18:29:20.914438+00	2026-04-01 18:29:20.914438+00	f	8b2f3db8-59bc-486a-b852-58e489fd6399
d53ae11d-54f4-47e6-91dd-e452288c5a79	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	Lomonosov 1/24	\N	+000000001	t	f	f	f	2	0	0	Dubli import (qator 86)	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
d3ca3308-46bc-4717-b89d-a93a72d33f0b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	M. Ulug'bek 15/19	\N	+000000002	t	f	f	f	2	0	0	Dubli import (qator 122)	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
9e3b23c2-e08a-4a81-9f95-955cb1e05f4d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	Tarobiy 77b/61	\N	+000000003	t	f	f	f	4	0	0	Dubli import (qator 151)	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
79401428-e8f6-4f9d-b996-d79486c5ee3e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	Karimov 47/71	\N	+000000004	t	f	f	f	2	0	0	Dubli import (qator 237)	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
5debfc92-6925-47af-a205-e9a13815f7c7	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	Karimov 92/33	\N	+000000005	t	f	f	f	5	0	0	Dubli import (qator 252)	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
8994ab0f-5d96-4dff-8441-b0921516cb43	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	Karimov 94/48*	\N	+000000006	t	f	f	f	2	0	0	Dubli import (qator 255)	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
2a23c223-436e-4c23-9c4c-9fedb014fde2	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	Shodlik 5/6	\N	+000000007	t	f	f	f	2	0	0	Dubli import (qator 351)	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
cb2046fc-9a40-48c9-9a08-a35e07877c06	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	Nurafshon 1/25	\N	+000000008	t	f	f	f	2	0	0	Dubli import (qator 355)	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
dae66baf-d688-42ad-86c0-d7290b81dabd	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	Spitamen 5/19	\N	+000000009	t	f	f	f	3	0	0	Dubli import (qator 369)	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
d3d8dc55-28e4-43de-96fa-e35a350df587	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	Qurilish 5/13	\N	+000000010	t	f	f	f	4	0	0	Dubli import (qator 374)	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
47af2c99-ee8a-4d34-a496-dc894b647b4d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	Pushkin 4a/34	\N	+000000011	t	f	f	f	2	0	0	Dubli import (qator 403)	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
5dd429b8-a125-4ee8-9e33-dbae92b8f1cc	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	Ibn Sino 43/6	\N	+000000012	t	f	f	f	2	0	0	Dubli import (qator 418)	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
0cdfa3ac-12ee-4948-bc09-70940765ba2f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	Tolstoy 21/39	\N	+000000013	t	f	f	f	2	0	0	Dubli import (qator 430)	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
4cfc5e61-f7e2-4196-bc1f-51b2ab3e2f6c	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	A.Avloniy 20/29	\N	+000000014	t	f	f	f	2	0	0	Dubli import (qator 465)	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
51328a9a-de4b-4315-9e4f-48f45ab2270b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	Galaba 141/3/26	\N	+000000015	t	f	f	f	2	0	0	Dubli import (qator 521)	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
54efd433-c25d-4584-bf35-1ec490569cf0	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	Galaba 145/23	\N	+000000016	t	f	f	f	2	0	0	Dubli import (qator 523)	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
d3c7ba95-c333-4ecc-b279-d79a5f935e54	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	Galaba 210/5	\N	+000000017	t	f	f	f	1	0	0	Dubli import (qator 545)	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
7be076ee-6acc-4abd-b4e1-7427050d57fc	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	Polik  kasaba/1, bux/4, kadr/3, nazorat/1, zamdirek/2, kotibala/1, boshhamshir/1	\N	+000000018	t	f	f	f	14	0	0	Dubli import (qator 561)	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
5bc95780-94a3-4c47-a6b2-44afbe19d6c4	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	A. Buxoriy 181	\N	+000000019	t	f	f	f	5	0	0	Dubli import (qator 576)	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
847c501c-dc35-486d-94e3-a6cefa9609ba	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	Birdamlik 33***	\N	+000000020	t	f	f	f	4	0	0	Dubli import (qator 617)	2026-04-02 12:22:45.576906+00	2026-04-02 12:22:45.576906+00	f	a6bfecf9-3d9f-4fbc-8bf8-0c3871fff8de
\.


--
-- Data for Name: container_client_balance; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.container_client_balance (id, tenant_id, client_id, balance) FROM stdin;
6c0ac2a8-4e51-4eda-8304-731f961fe118	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	498ba42d-93a5-422f-a3bb-38584ccda1ba	0
\.


--
-- Data for Name: container_transactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.container_transactions (id, tenant_id, client_id, order_id, created_by_id, transaction_type, quantity, balance_before, balance_after, note, created_at) FROM stdin;
0ef399c9-6d11-4611-aa8d-29b1572719de	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	498ba42d-93a5-422f-a3bb-38584ccda1ba	1	\N	delivered	1	0	1	\N	2026-04-01 16:20:45.251335+00
66421f01-5829-40fd-b7db-3921fd8e29bb	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	498ba42d-93a5-422f-a3bb-38584ccda1ba	1	\N	returned	1	1	0	\N	2026-04-01 16:20:45.251335+00
\.


--
-- Data for Name: courier_balance_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.courier_balance_log (id, courier_id, tenant_id, order_id, operation, full_containers_delta, empty_containers_delta, cash_delta, card_delta, payme_delta, note, created_at) FROM stdin;
b3559b3d-d59e-46be-a6f5-4011c480e947	d24959cd-6d69-454d-ae4c-147c62b612d9	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	shift_open	0	0	0	0	0	Smena ochildi. Boshlang'ich to'la tara: 0	2026-04-01 15:25:50.928465+00
c32d77fc-0a03-4921-969a-0cc4599e22da	84b8c7f4-a063-40c0-8dda-7d450d973a93	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	shift_open	0	0	0	0	0	Smena ochildi. Boshlang'ich to'la tara: 0	2026-04-01 18:38:15.840736+00
6232971c-aca7-4a80-bee4-ffbd00616082	d24959cd-6d69-454d-ae4c-147c62b612d9	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	shift_close_by_operator	0	0	0	0	0	Operator tomonidan yopildi. Farq: naqd=0, karta=0, payme=0	2026-04-07 05:05:13.607057+00
cce6dcce-9218-4ea4-a052-6412f22f0ce6	d24959cd-6d69-454d-ae4c-147c62b612d9	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	shift_open	0	0	0	0	0	Smena ochildi. Boshlang'ich to'la tara: 0	2026-04-11 15:15:03.721879+00
de5fde10-5ac0-44f7-9a98-6dccc3dc8c14	d24959cd-6d69-454d-ae4c-147c62b612d9	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	shift_close_by_operator	0	0	0	0	0	Operator tomonidan yopildi. Farq: naqd=0, karta=0, payme=0	2026-04-11 15:17:20.261635+00
\.


--
-- Data for Name: courier_cash_collections; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.courier_cash_collections (id, tenant_id, courier_id, collected_by_id, cash_amount, card_amount, payme_amount, total_amount, full_containers_returned, empty_containers_returned, orders_completed, note, collection_date) FROM stdin;
2f08f703-0735-4c5e-993b-f84b9d1849bd	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	d24959cd-6d69-454d-ae4c-147c62b612d9	b48b8100-a97f-4462-a874-3a4d8208a299	670000	0	0	670000	0	0	0		2026-04-07 05:05:13.607057+00
b468a38c-e316-47fa-9f2e-74ca29cb5882	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	d24959cd-6d69-454d-ae4c-147c62b612d9	b48b8100-a97f-4462-a874-3a4d8208a299	0	1073500	0	1073500	0	0	1		2026-04-11 15:17:20.261635+00
\.


--
-- Data for Name: courier_inventory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.courier_inventory (id, tenant_id, courier_id, product_id, quantity, updated_at) FROM stdin;
\.


--
-- Data for Name: couriers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.couriers (id, tenant_id, user_id, car_number, is_active, shift_status, shift_started_at, cash_balance, card_balance, payme_balance, full_containers, empty_containers, preferred_navigator, created_at, updated_at) FROM stdin;
84b8c7f4-a063-40c0-8dda-7d450d973a93	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	889f4fbc-04bc-44a9-8b77-125ce7f8960f	\N	t	OPEN	2026-04-01 18:38:15.84568+00	0	0	0	0	0	yandex	2026-04-01 16:43:43.666612+00	2026-04-01 18:38:15.840736+00
7b1d4956-5b89-40d2-9638-681d3c78c6bb	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	9acbe1e9-7daa-40cc-b128-70dcc1bf6793	\N	t	CLOSED	\N	0	0	0	0	0	yandex	2026-04-02 15:58:55.580081+00	2026-04-02 15:58:55.580081+00
d24959cd-6d69-454d-ae4c-147c62b612d9	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	7a4fed15-43ec-4671-99df-adc96efb7c98	\N	t	CLOSED	2026-04-11 15:15:03.727541+00	0	0	0	0	0	yandex	2026-04-01 15:17:04.886797+00	2026-04-11 15:17:20.261635+00
\.


--
-- Data for Name: debt_transactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.debt_transactions (id, tenant_id, client_id, debt_id, order_id, created_by_id, transaction_type, amount, payment_method, description, created_at) FROM stdin;
\.


--
-- Data for Name: debts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.debts (id, tenant_id, client_id, order_id, original_amount, remaining_amount, is_paid, created_at, paid_at) FROM stdin;
c3780004-549d-471b-87e9-da3607e916fd	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	498ba42d-93a5-422f-a3bb-38584ccda1ba	1	10000	10000	f	2026-04-01 16:20:45.251335+00	\N
\.


--
-- Data for Name: notifications_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notifications_log (id, tenant_id, user_id, order_id, telegram_id, message, notification_type, is_sent, error, sent_at, created_at) FROM stdin;
\.


--
-- Data for Name: operator_cash_submissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.operator_cash_submissions (id, tenant_id, operator_id, collected_by_id, cash_amount, card_amount, total_amount, note, submission_date) FROM stdin;
\.


--
-- Data for Name: order_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_items (id, order_id, product_id, tenant_id, quantity, price_at_order, total, delivered_quantity) FROM stdin;
cb517cc3-a66f-4cdb-8687-046ab7aa4e5d	1	a64ff9fa-562d-43d9-881e-f08f97db0d33	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	1	10000	10000	1
172d9645-9f36-49b5-8173-d3e0d43b4bd4	2	db2394db-8718-401b-8024-345fb7030703	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	60	7500	450000	60
ff90d6d9-31a2-42d1-abf9-3a9d157ddd58	2	cc05e7d1-dc94-430a-9c8e-22bb284a12ca	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	40	5500	220000	40
3886b6f9-9fb3-4c33-b648-c29b6a53aaba	3	db2394db-8718-401b-8024-345fb7030703	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	10	7500	75000	10
b983292b-2f2d-422e-91d1-d1cc0ddf2f43	3	cc05e7d1-dc94-430a-9c8e-22bb284a12ca	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	10	5500	55000	10
ef842787-d3e7-467a-a31e-46f1dec69313	4	db2394db-8718-401b-8024-345fb7030703	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	83	7500	622500	83
43d4a656-d2e5-4a9e-8f08-27b5e0811aad	4	cc05e7d1-dc94-430a-9c8e-22bb284a12ca	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	82	5500	451000	82
\.


--
-- Data for Name: order_status_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_status_history (id, order_id, tenant_id, status, changed_by_id, note, created_at) FROM stdin;
ebb3c02f-149a-4c3c-a5a8-05ac8dde74a7	1	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	YANGI	9acbe1e9-7daa-40cc-b128-70dcc1bf6793	\N	2026-04-01 16:15:18.659804+00
bc26e104-02aa-4f3f-a60e-e6b1e4d266b1	1	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	TAYINLANDI	9acbe1e9-7daa-40cc-b128-70dcc1bf6793	\N	2026-04-01 16:18:46.116843+00
2834e457-794c-4dfc-885b-55099deb49fb	1	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	YETKAZILDI	7a4fed15-43ec-4671-99df-adc96efb7c98	\N	2026-04-01 16:20:45.251335+00
3ad6c615-f248-4f0e-a4fb-56077acc1d63	2	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	YOLDA	7a4fed15-43ec-4671-99df-adc96efb7c98	\N	2026-04-01 20:04:46.565916+00
c2b13c4a-eecf-4d03-b95a-1c64ad995293	2	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	YETKAZILDI	7a4fed15-43ec-4671-99df-adc96efb7c98	Tez sotuv - avtomatik yakunlandi	2026-04-01 20:04:46.565916+00
1c575170-da7b-44a1-920b-2ef47fcd0bb1	3	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	YANGI	7a4fed15-43ec-4671-99df-adc96efb7c98	\N	2026-04-08 19:06:45.262443+00
499e91b8-4810-40e0-b247-a9a88c8becb6	3	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	TAYINLANDI	b48b8100-a97f-4462-a874-3a4d8208a299	\N	2026-04-08 19:07:28.26222+00
a0a07f1e-483c-4022-8955-20eee427074c	3	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	MUAMMO	7a4fed15-43ec-4671-99df-adc96efb7c98	Mijoz bekor qildi	2026-04-11 15:14:32.244941+00
94391eb5-50a2-4ed2-897f-e1c90ac68df8	4	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	YOLDA	7a4fed15-43ec-4671-99df-adc96efb7c98	\N	2026-04-11 15:16:21.67981+00
e2640c14-1e8a-4d31-a589-3be62d0a3130	4	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	YETKAZILDI	7a4fed15-43ec-4671-99df-adc96efb7c98	Tez sotuv - avtomatik yakunlandi	2026-04-11 15:16:21.67981+00
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orders (id, tenant_id, client_id, courier_id, address_id, status, payment_status, payment_method, total_amount, paid_amount, debt_amount, containers_delivered, containers_returned, comment, cancel_reason, problem_reason, is_phone_order, delivered_at, created_at, updated_at, contact_phone, cash_amount, card_amount, is_walkin, walkin_phone, walkin_address, walkin_store) FROM stdin;
1	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	498ba42d-93a5-422f-a3bb-38584ccda1ba	d24959cd-6d69-454d-ae4c-147c62b612d9	333dd9fc-ba7c-41ba-98f1-b58239410fa0	YETKAZILDI	TOLANMAGAN	QARZ	10000	0	10000	1	1	\N	\N	\N	t	2026-04-01 16:20:45.287254+00	2026-04-01 16:15:18.659804+00	2026-04-01 16:20:45.251335+00	\N	0	0	f	\N	\N	\N
2	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	d24959cd-6d69-454d-ae4c-147c62b612d9	\N	YETKAZILDI	TOLANGAN	NAQD	670000	670000	0	0	0	\N	\N	\N	f	2026-04-01 20:04:46.644561+00	2026-04-01 20:04:46.565916+00	2026-04-01 20:04:46.565916+00	\N	670000	0	t	\N	\N	\N
3	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	4ad54089-6bce-4516-bb99-e6b2ca3eef37	d24959cd-6d69-454d-ae4c-147c62b612d9	96b4eecc-461b-4ec1-9fc9-3f58dbf87744	MUAMMO	TOLANMAGAN	\N	130000	0	0	0	0	5dan keyin	\N	Mijoz bekor qildi	f	\N	2026-04-08 19:06:45.262443+00	2026-04-11 15:14:32.244941+00	90 015 77 75	0	0	f	\N	\N	\N
4	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	d24959cd-6d69-454d-ae4c-147c62b612d9	\N	YETKAZILDI	TOLANGAN	KARTA	1073500	1073500	0	0	0	\N	\N	\N	f	2026-04-11 15:16:21.739198+00	2026-04-11 15:16:21.67981+00	2026-04-11 15:16:21.67981+00	\N	0	1073500	t	+998900157775	Niz 4	Dokon
\.


--
-- Data for Name: price_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.price_history (id, product_id, tenant_id, old_price, new_price, changed_by_id, changed_at) FROM stdin;
\.


--
-- Data for Name: product_categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_categories (id, tenant_id, name, icon, sort_order, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.products (id, tenant_id, category_id, name, description, image_url, price, volume, volume_unit, is_returnable_container, is_active, sort_order, created_at, updated_at, container_product_id, containers_per_unit, inactive_threshold_days, show_to_clients, is_deleted) FROM stdin;
db2394db-8718-401b-8024-345fb7030703	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	ako 10L	\N	/uploads/products/e8a2df39-f2c8-4bf3-ba28-4aca06ead209.png	7500	10	\N	f	t	0	2026-04-01 13:45:09.658059+00	2026-04-01 15:18:13.454968+00	\N	1	30	t	f
cc05e7d1-dc94-430a-9c8e-22bb284a12ca	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	ako 5L	\N	/uploads/products/23f3a517-d317-4872-87b8-2863d4e25908.png	5500	5	\N	f	t	0	2026-04-01 13:44:46.340204+00	2026-04-01 15:18:20.679432+00	\N	1	30	t	f
a64ff9fa-562d-43d9-881e-f08f97db0d33	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	Himalay 18.9L	\N	/uploads/products/f732cd2a-7685-495f-a306-4488a64c9818.png	10000	18	\N	t	f	0	2026-04-01 15:50:11.500842+00	2026-04-02 10:00:38.426762+00	\N	1	30	f	f
111a3a1e-89cf-4640-b800-40bce6d40e88	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	ako 18.9L	\N	/uploads/products/835069da-1a73-4966-bd64-79e5c17bc410.png	15000	18	\N	t	t	0	2026-04-02 10:01:41.047766+00	2026-04-07 09:22:23.587722+00	\N	1	5	t	f
\.


--
-- Data for Name: regions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.regions (id, tenant_id, name_uz, name_uz_cyrillic, name_ru, is_active, sort_order, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.settings (id, tenant_id, company_name, logo_url, bot_token, work_start_hour, work_end_hour, inactive_client_days, extra_json) FROM stdin;
0816c898-08a7-4565-95ba-011194978b1e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	\N	\N	8	22	30	\N
\.


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tenants (id, name, slug, logo_url, bot_token, is_active, settings, created_at, updated_at) FROM stdin;
0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	AkoWater	akowater	\N	\N	t	\N	2026-04-01 08:37:49.49754+00	2026-04-01 08:37:49.49754+00
\.


--
-- Data for Name: treasury_transactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.treasury_transactions (id, tenant_id, order_id, created_by_id, transaction_type, category, amount, payment_method, description, transaction_date) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, tenant_id, telegram_id, telegram_username, first_name, last_name, phone, role, hashed_password, is_active, is_phone_verified, bot_blocked, language, created_at, updated_at, cash_balance, card_balance, secondary_role) FROM stdin;
b48b8100-a97f-4462-a874-3a4d8208a299	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	\N	Admin	SuvPro	998901234567	SUPER_ADMIN	$2b$12$JK6tNkOfSEP7suZjAYo3XeFKVnW14k7slrtssiVjPbty5LqGEMGgC	t	f	f	ru	2026-04-01 08:07:23.086411+00	2026-04-01 08:07:23.086411+00	0	0	\N
dbe6c2f9-e1b5-4177-a8ca-865f84fa3049	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	\N	Alisher		997555516	COURIER	\N	t	f	f	uz	2026-04-01 13:48:11.922982+00	2026-04-01 13:52:51.571694+00	0	0	\N
9c586c10-f2ab-4708-8b71-5a6fc8367a39	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	\N	Test	\N	+998901111111	CLIENT	\N	f	t	f	uz	2026-04-01 08:37:57.081437+00	2026-04-01 17:48:23.395073+00	0	0	\N
889f4fbc-04bc-44a9-8b77-125ce7f8960f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	7628815246	Prooudmoore	Бехруз	Хайриллоев	+998937570731	COURIER	\N	t	t	f	ru	2026-04-01 08:46:12.544418+00	2026-04-01 18:51:28.539983+00	0	0	\N
027ff79a-39f6-429d-81d2-b3aadf3f0455	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	\N	\N	Xasan	Zaripov	998770357032	CLIENT	\N	t	f	f	uz	2026-04-02 05:22:55.119929+00	2026-04-02 15:58:39.362027+00	0	0	\N
9acbe1e9-7daa-40cc-b128-70dcc1bf6793	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	6111091625	zaripov_oo17	Xasan	Zaripov	+998900880282	OPERATOR	$2b$12$yuw7xSJdDxiNBJNCHDSHD.Odn4SdX/xKE/96oFqrskt8.S7QtwjIu	t	t	f	uz	2026-04-01 15:33:15.324194+00	2026-04-02 15:58:55.580081+00	0	0	courier
7a4fed15-43ec-4671-99df-adc96efb7c98	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	985937565	Himalaywater	Akobir	Qodirov	+998913373937	COURIER	\N	t	t	f	uz	2026-04-01 14:09:44.451031+00	2026-04-07 09:18:44.978651+00	0	0	\N
93afb7df-adc4-452b-8f3b-f4ea0b52bec6	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	5358138651	\N	Alisher	Abduahatov	+998997555516	CLIENT	\N	t	t	f	uz	2026-04-11 15:16:34.609078+00	2026-04-11 15:16:34.609078+00	0	0	\N
\.


--
-- Data for Name: warehouse_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.warehouse_items (id, tenant_id, product_id, name, unit, is_container, is_full, low_threshold, out_threshold, created_at, updated_at) FROM stdin;
e56ee028-fb79-49c7-bd65-d019ddc11b9d	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	db2394db-8718-401b-8024-345fb7030703	ako 10L	ta	f	t	50	10	2026-04-01 13:45:09.658059+00	2026-04-01 15:18:13.454968+00
2a3a6cb2-2fa7-4327-b662-24241491ae8f	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	cc05e7d1-dc94-430a-9c8e-22bb284a12ca	ako 5L	ta	f	t	50	10	2026-04-01 13:44:46.340204+00	2026-04-01 15:18:20.679432+00
ac653983-cf86-47e2-b860-6db1a6d423fc	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	a64ff9fa-562d-43d9-881e-f08f97db0d33	Himalay 18.9L	ta	f	t	50	10	2026-04-01 15:50:11.500842+00	2026-04-01 15:50:11.500842+00
32eb1319-c245-43bf-a841-b9eccd31f881	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	111a3a1e-89cf-4640-b800-40bce6d40e88	ako 18.9L	ta	t	t	50	10	2026-04-02 10:01:41.047766+00	2026-04-02 10:02:52.763587+00
\.


--
-- Data for Name: warehouse_stock; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.warehouse_stock (id, tenant_id, item_id, quantity, empty_quantity) FROM stdin;
80df4632-dbf8-42de-924c-dcabed17a5c9	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	32eb1319-c245-43bf-a841-b9eccd31f881	0	0
76e742e6-adce-49d9-84cc-5c443bfb3f9b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	ac653983-cf86-47e2-b860-6db1a6d423fc	979	2001
386a97dc-dbca-4282-9521-72600324f2b4	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	e56ee028-fb79-49c7-bd65-d019ddc11b9d	857	0
a7526834-fb91-482b-bb58-feac61538b31	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	2a3a6cb2-2fa7-4327-b662-24241491ae8f	878	0
\.


--
-- Data for Name: warehouse_transactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.warehouse_transactions (id, tenant_id, item_id, order_id, courier_id, created_by_id, transaction_type, quantity, balance_before, balance_after, note, created_at) FROM stdin;
9b0525f9-482d-4f5f-a06a-a7facde5c7c2	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	e56ee028-fb79-49c7-bd65-d019ddc11b9d	\N	\N	b48b8100-a97f-4462-a874-3a4d8208a299	KIRIM	1000	0	1000	\N	2026-04-01 13:46:26.4003+00
25b764e7-fa2b-43f3-904a-2c2d71c9776a	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	e56ee028-fb79-49c7-bd65-d019ddc11b9d	\N	\N	b48b8100-a97f-4462-a874-3a4d8208a299	KIRIM	1000	1000	2000	\N	2026-04-01 13:47:03.047814+00
718c9614-1693-42e7-a7a0-130ad395c76e	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	e56ee028-fb79-49c7-bd65-d019ddc11b9d	\N	\N	b48b8100-a97f-4462-a874-3a4d8208a299	CHIQIM	1000	2000	1000	\N	2026-04-01 13:47:12.575223+00
f1dd1e1d-de94-4e28-abcc-a2fec8ff8d23	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	2a3a6cb2-2fa7-4327-b662-24241491ae8f	\N	\N	b48b8100-a97f-4462-a874-3a4d8208a299	KIRIM	1000	0	1000	\N	2026-04-01 13:47:20.944078+00
4180ab72-713b-41e1-97ba-4efe11f79451	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	ac653983-cf86-47e2-b860-6db1a6d423fc	\N	\N	b48b8100-a97f-4462-a874-3a4d8208a299	KIRIM	3000	0	3000	Bo'sh tara kirim	2026-04-01 15:52:52.43727+00
515f38bb-7bc4-4f13-ba0d-05726b387326	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	ac653983-cf86-47e2-b860-6db1a6d423fc	\N	\N	b48b8100-a97f-4462-a874-3a4d8208a299	KIRIM	1000	0	1000	\N	2026-04-01 15:53:43.243116+00
e665ee1e-436b-4cc2-9524-a0944e8506a3	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	ac653983-cf86-47e2-b860-6db1a6d423fc	\N	\N	b48b8100-a97f-4462-a874-3a4d8208a299	CHIQIM	20	1000	980	\N	2026-04-01 15:54:01.351847+00
dae33093-530d-4d3f-a0e9-1fbc29652478	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	e56ee028-fb79-49c7-bd65-d019ddc11b9d	\N	\N	9acbe1e9-7daa-40cc-b128-70dcc1bf6793	KIRIM	10	880	890	\N	2026-04-01 15:58:46.053402+00
7392d57f-8e91-427f-aab9-95731b4f720b	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	e56ee028-fb79-49c7-bd65-d019ddc11b9d	\N	\N	9acbe1e9-7daa-40cc-b128-70dcc1bf6793	CHIQIM	10	890	880	\N	2026-04-01 15:58:54.640993+00
f857569b-a8af-47d0-8b53-a0d2be1d4583	0f92d89b-e7e7-411c-8c89-b5dd801bbe6a	ac653983-cf86-47e2-b860-6db1a6d423fc	1	\N	\N	KIRIM	1	2000	2001	Buyurtma #1 - mijoz pust tara qaytardi	2026-04-01 16:20:45.251335+00
\.


--
-- Name: orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.orders_id_seq', 4, true);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: client_addresses client_addresses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client_addresses
    ADD CONSTRAINT client_addresses_pkey PRIMARY KEY (id);


--
-- Name: client_groups client_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client_groups
    ADD CONSTRAINT client_groups_pkey PRIMARY KEY (id);


--
-- Name: clients clients_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_pkey PRIMARY KEY (id);


--
-- Name: container_client_balance container_client_balance_client_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.container_client_balance
    ADD CONSTRAINT container_client_balance_client_id_key UNIQUE (client_id);


--
-- Name: container_client_balance container_client_balance_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.container_client_balance
    ADD CONSTRAINT container_client_balance_pkey PRIMARY KEY (id);


--
-- Name: container_transactions container_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.container_transactions
    ADD CONSTRAINT container_transactions_pkey PRIMARY KEY (id);


--
-- Name: courier_balance_log courier_balance_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.courier_balance_log
    ADD CONSTRAINT courier_balance_log_pkey PRIMARY KEY (id);


--
-- Name: courier_cash_collections courier_cash_collections_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.courier_cash_collections
    ADD CONSTRAINT courier_cash_collections_pkey PRIMARY KEY (id);


--
-- Name: courier_inventory courier_inventory_courier_id_product_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.courier_inventory
    ADD CONSTRAINT courier_inventory_courier_id_product_id_key UNIQUE (courier_id, product_id);


--
-- Name: courier_inventory courier_inventory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.courier_inventory
    ADD CONSTRAINT courier_inventory_pkey PRIMARY KEY (id);


--
-- Name: couriers couriers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.couriers
    ADD CONSTRAINT couriers_pkey PRIMARY KEY (id);


--
-- Name: debt_transactions debt_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.debt_transactions
    ADD CONSTRAINT debt_transactions_pkey PRIMARY KEY (id);


--
-- Name: debts debts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.debts
    ADD CONSTRAINT debts_pkey PRIMARY KEY (id);


--
-- Name: notifications_log notifications_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_log
    ADD CONSTRAINT notifications_log_pkey PRIMARY KEY (id);


--
-- Name: operator_cash_submissions operator_cash_submissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.operator_cash_submissions
    ADD CONSTRAINT operator_cash_submissions_pkey PRIMARY KEY (id);


--
-- Name: order_items order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_pkey PRIMARY KEY (id);


--
-- Name: order_status_history order_status_history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_status_history
    ADD CONSTRAINT order_status_history_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: price_history price_history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.price_history
    ADD CONSTRAINT price_history_pkey PRIMARY KEY (id);


--
-- Name: product_categories product_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_categories
    ADD CONSTRAINT product_categories_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: regions regions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.regions
    ADD CONSTRAINT regions_pkey PRIMARY KEY (id);


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (id);


--
-- Name: settings settings_tenant_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_tenant_id_key UNIQUE (tenant_id);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_slug_key UNIQUE (slug);


--
-- Name: treasury_transactions treasury_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.treasury_transactions
    ADD CONSTRAINT treasury_transactions_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_telegram_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_telegram_id_key UNIQUE (telegram_id);


--
-- Name: warehouse_items warehouse_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouse_items
    ADD CONSTRAINT warehouse_items_pkey PRIMARY KEY (id);


--
-- Name: warehouse_stock warehouse_stock_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouse_stock
    ADD CONSTRAINT warehouse_stock_pkey PRIMARY KEY (id);


--
-- Name: warehouse_transactions warehouse_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouse_transactions
    ADD CONSTRAINT warehouse_transactions_pkey PRIMARY KEY (id);


--
-- Name: idx_courier_cash_collections_courier; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_courier_cash_collections_courier ON public.courier_cash_collections USING btree (courier_id);


--
-- Name: idx_courier_cash_collections_tenant; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_courier_cash_collections_tenant ON public.courier_cash_collections USING btree (tenant_id);


--
-- Name: idx_courier_inventory_courier; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_courier_inventory_courier ON public.courier_inventory USING btree (courier_id);


--
-- Name: idx_courier_inventory_full; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_courier_inventory_full ON public.courier_inventory USING btree (courier_id, product_id, quantity);


--
-- Name: idx_courier_inventory_product; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_courier_inventory_product ON public.courier_inventory USING btree (product_id);


--
-- Name: ix_audit_log_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_audit_log_tenant_id ON public.audit_log USING btree (tenant_id);


--
-- Name: ix_client_addresses_client_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_client_addresses_client_id ON public.client_addresses USING btree (client_id);


--
-- Name: ix_client_addresses_primary; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_client_addresses_primary ON public.client_addresses USING btree (client_id, is_primary);


--
-- Name: ix_client_addresses_text; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_client_addresses_text ON public.client_addresses USING btree (address_text);


--
-- Name: ix_client_groups_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_client_groups_tenant_id ON public.client_groups USING btree (tenant_id);


--
-- Name: ix_clients_group_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_clients_group_id ON public.clients USING btree (group_id);


--
-- Name: ix_clients_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_clients_is_active ON public.clients USING btree (tenant_id, is_active) WHERE (is_deleted = false);


--
-- Name: ix_clients_is_blocked; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_clients_is_blocked ON public.clients USING btree (tenant_id, is_blocked) WHERE (is_deleted = false);


--
-- Name: ix_clients_phone; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_clients_phone ON public.clients USING btree (phone);


--
-- Name: ix_clients_tenant_deleted; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_clients_tenant_deleted ON public.clients USING btree (tenant_id, is_deleted);


--
-- Name: ix_clients_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_clients_tenant_id ON public.clients USING btree (tenant_id);


--
-- Name: ix_container_transactions_client_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_container_transactions_client_id ON public.container_transactions USING btree (client_id);


--
-- Name: ix_courier_balance_log_courier_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_courier_balance_log_courier_id ON public.courier_balance_log USING btree (courier_id);


--
-- Name: ix_couriers_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_couriers_tenant_id ON public.couriers USING btree (tenant_id);


--
-- Name: ix_debt_transactions_client_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_debt_transactions_client_id ON public.debt_transactions USING btree (client_id);


--
-- Name: ix_debts_client_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_debts_client_id ON public.debts USING btree (client_id);


--
-- Name: ix_debts_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_debts_tenant_id ON public.debts USING btree (tenant_id);


--
-- Name: ix_operator_cash_submissions_operator_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_operator_cash_submissions_operator_id ON public.operator_cash_submissions USING btree (operator_id);


--
-- Name: ix_operator_cash_submissions_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_operator_cash_submissions_tenant_id ON public.operator_cash_submissions USING btree (tenant_id);


--
-- Name: ix_order_items_order_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_order_items_order_id ON public.order_items USING btree (order_id);


--
-- Name: ix_order_status_history_order_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_order_status_history_order_id ON public.order_status_history USING btree (order_id);


--
-- Name: ix_orders_client_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_orders_client_id ON public.orders USING btree (client_id);


--
-- Name: ix_orders_courier_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_orders_courier_id ON public.orders USING btree (courier_id);


--
-- Name: ix_orders_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_orders_status ON public.orders USING btree (status);


--
-- Name: ix_orders_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_orders_tenant_id ON public.orders USING btree (tenant_id);


--
-- Name: ix_price_history_product_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_price_history_product_id ON public.price_history USING btree (product_id);


--
-- Name: ix_products_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_products_tenant_id ON public.products USING btree (tenant_id);


--
-- Name: ix_regions_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_regions_tenant_id ON public.regions USING btree (tenant_id);


--
-- Name: ix_treasury_transactions_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_treasury_transactions_tenant_id ON public.treasury_transactions USING btree (tenant_id);


--
-- Name: ix_users_phone; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_users_phone ON public.users USING btree (phone);


--
-- Name: ix_users_telegram_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_users_telegram_id ON public.users USING btree (telegram_id);


--
-- Name: ix_warehouse_stock_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_warehouse_stock_tenant_id ON public.warehouse_stock USING btree (tenant_id);


--
-- Name: ix_warehouse_transactions_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_warehouse_transactions_tenant_id ON public.warehouse_transactions USING btree (tenant_id);


--
-- Name: audit_log audit_log_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: audit_log audit_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: client_addresses client_addresses_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client_addresses
    ADD CONSTRAINT client_addresses_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: client_addresses client_addresses_region_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client_addresses
    ADD CONSTRAINT client_addresses_region_id_fkey FOREIGN KEY (region_id) REFERENCES public.regions(id) ON DELETE SET NULL;


--
-- Name: client_addresses client_addresses_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client_addresses
    ADD CONSTRAINT client_addresses_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: client_groups client_groups_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client_groups
    ADD CONSTRAINT client_groups_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: clients clients_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: clients clients_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: container_client_balance container_client_balance_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.container_client_balance
    ADD CONSTRAINT container_client_balance_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: container_client_balance container_client_balance_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.container_client_balance
    ADD CONSTRAINT container_client_balance_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: container_transactions container_transactions_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.container_transactions
    ADD CONSTRAINT container_transactions_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: container_transactions container_transactions_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.container_transactions
    ADD CONSTRAINT container_transactions_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: container_transactions container_transactions_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.container_transactions
    ADD CONSTRAINT container_transactions_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE SET NULL;


--
-- Name: container_transactions container_transactions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.container_transactions
    ADD CONSTRAINT container_transactions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: courier_balance_log courier_balance_log_courier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.courier_balance_log
    ADD CONSTRAINT courier_balance_log_courier_id_fkey FOREIGN KEY (courier_id) REFERENCES public.couriers(id) ON DELETE CASCADE;


--
-- Name: courier_balance_log courier_balance_log_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.courier_balance_log
    ADD CONSTRAINT courier_balance_log_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE SET NULL;


--
-- Name: courier_balance_log courier_balance_log_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.courier_balance_log
    ADD CONSTRAINT courier_balance_log_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: courier_cash_collections courier_cash_collections_collected_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.courier_cash_collections
    ADD CONSTRAINT courier_cash_collections_collected_by_id_fkey FOREIGN KEY (collected_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: courier_cash_collections courier_cash_collections_courier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.courier_cash_collections
    ADD CONSTRAINT courier_cash_collections_courier_id_fkey FOREIGN KEY (courier_id) REFERENCES public.couriers(id) ON DELETE CASCADE;


--
-- Name: courier_cash_collections courier_cash_collections_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.courier_cash_collections
    ADD CONSTRAINT courier_cash_collections_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: courier_inventory courier_inventory_courier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.courier_inventory
    ADD CONSTRAINT courier_inventory_courier_id_fkey FOREIGN KEY (courier_id) REFERENCES public.couriers(id) ON DELETE CASCADE;


--
-- Name: courier_inventory courier_inventory_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.courier_inventory
    ADD CONSTRAINT courier_inventory_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: courier_inventory courier_inventory_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.courier_inventory
    ADD CONSTRAINT courier_inventory_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: couriers couriers_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.couriers
    ADD CONSTRAINT couriers_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: couriers couriers_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.couriers
    ADD CONSTRAINT couriers_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: debt_transactions debt_transactions_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.debt_transactions
    ADD CONSTRAINT debt_transactions_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: debt_transactions debt_transactions_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.debt_transactions
    ADD CONSTRAINT debt_transactions_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: debt_transactions debt_transactions_debt_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.debt_transactions
    ADD CONSTRAINT debt_transactions_debt_id_fkey FOREIGN KEY (debt_id) REFERENCES public.debts(id) ON DELETE CASCADE;


--
-- Name: debt_transactions debt_transactions_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.debt_transactions
    ADD CONSTRAINT debt_transactions_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE SET NULL;


--
-- Name: debt_transactions debt_transactions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.debt_transactions
    ADD CONSTRAINT debt_transactions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: debts debts_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.debts
    ADD CONSTRAINT debts_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: debts debts_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.debts
    ADD CONSTRAINT debts_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: debts debts_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.debts
    ADD CONSTRAINT debts_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: clients fk_clients_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT fk_clients_group_id FOREIGN KEY (group_id) REFERENCES public.client_groups(id) ON DELETE SET NULL;


--
-- Name: products fk_products_container_product_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT fk_products_container_product_id FOREIGN KEY (container_product_id) REFERENCES public.products(id) ON DELETE SET NULL;


--
-- Name: notifications_log notifications_log_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_log
    ADD CONSTRAINT notifications_log_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE SET NULL;


--
-- Name: notifications_log notifications_log_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_log
    ADD CONSTRAINT notifications_log_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: notifications_log notifications_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_log
    ADD CONSTRAINT notifications_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: operator_cash_submissions operator_cash_submissions_collected_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.operator_cash_submissions
    ADD CONSTRAINT operator_cash_submissions_collected_by_id_fkey FOREIGN KEY (collected_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: operator_cash_submissions operator_cash_submissions_operator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.operator_cash_submissions
    ADD CONSTRAINT operator_cash_submissions_operator_id_fkey FOREIGN KEY (operator_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: operator_cash_submissions operator_cash_submissions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.operator_cash_submissions
    ADD CONSTRAINT operator_cash_submissions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: order_items order_items_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: order_items order_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE RESTRICT;


--
-- Name: order_items order_items_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: order_status_history order_status_history_changed_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_status_history
    ADD CONSTRAINT order_status_history_changed_by_id_fkey FOREIGN KEY (changed_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: order_status_history order_status_history_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_status_history
    ADD CONSTRAINT order_status_history_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: order_status_history order_status_history_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_status_history
    ADD CONSTRAINT order_status_history_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: orders orders_address_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_address_id_fkey FOREIGN KEY (address_id) REFERENCES public.client_addresses(id) ON DELETE SET NULL;


--
-- Name: orders orders_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE RESTRICT;


--
-- Name: orders orders_courier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_courier_id_fkey FOREIGN KEY (courier_id) REFERENCES public.couriers(id) ON DELETE SET NULL;


--
-- Name: orders orders_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: price_history price_history_changed_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.price_history
    ADD CONSTRAINT price_history_changed_by_id_fkey FOREIGN KEY (changed_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: price_history price_history_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.price_history
    ADD CONSTRAINT price_history_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: price_history price_history_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.price_history
    ADD CONSTRAINT price_history_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: product_categories product_categories_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_categories
    ADD CONSTRAINT product_categories_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: products products_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.product_categories(id) ON DELETE SET NULL;


--
-- Name: products products_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: regions regions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.regions
    ADD CONSTRAINT regions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: settings settings_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: treasury_transactions treasury_transactions_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.treasury_transactions
    ADD CONSTRAINT treasury_transactions_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: treasury_transactions treasury_transactions_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.treasury_transactions
    ADD CONSTRAINT treasury_transactions_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE SET NULL;


--
-- Name: treasury_transactions treasury_transactions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.treasury_transactions
    ADD CONSTRAINT treasury_transactions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: users users_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: warehouse_items warehouse_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouse_items
    ADD CONSTRAINT warehouse_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: warehouse_items warehouse_items_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouse_items
    ADD CONSTRAINT warehouse_items_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: warehouse_stock warehouse_stock_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouse_stock
    ADD CONSTRAINT warehouse_stock_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.warehouse_items(id) ON DELETE CASCADE;


--
-- Name: warehouse_stock warehouse_stock_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouse_stock
    ADD CONSTRAINT warehouse_stock_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: warehouse_transactions warehouse_transactions_courier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouse_transactions
    ADD CONSTRAINT warehouse_transactions_courier_id_fkey FOREIGN KEY (courier_id) REFERENCES public.couriers(id) ON DELETE SET NULL;


--
-- Name: warehouse_transactions warehouse_transactions_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouse_transactions
    ADD CONSTRAINT warehouse_transactions_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: warehouse_transactions warehouse_transactions_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouse_transactions
    ADD CONSTRAINT warehouse_transactions_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.warehouse_items(id) ON DELETE RESTRICT;


--
-- Name: warehouse_transactions warehouse_transactions_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouse_transactions
    ADD CONSTRAINT warehouse_transactions_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE SET NULL;


--
-- Name: warehouse_transactions warehouse_transactions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouse_transactions
    ADD CONSTRAINT warehouse_transactions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict dHCbYRtXFK9TguVhp1WKSn6AYcMf6mb12SwXom6ZmpwQbjBb17PsK5koK8y6YMR

